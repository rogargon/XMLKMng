/*

Name: BuiltinBody.java

Version: 1.0

Purpose:

History:

*/

package edu.unika.aifb.inference;

public class BuiltinBody extends Body {
	private BuiltinFunc func;
	
	public BuiltinBody(int sym, boolean negated, Term[] terms, BuiltinFunc f) {
		// sym = Pr�dikatsymbol, anz = Stelligkeit, negated = negiert, terms = Feld von anz Termen
		super(sym,negated,terms);
		builtin = true;
		func = f;
	}
	
	public void Eval() {
		up.Eval(this,adddown,vars3,func);
		addup.UnionSelected(up);	
	}
	
	public boolean Evaluable(Atom t) {
		return func.isevaluable(this,t);
	}
	
	public boolean NaiveRight(Atoms brel, int index[]) {
		int oldnum, newnum,i;
		oldnum = brelation.anztuples;
		down.Substitute(this,brel,bindex);
		up.Eval(this,down,vars3,func);
		if (!neg)
			// Join mit positivem Rumpfliteral
			 brelation.Join(brel,index,up,index1, brel.matchindex,dindex);
		else 
			// Differenz mit negativem Rumpfliteral
			brelation.Negation(brel,index,up,index1);
		newnum = brelation.anztuples;
		return oldnum != newnum;
	}

}

