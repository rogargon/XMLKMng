/*

Name:

Version: 1.0

Purpose:

History:

*/



package edu.unika.aifb.inference;

import java.io.*;
import java.net.*;
import java.util.*;



class TriviaS1 {
    private static final int PORTNUM = 1235;
    private ServerSocket serverSocket;
    private Evaluator eval;

    public TriviaS1(Evaluator ev) {
        //super("TriviaServer");
        try {
            serverSocket = new ServerSocket(PORTNUM);
            System.out.println("Compilation Server up and running ...");
        }
        catch (IOException e) {
            System.err.println("Exception: couldn't create socket");
            System.exit(1);
        }
	eval = ev;
    }


    public void run() {
        Socket clientSocket = null;
	
        // Look for clients and ask trivia questions
        while (true) {
            // Wait for a client
            if (serverSocket == null)
                return;
            try {
                clientSocket = serverSocket.accept();
            }
            catch (IOException e) {
                System.err.println("Exception: couldn't connect to client socket");
                System.exit(1);
            }

            // Perform the question/answer processing
            try {
                DataInputStream is = new DataInputStream(clientSocket.getInputStream());
                PrintStream os = new PrintStream(new BufferedOutputStream(clientSocket.getOutputStream()), false);
                eval.RS.writeonly(os);
		String outLine, inLine;
		String queries;
		long sec1, sec2;
		Rule r;

	      	os.println("start");
	      	os.flush();

		// Get the queries
		queries ="";
        while (true) {	  
	       // read in a line
	       inLine = is.readLine();
	       if (inLine.length() > 0) {
				if (inLine.equals("stop")) {
					// os.println("stop");
					break;
				}
				else {
					System.out.print("Query: "); System.out.println(inLine);
					queries = queries + inLine;
					// eval.compileString(inLine);
				}
			}
		}

		// translate the queries
		CollectMediator cm = eval.translateString(queries);

		// give the variable names 
		for (java.util.Enumeration e = cm.Queries.elements(); e.hasMoreElements();) {
			Object q = e.nextElement();
			Vector vars = (Vector)cm.Names.get(q);
			Vector nums = (Vector)cm.Numbers.get(q);
			int i = vars.size();
			for (int h = 0; h < i; h++) {
				// System.out.println(vars.elementAt(h) + " has been given the internal variable number "+nums.elementAt(h));
				os.print("\""); os.print(vars.elementAt(h)); os.print("\"");
				if (h<i-1) os.print(",");
			}
		}
		os.println();

		// give the rules
		for (int i = 0; i < cm.Rules.size(); i++) {
			r = (Rule)cm.Rules.elementAt(i);
			//r.print(System.out);
			r.internalize(os);
			os.println();
		}
		for (int i = 0; i < cm.Queries.size(); i++) {
			r = (Rule)cm.Queries.elementAt(i);
			//r.print(System.out);
			r.internalize(os);
			os.println();
		}

		os.println("stop");

		os.flush();
	        // Cleanup
		// System.out.println("Closing Client");
	        os.close();
	        is.close();
	        clientSocket.close();
            }
            catch (Exception e) {
                System.err.println("Exception: " + e);
                e.printStackTrace();
            }
        }
    }

  
}

public class CompileServer {
    public static void main(String[] args) throws IOException {
	RandomAccessFile file;
	Evaluator ev;
	int i;
	file = new RandomAccessFile(args[0],"r");  
	ev = new Evaluator();
	ev.init();
	ev.read(file);
	file.close();
        TriviaS1 server = new TriviaS1(ev);
        server.run();
    }
}
