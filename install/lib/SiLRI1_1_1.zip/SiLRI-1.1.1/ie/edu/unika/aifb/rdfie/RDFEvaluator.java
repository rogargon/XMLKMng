/*

Name: RDFEvaluator.java

Version: 1.01

Purpose:

History:
5.2. Added implementation for org.desire.rudolf.rdf.RDFModelCore interface: SDe

*/

package edu.unika.aifb.rdfie;

import java.io.*;
import java.util.*;
import java.net.*;

import edu.unika.aifb.inference.*;
import org.w3c.rdf.*;
import org.desire.rudolf.rdf.RDFModelCore;




public class RDFEvaluator extends Evaluator implements RDFModelCore{
//static String TRIPLENAME = "setatt_";
static String TRIPLENAME = Config.METHODSYMBOL[1]; //"triple";
static String LITERALNAME = "literal";
static String RESOURCENAME = "resource";



int triplesymbol,literalsymbol,resourcesymbol;
int count;




public void init() {
 try{
 super.init();
 count =0;
 triplesymbol=PSymbols.searchAndInsert(TRIPLENAME,3);
 literalsymbol = FSymbols.searchAndInsert(LITERALNAME,1);
 resourcesymbol = FSymbols.searchAndInsert(RESOURCENAME,1);

  // if no XML parser was specified, use IBM XML4j (assuming that it is in the classpath)
  if(System.getProperties().getProperty("org.xml.sax.parser") == null)
  	System.getProperties().put("org.xml.sax.parser","com.ibm.xml.parser.SAXDriver");
  //compileString(RDFAxioms.RDFAXIOMS);
 } catch(Exception e) {System.out.println(e);}
}


public void ReInit() {
 try{
 super.ReInit();
 count =0;
 triplesymbol=PSymbols.searchAndInsert(TRIPLENAME,3);
 literalsymbol = FSymbols.searchAndInsert(LITERALNAME,1);
 resourcesymbol = FSymbols.searchAndInsert(RESOURCENAME,1);
  //compileString(RDFAxioms.RDFAXIOMS);
 } catch(Exception e) {System.out.println(e);}
}

public void compileRDFFile(String filename) throws Exception{ 
	IESiRPAC.computeTriples(filename,false,this);
}


public void compileRDFURL(String urlname) throws Exception{   
	IESiRPAC.computeTriples(urlname,false,this);
}

/*
public void compileRDFString(String rules,String ResourceName)  throws Exception{ 
	compileRDFStream(new StringBufferInputStream(rules),ResourceName);
}

public void compileRDFFile(String filename) throws Exception{ 
	compileRDFStream(new FileInputStream(filename),filename); 
}


public void compileRDFURL(String URLName) throws Exception{   
	URL url = new URL (URLName);
	compileRDFStream(url.openStream(),URLName); 
}

public void compileRDFStream(InputStream RDF,String ResourceName) throws Exception{
	count=0; 
	IESiRPAC.computeTriples(RDF,ResourceName,this);
	//System.out.println("Loaded " + new Integer(count) + " Triples.");
}
*/


   public void addTriple (Property predicate,
			   Resource subject,
			   RDFnode object){

	RS.AddFact(triplesymbol,new GroundAtom(createTerms(predicate,subject,object)));
}

Term[] createTerms(	Property predicate,
			Resource subject,
			RDFnode object){

	int k;	
	Term[] t = new Term[3];
	if(predicate!=null){
		k = Strings.searchAndInsert(predicate.getPredicate());
		t[1] = new ConstTerm(k+Config.STRINGSTART);
	}
	else t[1] = null;

	if(subject!=null){
		k = Strings.searchAndInsert(subject.getURI());
		t[0] = new ConstTerm(k+Config.STRINGSTART);
	}
	else t[0] = null;

	if(object!=null){
		if(object instanceof org.w3c.rdf.Literal){
			k=Strings.searchAndInsert(((org.w3c.rdf.Literal) object).toString());
			Term[] st = new Term[1];
			st[0] = new ConstTerm(k+Config.STRINGSTART);
			t[2] = new ConstTerm(literalsymbol,st);
		}
		else if(object instanceof Resource){
			k = Strings.searchAndInsert(((org.w3c.rdf.Resource)object).getURI());
			Term[] st = new Term[1];
			st[0] = new ConstTerm(k+Config.STRINGSTART);
			t[2] = new ConstTerm(resourcesymbol,st);		
		}
		else System.out.println("Unknown object type");
	}
	else t[2]=null;
	return t;


}

/* Ignore start and end messages right now */
/* if quering and adding data is async we could use that to set a
   semaphore
*/

public void start(DataSource ds){}

public void end(DataSource ds){}

/* Add triple to factbase. Ignore Datasource right now */
public void assert(DataSource ds, Property p,  Resource r, RDFnode v){
	addTriple (p,r,v);
}

/* generate query about this assertion */
public boolean hasAssertion( Property p,  Resource r, RDFnode v){
	boolean result = true;
	Term[] t = createTerms(p,r,v);
	Body[] b =  {new Body(triplesymbol,false,t)};
	Rule q = new Rule(null,b);
	RS.AddRule(q);
	evaluate();	
	result = testSubstitutions(q);
	RS.DeleteRule(q);
	return result;
}



public Vector valuesWhere(Property p, Resource r){
	Vector result = new Vector(); // create result vector

	Vector nums = new Vector(1);
	Vector vars = new Vector(1); // create vector for answer variable number and name

	nums.addElement(new Integer(0)); // add answer variable number
	vars.addElement("Z"); // add answer variable name (arbitrary)

	Term[] t = createTerms(p,r,null); // create query triple
	t[2] =  new Variable(0); // add variable
	Body[] b =  {new Body(triplesymbol,false,t)}; // create new body with triplesymbol as 
	// predicate, non-negated, and terms t
	Rule q = new Rule(null,b); //crate new Rule with empty head (a query)

	Names.put(q,vars); // register variables for query
	Numbers.put(q,nums);

	RS.AddRule(q); // add rule to RuleSet
	evaluate(); // evaluate it
	Vector subs = computeSingleSubstitution(q); // compute answer substitutions for query q
	for(java.util.Enumeration  e = subs.elements() ; e.hasMoreElements() ;) {
		Vector sv = (Vector) e.nextElement();	// a vector of variable-term pairs	
		SimpleSubst s =  (SimpleSubst) sv.elementAt(0); // a variable-term pair
		FTerm ft=s.getTerm(); // getTerm
		result.addElement(getObject(ft)); // Transform to object
	} 
	deleteQuery(q); // delete rule from RuleSet (and corresponding variables)
	return result;

}

public Vector nodesWhere(Property p, RDFnode v){
	Vector result = new Vector();

	Vector nums = new Vector(1);
	Vector vars = new Vector(1);

	nums.addElement(new Integer(0));
	vars.addElement("X");

	Term[] t = createTerms(p,null,v);
	t[0] =  new Variable(0);
	Body[] b =  {new Body(triplesymbol,false,t)};
	Rule q = new Rule(null,b);

	Names.put(q,vars);
	Numbers.put(q,nums);

	RS.AddRule(q);
	stratify();
	evaluate();
	Vector subs = computeSingleSubstitution(q);
	for(java.util.Enumeration  e = subs.elements() ; e.hasMoreElements() ;) {
		Vector sv = (Vector) e.nextElement();		
		SimpleSubst s =  (SimpleSubst) sv.elementAt(0);
		FTerm ft=s.getTerm();
		result.addElement(getSubject(ft));
	}
	deleteQuery(q);
	return result;
}

public Vector nodesWhere(Property p){
	Vector result = new Vector();

	Vector nums = new Vector(1);
	Vector vars = new Vector(1);

	nums.addElement(new Integer(0));
	vars.addElement("X");

	Term[] t = createTerms(p,null,null);
	t[0] =  new Variable(0);	
	t[2] =  new Variable(1);	
	Body[] b =  {new Body(triplesymbol,false,t)};
	Rule q = new Rule(null,b);
	RS.AddRule(q);
	Names.put(q,vars);
	Numbers.put(q,nums);
	stratify();
	evaluate();
	Vector subs = computeSingleSubstitution(q);
	for(java.util.Enumeration  e = subs.elements() ; e.hasMoreElements() ;) {
		Vector sv = (Vector) e.nextElement();		
		SimpleSubst s =  (SimpleSubst) sv.elementAt(0);
		FTerm ft=s.getTerm();
		Resource r = getSubject(ft);
		if(!result.contains(r))
			result.addElement(r);
	}
	deleteQuery(q);
	return result;
}

RDFnode getObject(FTerm ft){
	if(ft instanceof FTermFunction){
		FTermFunction ftf = (FTermFunction) ft;
		FTerm[] args = ftf.getArguments();if(args==null) args = new FTerm[0];
		String symbol = ftf.getSymbol();
		if(args.length==1 && args[0] instanceof FTermString){
			String content = ((FTermString) args[0]).getContent();
			if(symbol.equals(LITERALNAME)) 
				return new org.w3c.rdf.Literal(content);
			else
				if(symbol.equals(RESOURCENAME))
					return new org.w3c.rdf.Resource(content);
				else
					return new org.w3c.rdf.Literal(ft.toString());
		}
		else
			return new org.w3c.rdf.Literal(ft.toString());
	}
	else 
		return new org.w3c.rdf.Literal(ft.toString());			
}


org.w3c.rdf.Resource getSubject(FTerm ft){
	if(ft instanceof FTermString){
		FTermString fts = (FTermString) ft;
		return new org.w3c.rdf.Resource(fts.getContent());
	}
	else 
		return new org.w3c.rdf.Resource(ft.toString());			
}



}	

