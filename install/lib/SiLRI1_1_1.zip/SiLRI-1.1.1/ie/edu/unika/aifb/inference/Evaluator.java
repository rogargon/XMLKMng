/*

Name: Evaluator.java

Version: 1.0

Purpose:
Capsulates the Inference Engine, realises an abstract API

History:

*/

package edu.unika.aifb.inference;

import java.util.*;
import java.net.*;
import java.io.*;

public class Evaluator extends SimpleEvaluator {


FLParser parser;



public void init(PrintStream f){ 
	super.init(f);
	parser = new FLParser(new StringBufferInputStream(""));
	try{
	compileString(Axioms.FLOGICAXIOMS);
   	} catch (Exception e) { System.out.println(e);}
}

public void ReInit (){
       super.init();
       try{
         parser.ReInit (new StringBufferInputStream (Axioms.FLOGICAXIOMS));
         parser.CompilationUnit (new CompMediator (this));
       } catch (Exception e) { System.out.println(e);}
}   




public void compileString(String rules)  throws ParseException
   { compileStream(new StringBufferInputStream(rules));}

public void compileFile(String filename) throws Exception{ 
	compileStream(new FileInputStream(filename)); }
 


public void compileStream(InputStream Rules) throws ParseException
{  
   parser.ReInit(Rules); 
   parser.CompilationUnit(new CompMediator(this));  
   compiled = true;
}



public CollectMediator translateString(String rules)  throws ParseException
   { return translateStream(new StringBufferInputStream(rules));}

public CollectMediator translateFile(String filename) throws Exception
   { return translateStream(new FileInputStream(filename)); }


public CollectMediator translateStream(InputStream Rules) throws ParseException
{  CollectMediator store = new CollectMediator(this);
   parser.ReInit(Rules); 
   parser.CompilationUnit(store);  
   /*	for( java.util.Enumeration e = store.Queries.elements();e.hasMoreElements();){
	   Object q = e.nextElement();
	   Vector vars = (Vector) store.Names.get(q);
	   Vector nums = (Vector) store.Numbers.get(q);
	   int i = vars.size();
	   int h;
	   for(h = 0; h< i ; h ++){
  		System.out.println(vars.elementAt(h) + " has been given the internal variable number " + nums.elementAt(h));
	   }
	}
   */
   return store;
}




void compile(FLObject o)
{  java.util.Enumeration e,f,g;
   for(f=o.trans().elements(); f.hasMoreElements();)
      { GeneralClause gc = (GeneralClause) f.nextElement();
        for(g=gc.translate().elements(); g.hasMoreElements();)
           { NormalClause ng = (NormalClause) g.nextElement();
             //System.out.println( ng.toString());
		if(ng instanceof ProgRule){
			ProgRule pr = (ProgRule) ng;
			Vector Body = pr.Body;
    			if(Body==null || Body.size()==0) {
				Vector Head = pr.Head;// we have a fact: add Head as a fact to ruleset!
				int h = Head.size();
				int i;
				for(i=0;i < h ; i++)
          				((Literal) Head.elementAt(i)).addFact(RS,PSymbols,
              	                                        FSymbols,
                     	                                 Strings);
			}
			else RS.AddRule(pr.translate(PSymbols, FSymbols, Strings));
		}
               else RS.AddRule( ((ProgQuery) ng).translate(PSymbols, FSymbols, Names,Numbers,Strings));
           }
      }
    o=null;
}

public void compileStream(InputStream Rules, PrintStream out) throws ParseException
{  
   this.out = out;
   parser.ReInit(Rules);    
   parser.CompilationUnit(new TransMediator(this));  
   compiled = true;
   
}

void toSimple(FLObject o)
{  java.util.Enumeration e,f,g;
   for(f=o.trans().elements(); f.hasMoreElements();)
      { GeneralClause gc = (GeneralClause) f.nextElement();
        for(g=gc.translate().elements(); g.hasMoreElements();)
           { NormalClause ng = (NormalClause) g.nextElement();
             //System.out.println(ng.toString());
               if(ng instanceof ProgRule)
                 out.print(((ProgRule) ng).toSimple());
               else
                out.print(((ProgQuery) ng).toSimple());
           }
      }
    o=null;
}


public Vector computeSubstitutions()
{
int i;
Rule q;
int k,m,j;
Vector Vars;
Vector Nums;
Vector QSubst = new Vector();


for(q = RS.NextQuery(null); q != null; q = RS.NextQuery(q)) 
   { 
     Vector SetSubst = new Vector();
     Vars = (Vector) Names.get(q);
     Nums = (Vector) Numbers.get(q);
     Substitution S = RS.Substitution(q);
     //System.out.println(S.toString());
     k = S.index.length;
     //System.out.println(new Integer(k));
     if(Nums==null) j=0; else j = Nums.size();
     
     Atom A = (Atom) S.First();   // and NextTuple()
     //if(A==null) System.out.println("We do nothing");
     while(A !=null)   // do something...
       {//System.out.println("we do something...");

        Vector SingleSubst = new Vector();
        for(i=0;i<j;i++)
         {

          if(Nums.elementAt(i) != null && S.index[((Integer)(Nums.elementAt(i))).intValue()] >=0)
          {
           SingleSubst.addElement(new FLSubst((String) Vars.elementAt(i), 
                toFLTerm(A.terms[S.index[((Integer) Nums.elementAt(i)).intValue()]],FSymbols, Strings)));
           }
         }          
         SetSubst.addElement(SingleSubst);
         A = (Atom) S.Next(); 
       }
       QSubst.addElement(SetSubst);
}
return QSubst;                       
}


     
public Path toFLTerm(Term A,AVLTreeSymbol ids, AVLTreeString Strings ) 
 { 
   if(A instanceof Variable) 
         { 
           return new Path(new IDTermVariable("X" + Integer.toString(((Variable)A).symbol)));
         }
          else if(A instanceof NumTerm) 
         {
           return new Path(new IDTermFloat(new Double(((NumTerm) A).zahl)));
         }
          else if(A instanceof StringTerm)
        {
          return  new Path(new IDTermString(((StringTerm)A).s));
         }
          else if(A instanceof ConstTerm)
        {        
         ConstTerm C = (ConstTerm) A;
         if(C.symbol >= Config.STRINGSTART) 
             return  new Path(new IDTermString(Strings.getContent(C.symbol - Config.STRINGSTART))); 
 	  String s1 = (String) ids.getContent(C.symbol);
         if(s1== Config.NIL) return new Path(new IDTermList(null,null));
         if(s1== Config.LIST) { 
	       Vector l=new Vector();
               while(ids.getContent(C.symbol) != Config.NIL) {
                    l.addElement(toFLTerm(C.pars[0],ids,Strings));
                    C = (ConstTerm)  C.pars[1];
               }  
               return new Path(new IDTermList(l,null));
          }
    /*       
         if(s1== Config.PATHSYMBOL) 
           { Vector l = new Vector();
             l.addElement(new Integer(0));
             l.addElement(toFLTerm(C.pars[1],ids,Strings));
             return new Path((toFLTerm(C.pars[0],ids,Strings)).o,l);}
          if(s1==Config.METHODNAMESYMBOL) 
             { Path p = toFLTerm(C.pars[0],ids,Strings);
               ConstTerm args = (ConstTerm) C.pars[1];
               int p = args.anzpars;
               if(p>0)
                 { s = s.concat("@(");
                   for(int i=0;i<p;i++)
                     { s= s.concat(toFlogic(args.pars[i],ids,Strings));
                       if(i<p-1) s = s.concat(",");
                     }
                   s = s.concat(")");
                 }
                return s;                   
             }
          */ 

    
         Vector r= new Vector();
	 if (C.anzpars > 0) {
	       for(int i= 0; i < C.anzpars; i++) {
		  r.addElement(toFLTerm(C.pars[i],ids,Strings));
		}	
	}
	return new Path(new IDTermFunction(s1,r));	
     }
 return null;
   
}     


   public static void main(String args[]) throws Exception
   { 
     Evaluator  eval = new Evaluator();
     eval.init();   
     int i=0;
    while(i< args.length)
    {
      if(args[i].equals("-simple"))
         if ( i !=args.length - 1)
              { eval.compileSimpleFile(args[i+1]); i=i+2;}
         else System.out.println("Not enough arguments!");

      else {eval.compileFile(args[i]);i++;};
      
     }
     eval.stratify();
     eval.evaluate();
//   eval.dynamic();
//   eval.Wellfounded();
     eval.printSubs(eval.computeSubstitutions());
   
 }
                    
}

                   


abstract class ParserMediator {
 public void mediate(FLObject O) {}
}

class CompMediator extends ParserMediator{
	Evaluator engine;
 	public CompMediator(Evaluator engine){
		this.engine = engine;
	}


	public void mediate(FLObject O){
		engine.compile(O);
	}
}

class CollectMediator extends ParserMediator{
	Evaluator engine;
	public Hashtable Names;
	public Hashtable Numbers;
	/* Names and Numbers are Hashtables of Vector
	   Given query q, Names and Numbers can  be used like this:

 	for( java.util.Enumeration e =  Queries.elements();e.hasMoreElements();){
	   Object q = e.nextElement();
	   Vector vars = (Vector)  Names.get(q);
	   Vector nums = (Vector)  Numbers.get(q);
	   int i = vars.size();
	   int h;
	   for(h = 0; h< i ; h ++){
  		System.out.println(vars.elementAt(h) + " has been given the internal variable number " + nums.elementAt(h));
	   }
	}
 
       Names and Numbers are not introduced into the global names and numbers!
       (that means the internal procedures for translating substitutions to F-logic notation
        can not be used. 
       If you wish that, contact me. SDe.
        */
	public Vector Rules;
	public Vector Queries;


	
 	public CollectMediator(Evaluator engine){
		this.engine = engine;
		Rules=new Vector();	
		Queries = new Vector();
		Names = new Hashtable();
		Numbers = new Hashtable();
	
	}


	public void mediate(FLObject O){
		compile(O);
	}

	void compile(FLObject o){  
		java.util.Enumeration e,f,g;
		for(f=o.trans().elements(); f.hasMoreElements();){ 
			GeneralClause gc = (GeneralClause) f.nextElement();
			for(g=gc.translate().elements(); g.hasMoreElements();){
				NormalClause ng = (NormalClause) g.nextElement();
				//System.out.println(ng.toString());
				if(ng instanceof ProgRule){
					ProgRule pr = (ProgRule) ng;
					Vector Body = pr.Body;
    					if(Body==null || Body.size()==0) {
						System.out.println("Sorry, facts are currently unhandeld in class CollectMediator!");
					}
					else Rules.addElement(pr.translate(engine.PSymbols, engine.FSymbols, engine.Strings));
				}
               			else Queries.addElement( ((ProgQuery) ng).translate(engine.PSymbols, engine.FSymbols, Names,Numbers,engine.Strings));
           		}
      		}
    		o=null;
	}
}


class TransMediator extends ParserMediator{
	Evaluator engine;
	public TransMediator(Evaluator engine){
		this.engine = engine;
	}
	public void mediate(FLObject O){
		engine.toSimple(O);
	}
}
