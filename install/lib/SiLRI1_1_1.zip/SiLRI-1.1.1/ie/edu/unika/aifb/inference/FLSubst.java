/*

Name: FLSubst.java

Version: 1.0

Purpose:
Represents a Frame-Logic answer Substitution

History:

*/

package edu.unika.aifb.inference;


public class FLSubst 
{ public String Var;
  public Path Substitution;
  FLSubst(String Var,Path Substitution){
   this.Var = Var; this.Substitution = Substitution;}

  public String getSubstitutionString() { return Substitution.toString();}

  public String toString()  
  { return Var + " = " + Substitution.toString(); }

}   
