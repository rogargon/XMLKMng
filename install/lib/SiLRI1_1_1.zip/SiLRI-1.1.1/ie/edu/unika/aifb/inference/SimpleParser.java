/*

Name: SimpleParser.java

Version: 1.01

Purpose:
Parses Logic Programs in Datalog Notation

History:

2.5.99 Added support for new builtin mechanism. SDe

*/



package edu.unika.aifb.inference;
import edu.unika.aifb.builtins.BuiltinConfig;
import java.util.*;
import java.io.*;

public class SimpleParser {
        char c,d; int vars=0; int rule=0;
        SimpleEvaluator engine;
	RuleSet RS;
	AVLTreeSymbol FSymbols;
	AVLTreeSymbol PSymbols;
	AVLTreeString Strings;
	boolean fini;
        ASCII_UCodeESC_CharStream is;
	Hashtable varmap = new Hashtable(20);
	Vector Vars,Nums;
	// the following two variables are variables to speed up the 
	// parsing of single facts. The parser is therefore a litte bit
	// ugly...
	Vector Heads = new Vector(10,5);
	int atomsymbol;
	boolean query;
	public SimpleParser(SimpleEvaluator engine, InputStream stream) {
		 this.engine = engine;
                 is = new ASCII_UCodeESC_CharStream(stream, 1, 1);
	}



public void ReInit(InputStream stream)
	{ is = new ASCII_UCodeESC_CharStream(stream, 1, 1);}


	final boolean isLetter() {
		return  ((('a' <= c) && (('z' >= c))) ||  (('A' <= c) && (('Z' >= c))) || (c == '_'));
	}
	final boolean isUppercaseletter() {
		return ((('A' <= c) && ('Z' >= c)) || (c == '_'));
	}
	final boolean isSign() {
		return ((c == '+') || (c == '-'));
	}
	final boolean isDigit() {
		return (('0' <= c) && ('9' >= c));
	}		


	final void skip() throws SimpleParseException {
		try{
			c=is.BeginToken();
				while (((c == ' ') || (c == '\n') || (c == '\r'))) {
                  			c=is.readChar(); 	
				}
			is.backup(1);
                	c=is.BeginToken();
		} 
		catch(java.io.IOException e){fini=true;}
	}


	

        final boolean BracketLeft() throws SimpleParseException  {
		if (c != '(') { return false; }
        	else { skip(); return true;}
	}

	final void BracketRight() throws SimpleParseException  {
		if (c != ')') throw new SimpleParseException("Line:" + is.getEndLine() + ".Column:"+ is.getEndColumn() + ". Encountered  "+ c + ". Closing Bracket expected");
		skip();
	}

	final boolean Arrow() throws SimpleParseException {
		if (c == '<') {
                    try{d=is.readChar();} catch(java.io.IOException e){throw new SimpleParseException("Line:" + is.getEndLine() + ".Column:"+ is.getEndColumn() + ". Encountered  "+ d + ". Unexpected End of File");}
                    if(d == '-') {skip(); return true;}
		    else {is.backup(1); return false;}	}	
		else return false;
	}


	
	final String Identifier() throws SimpleParseException {
		if (!isLetter()) throw new SimpleParseException("Line:" + is.getEndLine() + ".Column:"+ is.getEndColumn() + ". Encountered  "+ c + ". Letter expected");
		while (isLetter() || isDigit()) {
			//System.out.print(c);
			 try{c=is.readChar();} catch(java.io.IOException e){throw new SimpleParseException("Line:" + is.getEndLine() + ".Column:"+ is.getEndColumn() + ". Encountered  "+ c + ". Unexpected End of File");}
                }
                is.backup(1);
		String s=is.GetImage();
		skip();	
                return s;		
	}

	final double Zahl() throws SimpleParseException {
		Double zahl;
		String s;
		// Vorkommateil
		if (isSign()) {
			try{c=is.readChar();} catch(java.io.IOException e){throw new SimpleParseException("Line:" + is.getEndLine() + ".Column:"+ is.getEndColumn() + ". Encountered  "+ c + ". Unexpected End of File");}

			if (!isDigit()) throw new SimpleParseException("Line:" + is.getEndLine() + ".Column:"+ is.getEndColumn() + ". Encountered  "+ c + ". digit expected");
		}	
		while (isDigit()) {try{c=is.readChar();} catch(java.io.IOException e){throw new SimpleParseException("Line:" + is.getEndLine() + ".Column:"+ is.getEndColumn() + ". Encountered  "+ c + ". Unexpected End of File");}
		}
		// Nachkommateil
		if (c == '.') {
			try{c=is.readChar();} catch(java.io.IOException e){throw new SimpleParseException("Line:" + is.getEndLine() + ".Column:"+ is.getEndColumn() + ". Encountered  "+ c + ". Unexpected End of File");}
			while (isDigit()) {try{c=is.readChar();} catch(java.io.IOException e){throw new SimpleParseException("Line:" + is.getEndLine() + ".Column:"+ is.getEndColumn() + ". Encountered  "+ c + ". Unexpected End of File");}}
		}
		// Exponent
		if ((c == 'e') || (c == 'E')) {
			try{c=is.readChar();} catch(java.io.IOException e){throw new SimpleParseException("Line:" + is.getEndLine() + ".Column:"+ is.getEndColumn() + ". Encountered  "+ c + ". Unexpected End of File");}
			if (!isSign() && !isDigit()) throw new SimpleParseException("Line:" + is.getEndLine() + ".Column:"+ is.getEndColumn() + ". Encountered  "+ c + ". +,- or digit expected");
			else {
				if (isSign()) {
					try{c=is.readChar();} catch(java.io.IOException e){throw new SimpleParseException("Line:" + is.getEndLine() + ".Column:"+ is.getEndColumn() + ". Encountered  "+ c + ". Unexpected End of File");}
					if (!isDigit()) throw new SimpleParseException("Line:" + is.getEndLine() + ".Column:"+ is.getEndColumn() + ". Encountered  "+ c + ". digit expected");
				}
				while (isDigit()) {try{c=is.readChar();} catch(java.io.IOException e){throw new SimpleParseException("Line:" + is.getEndLine() + ".Column:"+ is.getEndColumn() + ". Encountered  "+ c + ". Unexpected End of File");}}
			}
		}
		is.backup(1);
		s = is.GetImage();
		try {
			zahl = new Double(s);
		}
		catch (NumberFormatException p) {
			throw new SimpleParseException("Line:" + is.getEndLine() + ".Column:"+ is.getEndColumn() + ". Encountered  "+ c + ". number expected");
		}
		skip();	
		return zahl.doubleValue();
	}
	
	final String Zeichenkette() throws SimpleParseException {
		String s;
		try{c=is.BeginToken();} catch(java.io.IOException e){throw new SimpleParseException("Line:" + is.getEndLine() + ".Column:"+ is.getEndColumn() + ". Encountered  "+ c + ". Unexpected End of File");}
		while (c != '"') try{c=is.readChar();} catch(java.io.IOException e){throw new SimpleParseException("Line:" + is.getEndLine() + ".Column:"+ is.getEndColumn() + ". Encountered  "+ c + ". Unexpected End of File");}
		is.backup(1);
		s = is.GetImage(); 
                try{c=is.readChar();} catch(java.io.IOException e){throw new SimpleParseException("Line:" + is.getEndLine() + ".Column:"+ is.getEndColumn() + ". Encountered  "+ c + ". Unexpected End of File");}
		skip();
		return s;
	}
					
	final void Punkt() throws SimpleParseException {
		if (c != '.') throw new SimpleParseException("Line:" + is.getEndLine() + ".Column:"+ is.getEndColumn() + ". Encountered  "+ c + ". Point expected");
		skip();
	}

	final Variable Variable() throws SimpleParseException {
		Variable v;
		String 	s = Identifier();
		Integer k = (Integer) varmap.get(s);
		if(k==null) {
			k=new Integer(vars);
			vars++;
			varmap.put(s,k);
			if(query) { 
				Vars.addElement(s);
				Nums.addElement(k);
			}
		}	
		return new Variable(k.intValue());
	}

	final Term Term() throws SimpleParseException {
		Term t = null;
		String s;
		int code;
		Term[] args;
		if (isUppercaseletter()) 
			return Variable();
		else if (isLetter()) {
			s = Identifier();
			if (c == '(') {
				skip();
				args = ParameterList(); 
				BracketRight();
				code=FSymbols.searchAndInsert(s,args.length);
				return new ConstTerm(code,args);
			}
			else {  code=FSymbols.searchAndInsert(s,0);
				return new ConstTerm(code);
				}
		}
		else if (isDigit() || isSign()) {
			return new NumTerm(Zahl());
		}
		else if (c == '"') {		  
                          //t = new StringTerm(Zeichenkette());
		          code = Strings.searchAndInsert(Zeichenkette());
			  return  new ConstTerm(code+Config.STRINGSTART);
		}
		else throw new SimpleParseException("Line:" + is.getEndLine() + ".Column:"+ is.getEndColumn() + ". Encountered  "+ c + ". Variable, Constant, Function, Number or String expected");	
	}

	final Term[] ParameterList() throws SimpleParseException {
		Term[] t;
		Vector Param = new Vector(5,2);
		Param.addElement(Term());
		while (c == ',') {
			skip();
			Param.addElement(Term());
		}
		t=new Term[Param.size()];
		Param.copyInto(t);
		return t;
	}
/*
	Body BodyTermList(int sym, boolean neg) throws SimpleParseException {
		Body b;
		int anzterms = 0,i;
		Term terms[];	Term Terme[] = new Term[50];
		while (c != ')') {
			Terme[anzterms] = Term(); anzterms++;
			if (c == ',')
				skip();
		}
		// skip();
		terms = new Term[anzterms];
		for (i = 0; i < anzterms; i++)
			terms[i] = Terme[i];
		switch (sym) {
			case 0: b = new BuiltinBody(sym,neg,terms,new Add()); break;
			case 1: b = new BuiltinBody(sym,neg,terms,new Concat()); break;
			case 2: b = new BuiltinBody(sym,neg,terms,new isString()); break;
			case 3: b = new BuiltinBody(sym,neg,terms,new isNum()); break;
			case 4: b = new BuiltinBody(sym,neg,terms,new isConst()); break;
			case 5: b = new BuiltinBody(sym,neg,terms,new Evaluable()); break;

			default: b = new Body(sym,neg,terms);
		}
		return b;
	}
*/
	final Body BodyAtom() throws SimpleParseException {
		Term [] args;
		String s;
		int code;
		Body b = null;
		boolean neg = false;
		if (c == '-') {
			neg = true;
			skip();
		}
		s = Identifier();
			if (c == '(') {
				skip();
				args = ParameterList(); 
				BracketRight();
				code=PSymbols.searchAndInsert(s,args.length);
				if(code < BuiltinConfig.getBuiltinNumber())
					b = new BuiltinBody(code,neg,args,BuiltinConfig.newInstance(code));
				else
					b = new Body(code,neg,args);
					
			}
			else {  code=PSymbols.searchAndInsert(s,0);
				if(code <  BuiltinConfig.getBuiltinNumber())
					b = new BuiltinBody(code,neg,new Term[0],BuiltinConfig.newInstance(code));
				else
					b = new Body(code,neg,new Term[0]);
			}
		return b;
	}

	final Atom HeadAtom(boolean first) throws SimpleParseException {
		Term [] args;
		String s = Identifier();
			if (c == '(') {
				skip();
				args = ParameterList(); 
				BracketRight();
				atomsymbol=PSymbols.searchAndInsert(s,args.length);
				if(first && c=='.' && vars==0) return new Atom(args);
				else return new Head(atomsymbol,args);
			}
			else {  atomsymbol=PSymbols.searchAndInsert(s,0);
				if(first && c=='.' && vars==0) return new Atom (new Term[0]);
				else return new Head(atomsymbol,new Term[0]);
				}

	}


	final Body [] BodyKonjunktion() throws SimpleParseException {
		Body ruempfe[];
		Vector Bodies = new Vector(10,5);
		Bodies.addElement(BodyAtom());
		while (c == '&') {
			skip();
			Bodies.addElement(BodyAtom());
		}
		ruempfe = new Body[Bodies.size()];
		Bodies.copyInto(ruempfe);
		return ruempfe;	
	}
	final void HeadKonjunktion() throws SimpleParseException {
		Heads.addElement(HeadAtom(true));
		while (c == '&') {
			skip();
			Heads.addElement(HeadAtom(false));
		}
	}
	final void Rule() throws SimpleParseException {
		
		varmap.clear();
		vars = 0;
		query = false;
	
		if (Arrow()) {
			query = true;	
			Vars= new Vector(); 
			Nums= new Vector();
			Body[] bodies = BodyKonjunktion();
			Rule r = new Rule(null,bodies);
			RS.AddRule(r);
			engine.Names.put(r,Vars);
			engine.Numbers.put(r,Nums);
			Punkt();
		}		
		else {
			HeadKonjunktion();  
			if (Arrow()) {
				Body[] bodies = BodyKonjunktion();
				Head[] heads = new Head[Heads.size()];
				Heads.copyInto(heads);	
				Heads.removeAllElements();
				Rule r = new Rule(heads,bodies);
				RS.AddRule(r);
				Punkt();
			}
			else if (vars > 0 || Heads.size() > 1) {
				Head[] heads = new Head[Heads.size()];
				Heads.copyInto(heads);
				Heads.removeAllElements();	
				Rule r = new Rule(heads,null);
				RS.AddRule(r);
				Punkt();
			}
			else {
				//r = new Rule(heads,null);
				//RS.AddRule(r);
				  RS.AddFact(atomsymbol,(Atom) Heads.elementAt(0));
				Heads.removeAllElements();
				Punkt();
			}
		}
	}
	final public void compile() throws SimpleParseException{
			RS=engine.RS;
			FSymbols=engine.FSymbols;
			PSymbols=engine.PSymbols;
			Strings=engine.Strings;
		        skip();
			while (!fini) { 
				Rule();
			}
			is.Done();
		}
	
	}
		
