/*

Name: AVLTreeString.java

Version: 1.0

Purpose:

History:

*/

package edu.unika.aifb.inference;

import java.io.*;
import java.util.*;
import java.net.*;


class AVLNodeString extends AVLNode {
	public String s;
        public int i;
	public AVLNodeString(String s) {super(); this.s = s; i=-1;}
	public void print() {		
		System.out.print(i); System.out.print(" \""); System.out.print(s); System.out.print("\""); 
	}
	public void write(RandomAccessFile f) throws IOException {		
		f.writeBytes(String.valueOf(i)); f.writeBytes(" "); f.writeBytes(String.valueOf(s.length())); f.writeBytes(" "); f.writeBytes(s); 
	}
}


public class AVLTreeString extends AVLTree {
		private DynamicVector nodes;
                private AVLNodeString pre;
		
		public void write(RandomAccessFile f) throws IOException {
			int i;
			AVLNodeString a;
			for (i = 0; i < nodes.size(); i++) {
				a = (AVLNodeString)nodes.elementAt(i);
				a.write(f);  f.writeBytes("\n");
			}
		}

		public AVLTreeString() {
			super(false); // no duplicates
			nodes = new DynamicVector();
                        pre = new AVLNodeString("");
		}
		protected int praed(AVLNode t1, AVLNode t2) {
			int i = ((AVLNodeString)t1).s.compareTo(((AVLNodeString)t2).s);
			if(i>0) return 1;
                        else if(i<0) return -1;
                        return 0;			
		}
		protected boolean equal(AVLNode t1, AVLNode t2) {
	        	 return ((AVLNodeString)t1).s.equals(((AVLNodeString)t2).s);
		}

                public int search(String s){
		  pre.s=s;
		  AVLNodeString r= (AVLNodeString) Search(pre);
                  if(r==null) return -1; else return r.i;     
                }


                public int searchAndInsert(String s){
			  pre.s=s;
			  AVLNodeString n= new AVLNodeString(s);
			  n= (AVLNodeString) Insert(n);
                          if(n.i==-1) {n.i=nodes.size(); nodes.addElement(n);
                                       //System.out.println(nodes.size());
			  }
                          return n.i;
	                }
                public String getContent(int i)
                { return ((AVLNodeString) nodes.elementAt(i)).s;}


public static void main(String  argv[])
{
 AVLTreeString t= new AVLTreeString();
 System.out.println(t.searchAndInsert("a"));
 System.out.println(t.searchAndInsert("b"));
 System.out.println(t.searchAndInsert("c"));
 System.out.println(t.searchAndInsert("d"));
 System.out.println(t.searchAndInsert("e"));
 System.out.println(t.searchAndInsert("a"));
 System.out.println(t.searchAndInsert("c"));
 System.out.println(t.searchAndInsert("e"));
 System.out.println(t.getContent(1));
System.out.println(t.getContent(2));
System.out.println(t.getContent(3));
System.out.println(t.getContent(4));
}
				
}
