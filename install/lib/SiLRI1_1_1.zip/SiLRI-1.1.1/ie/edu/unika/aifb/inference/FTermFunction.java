/*

Name: FTermFunction.java

Version: 1.01

Purpose: 
Represents general logic program function terms

History:
3.5.99 created from FNode.java
*/

package edu.unika.aifb.inference;
import java.util.*;
import java.lang.*;
import java.io.*;


public class FTermFunction extends FTerm {
FTerm[] Arguments;
String Symbol;

FTermFunction(String Sym, FTerm[] Args){ 
	Symbol = Sym;
	Arguments = Args;
}

public String getSymbol(){
	return Symbol;
}

public FTerm[] getArguments(){
	return Arguments;
}






final public Term toTerm(Hashtable mapping,IntWrapper varcount,AVLTreeSymbol Symbols, AVLTreeString Strings)
 { 
   int arity = Arguments.length;
   int k=Symbols.searchAndInsert(Symbol,arity);
   Term[] t = new Term[arity];
   for(int l = 0;l< arity ; l++) 
     { t[l] = Arguments[l].toTerm(mapping,varcount,Symbols, Strings); }
   return new ConstTerm(k,t);

}
   

final public String toString()
   { String result = Symbol;
       if((Arguments!=null)&&(Arguments.length>0))
        {  
           int k = Arguments.length;
           result = result.concat("(");
           for(int i=0; i< k; i++) 
		{
           result=result.concat(Arguments[i].toString());
           if(i< k-1) result = result.concat(",");
                            }
         result = result.concat(")");
       }

     return result;
}


final public String toXSB()
   { String result = "f_" + Symbol;
       if((Arguments!=null)&&(Arguments.length>0))
        {  
           int k = Arguments.length;
           result = result.concat("(");
           for(int i=0; i< k; i++) 
		{
           result=result.concat(Arguments[i].toXSB());
           if(i< k-1) result = result.concat(",");
                            }
         result = result.concat(")");
       }

     return result;
}


final public String toSimple()
   { String result = "f_" + Symbol;
       if((Arguments!=null)&&(Arguments.length>0))
        {  
           int k = Arguments.length;
           result = result.concat("(");
           for(int i=0; i< k; i++) 
		{
           result=result.concat(Arguments[i].toSimple());
           if(i< k-1) result = result.concat(",");
                            }
         result = result.concat(")");
       }

     return result;
}

FTerm copyTerm(Hashtable h)
{ FTermFunction copy;
  FTerm[] NewArguments; 
   if((Arguments!=null) && (Arguments.length>0)) 
   { 
    int k = Arguments.length;
    NewArguments = new FTerm[k];
      for(int i=0; i< k; i++)
         NewArguments[i] = Arguments[i].copyTerm(h);
    }
                
   else NewArguments = new FTerm[0];
   copy = new FTermFunction(Symbol,NewArguments); 
   return copy;
 }

final FTerm copyTerm()
{  FTerm[] NewArguments; 
   if((Arguments!=null) && (Arguments.length>0)) 
   { 
    int k = Arguments.length;
    NewArguments = new FTerm[k];
      for(int i=0; i< k; i++)
         NewArguments[i] = Arguments[i].copyTerm();
    }
                
   else NewArguments = new FTerm[0];
   return new FTermFunction(Symbol,NewArguments); 
 }





final void FreeBoundVariables(Vector Free,Vector Bound)
{ 
   if((Arguments!=null) && (Arguments.length>0)) 
     { 
       int k = Arguments.length;
       for(int i=0; i< k; i++)
           Arguments[i].FreeBoundVariables(Free,Bound);
      }
              
 }     
 
}
