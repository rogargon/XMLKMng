/*

Name: RuleAtom.java

Version: 1.0

Purpose:

History:

*/

package edu.unika.aifb.inference;

import java.io.*;
import java.util.*;
import java.net.*;


public class RuleAtom extends Atom {
	Filter filter = null;
	public Atoms up = null;		// Substitutionen f�r die Variablen des Atoms
	public Atoms down = null;	// Substituierte Atome f�r Downpropagierung
	public Atoms adddown = null;	// inkrementelle Berechnung
	public Atoms addup = null;	// inkrementelle Berechnung
	public int symbol;		// Pr�dikatsymbol
	Rule rule = null;		// Verweis auf Regel
	RuleAtom next = null;		// Verzeigerung innerhalb von RuleSet
	RuleAtom last = null;		// Doppeltverzeigerung innerhalb von RuleSet
	Variable vars1[]; 		// index to the variables of the atom
	int vars2[];	  		// index to the symbols of the variables of the atom
	int vars3[];	  		// index is the symbol of the variable, content indicates column of the relation
	int index1[];	  		// indicates the join columns
	int index2[];	  		// indicates the join columns


	public RuleAtom(int sym, Term terme[]) {
		// sym = Pr�dikatsymbols, anz = Stelligkeit, terme = Feld mit Referenzen auf Terme
		super(terme);
		Variable v;
		symbol = sym;
		int j,i,max;
		vars1 = new Variable[anzvars+1];
		vars2 = new int[anzvars+1];
		index1 = new int[anzvars+1];
		for (v=variables, j=0; v !=null; v=v.next,j++) {
			vars1[j] = v;
			vars2[j] = v.symbol;
			index1[j] = -1;
		}
		vars1[j] = null;
		vars2[j] = -1;
		index1[j] = -1;
		max = -1;
		for (i = 0; i < anzvars; i++)
			if (max < vars2[i]) max = vars2[i];
		vars3 = new int[max+1];
		for (i = 0; i <= max; i++) vars3[i] = -1;
		for (i = 0; i < anzvars; i++)
			vars3[vars2[i]] = i;

	}

	public void ClearRuleAtom() {
		// L�schen der aufgesammelten Zwischenergebnisse
		up.Clear();
		addup.Clear();
		down.Clear();
		adddown.Clear();
	}


	public void print(PrintStream p) {
		int i;
		p.print("p"); p.print(symbol); 
		//System.out.print((char)((int)('p')+symbol));
		p.print('('); super.print(p); p.print(')');
	}

	public void internalize(PrintStream p) {
		//f.writeBytes("p"+String.valueOf(symbol));
		// System.out.print("p"); System.out.print(symbol); 
		p.print("p"+String.valueOf(symbol));
		super.internalize(p);
	}
	
/*
	public void print(int anzvars) {
		int i;
		Variable v;
		System.out.print((char)((int)('p')+symbol));
		System.out.print('('); super.print(); System.out.print(')');
		System.out.print("  Variables: ");
		for (v=variables; v != null; v= v.next) {
			System.out.print(v.symbol); System.out.print(" ");
		}
		System.out.print(" vars2: ");
		for (i = 0; i < vars2.length; i++) {
			System.out.print(vars2[i]);  System.out.print(' ');
		}
		System.out.print(" vars3: ");
		for (i = 0; i < vars3.length; i++) {
			System.out.print(vars3[i]);  System.out.print(' ');
		}
	}
*/
}






