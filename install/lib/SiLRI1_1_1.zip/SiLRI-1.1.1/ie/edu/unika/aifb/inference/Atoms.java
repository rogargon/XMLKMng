/*

Name: Atoms.java

Version: 1.0

Purpose:

History:

*/



package edu.unika.aifb.inference;

import java.io.*;
import java.net.*;

class Time {
	// Uhr f�r die Zeitstempel der Tupel
	private static long timestamp = 0;

	public static long getTime() {
		timestamp++;
		return timestamp-1;
	}
}

		
class AVLNodeT extends AVLNode {
	public GroundAtom tuple;
	public AVLNodeT(GroundAtom t) {super(); tuple = t;}
	public void print(PrintStream p) {
		//if (tuple != null) tuple.print(p);
		//else System.out.print("null");
		//System.out.print(" ");
	}
	public void print() {
		//if (tuple != null) tuple.print();
		//else System.out.print("null");
	}
}
	
class AVLTreeT extends AVLTree {
		private int index[] = null;
		public AVLTreeT(boolean dups, int ind[]) {
			super(dups);
			index = ind;
		}
		protected int praed(AVLNode t1, AVLNode t2) {
			int i = 0;
			int res = 0;
		    	while ((index[i] != -1) && (res == 0)) {
	           		res = ((AVLNodeT)t1).tuple.Compare(index[i],((AVLNodeT)t2).tuple,index[i]);
	            		i++;
	        	}
	        	return res; 			
		}
		protected boolean equal(AVLNode t1, AVLNode t2) {
	        	if (((AVLNodeT)t1).tuple == ((AVLNodeT)t2).tuple) 
	            		return true;
	        	else
	            		return false;
		}
	}
				
class IndexNode {
		protected int svec[];
		protected int stellen = 0;
		protected int anzstellen = 0;
		protected IndexNode next;
		protected AVLTree avl;
		
		protected IndexNode(int index[], boolean dups) {
			int i;
			stellen = 0;
			for (i = 0; index[i] != -1; i++) stellen |= (1 << index[i]);
			svec = index;
			anzstellen = i;
			avl = new AVLTreeT(dups,index);
			next = null;
		}
		protected void ClearIndex() {
			avl.ClearTree();
		}
	}
	
class Keller {
		int pg;
		int size;
		AVLNodeT k[];
		protected Keller(int max) {
			k = new AVLNodeT[max+1];
			size = max;
			pg = 0;
			}
		protected void Copy(Keller kel) {
			int i;
			for (i = 0; i <= kel.pg; i++) k[i] = kel.k[i];
			pg = kel.pg;
			}
		}	

abstract class Operation {
	public Atoms R1,R2;
	public Atoms D;
	public int index1[], index2[];
	protected Keller k1 = null;
	public long timestamp;
	public int dindex1[];
	public int dindex2[];
	protected Keller k2 = null, k3 = null;
	public Atom T;
	public boolean debug = false;
	
	protected void op(GroundAtom t1, GroundAtom t2) {}
	protected int compare(AVLNodeT t1, int index1[], AVLNodeT t2, int index2[]) {return 0;}	
	
	
	protected int down(Keller k, int index1[], AVLNodeT t2, int index2[]) {
		int praed = 0;
		int pegel;
		int res = 0;
		if (k.k[k.pg] == null)
			return -3;
		else {
			praed = compare(k.k[k.pg],index1,t2,index2);
			pegel = k.pg;
			switch (praed) {
				case 0: return 0;
				case -1: k.k[k.pg] = (AVLNodeT)k.k[k.pg].rechts; res = down(k,index1,t2,index2);
						 break;
				case 1: k.k[k.pg+1] = (AVLNodeT)k.k[k.pg].links; k.pg++; res = down(k,index1,t2,index2); 
						if ((res != 0) && (res != 1)) { 
						 	k.pg = pegel; res = 1;
						 }
						break;
				case 2: k.k[k.pg+1] = (AVLNodeT)k.k[k.pg].links; k.pg++; 
						res = down(k,index1,t2,index2);
						if (res!= 0) {k.pg = pegel; res = 0;}
						break;
				case -2: k.k[k.pg+1] = (AVLNodeT)k.k[k.pg].links; k.pg++; res = down(k,index1,t2,index2);
						if (res != 0) {
							k.pg = pegel;
							k.k[k.pg] = (AVLNodeT)k.k[k.pg].rechts; res = down(k,index1,t2,index2);
						}
						break;
			}
			return res;
		}
	}
				
    protected void next(Keller k) {
        AVLNodeT t;
        k.k[k.pg] = (AVLNodeT)k.k[k.pg].rechts;
        if (k.k[k.pg] == null) k.pg--;
        else {
            while (k.k[k.pg] != null) {
                k.k[k.pg+1] = (AVLNodeT)k.k[k.pg].links;
                k.pg++;
            }
            k.pg--;
        }
    } 
 				
	protected void right(Keller k, int index1[], AVLNodeT t2, int index2[]) {
		int praed = 0;
		int pegel;
		
		next(k);
		while ((k.pg > 0) && ((praed = compare(k.k[k.pg-1],index1,t2,index2)) == -1))
			k.pg--;
		if (praed == -1) {
			pegel = k.pg;
			k.k[k.pg] = (AVLNodeT)k.k[k.pg].rechts;
			if (down(k, index1, t2, index2) == -3)
				k.pg = pegel-1;
		}
	}	  
	  
   
    protected void first(Keller k, Atoms R, IndexNode ix) {
        k.pg = 0;
        k.k[0] = (AVLNodeT)ix.avl.Top();
        while (k.k[k.pg] != null) {
            k.k[k.pg+1] = (AVLNodeT)k.k[k.pg].links;
            k.pg++;
        }
        k.pg--;
    }  
}


class SearchOperation extends Operation{

	protected AVLNodeT a = new AVLNodeT(null);
	
	protected void search(AVLNodeT a, AVLNode tree) {
		AVLNode t;
		if (tree != null) {
        		switch (compare((AVLNodeT)tree,index1,a,index2)) {
           			case 1     : search(a,tree.links); break;
           			case -1    : search(a,tree.rechts); break;
           			case 0     : for (t = tree; t != null; t = t.mitte) 
           						if (!((AVLNodeT)t).tuple.deleted) op(((AVLNodeT)t).tuple,a.tuple); 
           					 break;
           			case 2	   : for (t = tree; t != null; t = t.mitte) 
           					if (!((AVLNodeT)t).tuple.deleted) op(((AVLNodeT)t).tuple,a.tuple);
           					 	search(a,tree.links); search(a,tree.rechts); break;
           			case -2	   : search(a,tree.links); search(a,tree.rechts); break;
       	 		}
    		}
	}


	public void Search(GroundAtom t) {
		a.tuple = t;
		search(a,(AVLNode)R1.indices.avl.Top());
    }
}


class Enumeration extends Operation {
	AVLNodeT first=null,last=null;

	public GroundAtom Enum() {
		if (k1 == null) k1 = new Keller(40);
		first(k1,R1,R1.indices);
		while ((k1.pg >= 0) && k1.k[k1.pg].tuple.deleted) {
			 next(k1);
		}
			if (k1.pg >= 0) return k1.k[k1.pg].tuple;
		else return null;
	}	

    
	public GroundAtom EnumNext() {
		next(k1);
    		while ((k1.pg >= 0) && k1.k[k1.pg].tuple.deleted) {
    			next(k1);
    		}
  		if (k1.pg >= 0) return k1.k[k1.pg].tuple;
    		else {
    			//R1.DeleteTuples();		
			return null;
		}
    	}	
	
	
	public void enumerate(AVLNodeT t) {
		if(t.links != null) enumerate((AVLNodeT)t.links);
		if (!t.tuple.deleted) 
			op(t.tuple,null);
		if (t.rechts != null) enumerate((AVLNodeT)t.rechts);
	}
	    	        
	public void Enumerate() {
		AVLNodeT t;
		t = (AVLNodeT)R1.indices.avl.Top();	
		if (t != null) enumerate(t);
		// R1.DeleteTuples();		
	}


	void queue(AVLNodeT t) {
		if (t != null) {
			last.mitte = t;
			last = t;
			t.mitte = null;
		}
	}
	AVLNodeT head() {
		AVLNodeT t;
		if (first == null) return null;
		else {
			t = first;
			queue((AVLNodeT)t.links); queue((AVLNodeT)t.rechts);
			first = (AVLNodeT)first.mitte;
			if (first == null) last = null;
			t.mitte = null;
			return t;
		}
	}
				
	public GroundAtom Enum1() {
		AVLNodeT t;
		GroundAtom a = null;
		t = (AVLNodeT)R1.indices.avl.Top();
		if (t != null) { 
			first = last = t; t.mitte = null;
			a = EnumNext1();
		}	
		if (a != null) return a;
		else return null;
	}	

    
	public GroundAtom EnumNext1() {
		AVLNodeT t;
		t = head();
		while ((t != null) && (t.tuple.deleted)) 
			t = head();
		if (t != null) return t.tuple;
		else return null;
    	}	
	
}


class NonGroundOperation extends Operation{
	    		        			    	    	    
	public void Operate() {
		IndexNode ix1, ix2;
		// GroundAtom t;
		AVLNodeT b1,b2;
		int praedikat;
		
		if ((R1.anztuples > 0) && (R2.anztuples > 0)) {

		    ix1 = R1.getindex(index1);
		    ix2 = R2.getindex(index2);

		    if (k1 == null) k1 = new Keller(40);
		    if (k2 == null) k2 = new Keller(40);
	   	    if (k3 == null) k3 = new Keller(40);		   	
	            first(k1,R1,ix1);
	            first(k2,R2,ix2);	        
	            while ((k1.pg >= 0) && (k2.pg >= 0)) {
	   		praedikat = compare(k1.k[k1.pg],index1,k2.k[k2.pg],index2);
	        	if (praedikat == 0) {		        	
			      	b1 = k1.k[k1.pg];
	                	do {
	                    		b2 = k2.k[k2.pg];
	                    		do {
	                        		if (!b1.tuple.deleted && !b2.tuple.deleted) op(b1.tuple,b2.tuple);
	                        		b2 = (AVLNodeT)b2.mitte;
	                    		} while (b2 != null);
	                    		b1 = (AVLNodeT)b1.mitte;
	                	} while (b1 != null); 
	                	next(k1);
	                	next(k2);
	            	}
	        	else if ((praedikat == 2)  || (praedikat == -2)) {		        	
	            		k3.Copy(k2);
	            		do {
	            			do {
						if ((praedikat == 0) || (praedikat == 2)) {
				                	for(b1 = k1.k[k1.pg];b1 != null; b1 = (AVLNodeT)b1.mitte) {
				                    		for(b2 = k2.k[k2.pg]; b2 != null;b2 = (AVLNodeT)b2.mitte) {
				                            		if (!b1.tuple.deleted && !b2.tuple.deleted) op(b1.tuple,b2.tuple);
				                    		}
				                	}
				       		}
			                	next(k2);
			        	} while ((k1.pg >= 0) && (k2.pg >= 0) && (((praedikat = compare(k1.k[k1.pg],index1,k2.k[k2.pg],index2)) == 0) || (praedikat == 2) || (praedikat == -2)));
			        	next(k1); k2.Copy(k3);
			 	} while ((k1.pg >= 0) && (k2.pg >= 0) && (((praedikat = compare(k1.k[k1.pg],index1,k2.k[k2.pg],index2)) == 2) || (praedikat == -2)));	         
	            	}
	            	else if (praedikat == -1) {
	            		// System.out.println("right left");
	                	right(k1,index1,k2.k[k2.pg],index2);
				// next(k1);
			}
	            	else {
	            		// System.out.println("right right");
	                	right(k2,index2,k1.k[k1.pg],index1);}
	            	}
	       	}
	}		
}


class GroundOperation extends Operation {
	    		        			    	    	    
	public void Operate() {
		IndexNode ix1, ix2;
		// GroundAtom t;
		AVLNodeT b1,b2;
		int praedikat;

	    	if ((R1.anztuples > 0) && (R2.anztuples > 0)) {
		    ix1 = R1.getindex(index1);
		    ix2 = R2.getindex(index2);
		    if (k1 == null) k1 = new Keller(40);
		    if (k2 == null) k2 = new Keller(40);
	   	    if (k3 == null) k3 = new Keller(40);		   	
	            first(k1,R1,ix1); first(k2,R2,ix2);	        
	            while ((k1.pg >= 0) && (k2.pg >= 0)) {
	   		praedikat = compare(k1.k[k1.pg],index1,k2.k[k2.pg],index2);
	        	if (praedikat == 0) {		        	
			      	b1 = k1.k[k1.pg];
	                	do {
	                    		b2 = k2.k[k2.pg];
	                    		do {
	                        		if (!b1.tuple.deleted && !b2.tuple.deleted) op(b1.tuple,b2.tuple);
	                        		b2 = (AVLNodeT)b2.mitte;
	                    		} while (b2 != null);
	                    		b1 = (AVLNodeT)b1.mitte;
	                	} while (b1 != null); 
	                	next(k1);
	                	next(k2);
	            	}
	            	else if (praedikat == -1) {
	            		// System.out.println("right left");
	                	right(k1,index1,k2.k[k2.pg],index2);}
	            	else {
	            		// System.out.println("right right");
	                	right(k2,index2,k1.k[k1.pg],index1);}
	            	}
	       	    }
	  	}	
	}


class Index extends Enumeration {
	public IndexNode ix;
	protected void op(GroundAtom t, GroundAtom t2) {
		AVLNodeT a;
        	a = new AVLNodeT(t);
	    	ix.avl.Insert(a);
	}
}

/*
class Print extends Enumeration {
	protected void op(GroundAtom t1, GroundAtom t2) {
		t1.print(System.out); System.out.println();
	}
}
*/




class Join extends GroundOperation {
	protected int compare(AVLNodeT t1, int index1[], AVLNodeT t2, int index2[]) {
		int i = 0;
		int res = 0;
	    	while ((index1[i] != -1) && (res == 0)) {
           		res = t1.tuple.Compare(index1[i],t2.tuple,index2[i]);
            		i++;
        	}
        	return res; 			
	}		
	protected  void op(GroundAtom t1, GroundAtom t2) {
		int i;
		GroundAtom t;
		GroundAtom ins;
		t = new GroundAtom(D.stellen);
		for (i = 0; i < R1.stellen; i++)
			if (dindex1[i] != -1) t.terms[dindex1[i]] = t1.terms[i]; // t.Copy(dindex1[i],t1,i);
		for (i = 0; i < R2.stellen; i++)
			if (dindex2[i] != -1) t.terms[dindex2[i]] = t2.terms[i]; //t.Copy(dindex2[i],t2,i);
		ins = D.Insert(t);
		if (ins != t) t = null;
		(t1).Supports(ins);
		(t2).Supports(ins);
		if (t1.lasttouched != timestamp) {
			t1.next2 = R1.tuples2;
			R1.tuples2 = t1;
			t1.lasttouched = timestamp;
		}
		if (t2.lasttouched != timestamp) {
			t2.next2 = R2.tuples2;
			R2.tuples2 = t2;
			t2.lasttouched = timestamp;
		}
	}
}

class Negation extends GroundOperation {
	protected int compare(AVLNodeT t1, int index1[], AVLNodeT t2, int index2[]) {
		int i = 0;
		int res = 0;
	    while ((index1[i] != -1) && (res == 0)) {
           	res = t1.tuple.Compare(index1[i],t2.tuple,index2[i]);
            i++;
        }
        return res; 			
	}		
	protected  void op(GroundAtom t1, GroundAtom t2) {
		(t2).negDependency(t1);
		if (t1.lasttouched < timestamp) {
			t1.next2 = R1.tuples2;
			R1.tuples2 = t1;
			t1.lasttouched = timestamp;
		}
		if (t2.lasttouched < timestamp) {
			t2.next2 = R2.tuples2;
			R2.tuples2 = t2;
			t2.lasttouched = timestamp;
		}
	}
}									


class NonGroundGroundAtomOp extends NonGroundOperation {
	int anzcmps = 0;
	//boolean flag;
	protected int cmp(Term t1, Term t2) {
		int i,res = 0;
		anzcmps++;
		if (t1.ground && t2.ground) 
			res = t1.Compare(t2);
		else if ((t1 instanceof Variable) || (t2 instanceof Variable)) 
			res = 2;
		else {
			if ((t1.type() != t2.type()) || (t1.anzpars != t2.anzpars)) {
				res = t1.CompareTypes(t2);
			}
			else {
				res = t1.CompareEqual(t2);
				if (res == 0) {
					for (i = 0; (i < t1.anzpars) && (res == 0); i++) 
						res = cmp(t1.pars[i],t2.pars[i]);
					if (res == 2) {
						for (; (i < t1.anzpars) && ((res ==2) || (res == 0)); i++)
							res = cmp(t1.pars[i],t2.pars[i]);
						if ((res == 2) || (res == 0)) return 2;
						else return -2;
					}
					else return res;
				}
			}
		}
		return res;
	}								
	protected int compare(AVLNodeT t1, int index1[], AVLNodeT t2, int index2[]) {
		int i = 0, res = 0;
		for(i = 0; (i < R1.stellen) && (res == 0); i++) {
           		res = cmp(((t1.tuple)).terms[i],((t2.tuple)).terms[i]);
        	}   	
   		if (res == 2) {
			for (; (i < R1.stellen) && ((res == 2) || (res == 0)); i++)
				res = cmp(((t1.tuple)).terms[i],((t2.tuple)).terms[i]);
			if ((res == 2) || (res == 0)) return 2;
			else return -2;
		}
		else return res;		
	}
}	


		
class Matching extends NonGroundGroundAtomOp {

	protected  void op(GroundAtom t1, GroundAtom t2) {
		int i;
		GroundAtom f;
		GroundAtom ins;
		Variable v;
		boolean res = true;
		boolean del;
		Atom t = (Atom)t1;
		res = t.Match(t2);
		if (res) {
			//flag = true;
			f = new GroundAtom(D.stellen);
			for(v = t.variables, i=0; v!= null; v=v.next,i++) 
				f.terms[i] = v.subsby;
			ins = D.Insert(f);
			t2.Supports(ins);
			if (ins == f) { 
				f.next2 = D.tuples2;
				D.tuples2 = f;
			}
		}
		for(v = t.variables, i=0; v!= null; v=v.next,i++) 
			v.subsby = null;
		if (t.lasttouched < timestamp) {
			t.next2 = R1.tuples2;
			R1.tuples2 = t;
			t.lasttouched = timestamp;
			}
		if (t2.lasttouched < timestamp) {
			t2.next2 = R2.tuples2;
			R2.tuples2 = t2;
			t2.lasttouched = timestamp;
			}
		}  
	}

class MatchJoin extends NonGroundGroundAtomOp {
							
	protected int compare(AVLNodeT t1, int index1[], AVLNodeT t2, int index2[]) {
		int i = 0, res = 0;
		anzcmps++;
		for(i = 0; (index1[i] != -1) && (res == 0); i++) {
	           	res = cmp(((t1.tuple)).terms[index1[i]],((t2.tuple)).terms[index2[i]]);
	        }   	
       		if (res == 2) {
				for (; (index1[i] != -1) && ((res ==2) || (res == 0)); i++)
						res = cmp(((t1.tuple)).terms[index1[i]],((t2.tuple)).terms[index2[i]]);
				if ((res == 2) || (res == 0)) return 2;
				else return -2;
		}
		else return res;		
	}

	protected  void op(GroundAtom t1, GroundAtom t2) {
			int i;
			Atom f;
			GroundAtom ins;
			Variable v;
			boolean res = true;
			boolean del;
			Atom t = (Atom)t1;
			if (t.variables == null)
				t.Variables();
			for (i = 0; (index1[i] != -1) && res; i++)
				res = t.terms[index1[i]].Match((t2).terms[index2[i]]) && res;
			if (res) {
				f = new Atom(D.stellen);
				for(i = 0; i < D.stellen; i++) f.terms[i] = null;
				for(i = 0; index1[i] != -1; i++)
					f.terms[index1[i]] = t2.terms[index2[i]];
				for(i = 0; i< t.terms.length; i++)
					if (f.terms[i] == null)
						f.terms[i] = t.terms[i];
				for(i = 0; i < dindex2.length; i++) {
					if (dindex2[i] != -1) {
						f.terms[dindex2[i]] = t2.terms[i];
						f.MarkVar(dindex2[i]);
					}
				}
				//f.mark = (t1).mark | (t2).mark;
				f.mark = t.mark;
				f.and = true;
				ins = D.Insert(f);
				t2.Supports(ins);
				if (ins == f) { 
					f.next2 = D.tuples2;
					D.tuples2 = f;
				}
			}
			t.ClearVariables();
			if (t.lasttouched < timestamp) {
				t.next2 = R1.tuples2;
				R1.tuples2 = t;
				t.lasttouched = timestamp;
				}
			if (t2.lasttouched < timestamp) {
				t2.next2 = R2.tuples2;
				R2.tuples2 = t2;
				t2.lasttouched = timestamp;
				}
			}  
	}

class MatchNegation extends NonGroundGroundAtomOp {							
	protected int compare(AVLNodeT t1, int index1[], AVLNodeT t2, int index2[]) {
		int i = 0, res = 0;
		for(i = 0; (index1[i] != -1) && (res == 0); i++) {
           		res = cmp(((t1.tuple)).terms[index1[i]],((t2.tuple)).terms[index2[i]]);
        	}   	
   		if (res == 2) {
			for (; (index1[i] != -1) && ((res ==2) || (res == 0)); i++)
					res = cmp(((t1.tuple)).terms[index1[i]],((t2.tuple)).terms[index2[i]]);
			if ((res == 2) || (res == 0)) return 2;
			else return -2;
		}
		else return res;		
	}

	protected  void op(GroundAtom t1, GroundAtom t2) {
		int i;
		// GroundAtom f;
		Variable v;
		boolean res = true;
		Atom t = (Atom)t1;
		if (t.variables == null)
			t.Variables();
		for (i = 0; index1[i] != -1; i++)
			res = t.terms[index1[i]].Match((t2).terms[index2[i]]);
		if (res) {
			if (t.lasttouched < timestamp) {
				t.next2 = R1.tuples2;
				R1.tuples2 = t;
				t.lasttouched = timestamp;
			}
			if (t2.lasttouched < timestamp) {
				t2.next2 = R2.tuples2;
				R2.tuples2 = t2;
				t2.lasttouched = timestamp;
			}
		}
		t.ClearVariables();
	}
}


class Filtering  extends NonGroundGroundAtomOp {
	protected int compare(AVLNodeT t1, int index1[], AVLNodeT t2, int index2[]) {
		int i = 0, res = 0;
		anzcmps++;
		for(i = 0; (index1[i] != -1) && (res == 0); i++) {
	           	res = cmp(((t1.tuple)).terms[index1[i]],((t2.tuple)).terms[index2[i]]);
	        }   	
       		if (res == 2) {
				for (; (index1[i] != -1) && ((res ==2) || (res == 0)); i++)
						res = cmp(((t1.tuple)).terms[index1[i]],((t2.tuple)).terms[index2[i]]);
				if ((res == 2) || (res == 0)) return 2;
				else return -2;
		}
		else return res;		
	}

	protected  void op(GroundAtom t1, GroundAtom t2) {
		int i;
		GroundAtom f;
		GroundAtom ins;
		Variable v;
		boolean res = true;
		boolean del;
		Atom t = (Atom)t1;
		res = t.Match(t2);
		t.ClearVariables();
		if (res) {
			res = T.Match(t2);
			if (res) {
				f = new GroundAtom(D.stellen);
				for(v = T.variables, i=0; v!= null; v=v.next,i++) 
					f.terms[i] = v.subsby;
				ins = D.Insert(f);
				t2.Supports(ins);
				if (ins == f) { 
					f.next2 = D.tuples2;
					D.tuples2 = f;
				}
			}
		}
		T.ClearVariables();
		if (t.lasttouched < timestamp) {
			t.next2 = R1.tuples2;
			R1.tuples2 = t;
			t.lasttouched = timestamp;
		}
		if (t2.lasttouched < timestamp) {
			t2.next2 = R2.tuples2;
			R2.tuples2 = t2;
			t2.lasttouched = timestamp;
		}
	}  
}	

class Filtering1  extends NonGroundGroundAtomOp {
	protected int compare(AVLNodeT t1, int index1[], AVLNodeT t2, int index2[]) {
		int i = 0, res = 0;
		anzcmps++;
		for(i = 0; (index1[i] != -1) && (res == 0); i++) {
//System.out.print(index1[i]); System.out.print("  "); System.out.println(index2[i]);
	           	res = cmp(((t1.tuple)).terms[index1[i]],((t2.tuple)).terms[index2[i]]);
	        }   	
       		if (res == 2) {
				for (; (index1[i] != -1) && ((res ==2) || (res == 0)); i++)
						res = cmp(((t1.tuple)).terms[index1[i]],((t2.tuple)).terms[index2[i]]);
				if ((res == 2) || (res == 0)) res = 2;
				else res = -2;
		}
/*
if (debug) {
	t1.print(); System.out.print("   "); t2.print(); System.out.print("   :"); System.out.println(res); 
}*/	
		return res;		
	}

	protected  void op(GroundAtom t1, GroundAtom t2) {
		int i;
		GroundAtom f;
		GroundAtom ins;
		Variable v;
		boolean res = true;
		boolean del;
		Atom t = (Atom)t1;
		res = t.Match(t2);
		t.ClearVariables();

		if (res) {
			ins = D.Insert(t2);
		}
		if (t.lasttouched < timestamp) {
			t.next2 = R1.tuples2;
			R1.tuples2 = t;
			t.lasttouched = timestamp;
		}
		if (t2.lasttouched < timestamp) {
			t2.next2 = R2.tuples2;
			R2.tuples2 = t2;
			t2.lasttouched = timestamp;
		}
	}  
}	


class Unification extends NonGroundGroundAtomOp {
	protected  void op(GroundAtom t1, GroundAtom t2) {
		int i;
		Atom f, ins;
		Variable v;
		boolean res = true;
		boolean del;
		Atom t1n = (Atom)t1;
		Atom t2n = (Atom)t2;
		res = (t1n).Unify(t2n);
		if (res) {
			f = new Atom(D.stellen);
			for(v = t1n.variables, i=0; v!= null; v=v.next,i++) 
				if (v.subsby != null)
					f.terms[i] = v.subsby;
				else
					f.terms[i] = v;
			ins = (Atom)D.Insert(f);
			del = ins.deleted;
			t2n.Supports(ins);
			if (ins == f) { 
				f.next2 = D.tuples2;
				D.tuples2 = f;
			}
		}
		t1n.ClearVariables();
		t2n.ClearVariables();
		if (t1n.lasttouched < timestamp) {
			t1n.next2 = R1.tuples2;
			R1.tuples2 = t1n;
			t1n.lasttouched = timestamp;
			}
		if (t2n.lasttouched < timestamp) {
			t2n.next2 = R2.tuples2;
			R2.tuples2 = t2n;
			t2n.lasttouched = timestamp;
			}
		}  
	}



class Generalization extends NonGroundGroundAtomOp {
	protected int compare(AVLNodeT t1, int index1[], AVLNodeT t2, int index2[]) {
		int i = 0, res = 0;
		for(i = 0; (index1[i] != -1) && (res == 0); i++) {
           		res = cmp(((t1.tuple)).terms[index1[i]],((t2.tuple)).terms[index2[i]]);
        	}   	
   		if (res == 2) {
			for (; (index1[i] != -1) && ((res ==2) || (res == 0)); i++)
					res = cmp(((t1.tuple)).terms[index1[i]],((t2.tuple)).terms[index2[i]]);
			if ((res == 2) || (res == 0)) return 2;
			else return -2;
		}
		else return res;		
	}

	protected  void op(GroundAtom t1, GroundAtom t2) {
		int i;
		Atom f,t, ins;
		Variable v;
		Atom t1n = (Atom)t1;
		Atom t2n = (Atom)t2;
		if (t1n != t2n) {
			t = t1n.Generalize(t2n);
			if (t != null) {
				ins = (Atom)D.Insert(t);
				if (ins == t) { 
					t.next2 = D.tuples2;
					D.tuples2 = t;
				}
				if (t1n.lasttouched < timestamp) {
					t1n.next2 = R1.tuples2;
					R1.tuples2 = t1n;
					t1n.lasttouched = timestamp;
				}
				if (t2n.lasttouched < timestamp) {
					t2n.next2 = R2.tuples2;
					R2.tuples2 = t2n;
					t2n.lasttouched = timestamp;
				}  
			} 
		}
	}
}

class Subsumption extends NonGroundGroundAtomOp {
	protected  void op(GroundAtom t1, GroundAtom t2) {
		int i;
		GroundAtom f,t;
		Variable v;
		boolean res = true;
		Atom t1n = (Atom)t1;
		Atom t2n = (Atom)t2;
		if (t1n != t2n) {
			res = (t2n).Match(t1n);
			if (res) {
				if (t1n.lasttouched < timestamp) {
					t1n.next2 = R1.tuples2;
					R1.tuples2 = t1n;
					t1n.lasttouched = timestamp;
				}
			}
			(t2n).ClearVariables();
		}
	}
}

class NonGroundSearchOp extends SearchOperation {
	//boolean flag;
	private int cmp(Term t1, Term t2) {
		int i,res = 0;
		if (t1.ground && t2.ground) res = t1.Compare(t2);
		else if ((t1 instanceof Variable) || (t2 instanceof Variable)) res = 2;
		else {
			res = t1.CompareTypes(t2);
			if (res == 0) {
				res = t1.CompareEqual(t2);
				if (res == 0) {
					for (i = 0; (i < t1.anzpars) && (res == 0); i++) 
						res = cmp(t1.pars[i],t2.pars[i]);
					if (res == 2) {
						for (; (i < t1.anzpars) && ((res ==2) || (res == 0)); i++)
							res = cmp(t1.pars[i],t2.pars[i]);
						if ((res == 2) || (res == 0)) return 2;
						else return -2;
					}
					else return res;
				}
			}
		}
		return res;
	}								
	protected int compare(AVLNodeT t1, int index1[], AVLNodeT t2, int index2[]) {
		int i = 0, res = 0;
		for(i = 0; (i < R1.stellen) && (res == 0); i++) {
           	res = cmp(((t1.tuple)).terms[i],((t2.tuple)).terms[i]);
        }   	
   		if (res == 2) {
			for (; (i < R1.stellen) && ((res ==2) || (res == 0)); i++)
					res = cmp(((t1.tuple)).terms[i],((t2.tuple)).terms[i]);
			if ((res == 2) || (res == 0)) return 2;
			else return -2;
		}
		else return res;		
	}
}

class Unify extends NonGroundSearchOp {
	protected void op(GroundAtom t1, GroundAtom t2) {
		int i;
		Atom f, ins;
		Variable v;
		boolean res = true, del;
		Atom T = (Atom)t2;
		Atom t = (Atom)t1;
		res = (T).Unify(t);		
		if (res) { // GroundAtome unifizierbar
			//Abspeichern der Substitutionen
			f = new Atom(D.stellen);
			for(v = (T).variables, i=0; v!= null; v=v.next,i++) 
				if (v.subsby != null)
					f.terms[i] = v.subsby.Substitute();
				else
					f.terms[i] = new Variable(v.symbol);
			ins = (Atom)D.Insert(f);
			(t).Supports(ins);
			if (ins == f) { 
				f.next2 = D.tuples2;
				D.tuples2 = f;
			}
		}
		// Variablensubstitutionen freigeben
		(T).ClearVariables();
		(t).ClearVariables();		
		// GroundAtom in Liste merken
		if (t.lasttouched < timestamp) {
			t.next2 = R1.tuples2;
			R1.tuples2 = t;
			t.lasttouched = timestamp;
		}
	}
}

class Match extends NonGroundSearchOp {
	protected void op(GroundAtom t, GroundAtom t2) {
		int i;
		GroundAtom f;
		GroundAtom ins;
		Variable v;
		boolean res = true, del;
		Atom T = (Atom)t2;
		res = (T).Match(t);
		if (res) {
			//flag = true;
			f = new GroundAtom(D.stellen);
			for(v = (T).variables, i=0; v!= null; v=v.next,i++) 
				if (v.subsby != null)
					f.terms[i] = v.subsby;
				else
					f.terms[i] = new Variable(v.symbol);
			ins = D.Insert(f);
			(t).Supports(ins);
			if (ins == f) { 
				f.next2 = D.tuples2;
				D.tuples2 = f;
			}
		}
		(T).ClearVariables();
		// (t).ClearVariables();
		if (t.lasttouched < timestamp) {
			t.next2 = R1.tuples2;
			R1.tuples2 = t;
			t.lasttouched = timestamp;
		}
	}
}

	

class Substitute extends Enumeration {
	Atom T;
	protected  void op(GroundAtom t, GroundAtom t2) {
		int i;
		GroundAtom f;
		GroundAtom ins;
		Variable v;
		boolean res = true;
		boolean del;
		for(v = (T).variables; v!= null; v=v.next) 
			if ((v.symbol < index1.length) && (index1[v.symbol] != -1) && (index1[v.symbol] < (t).terms.length))
				v.subsby = (t).terms[index1[v.symbol]];
		f = new GroundAtom(D.stellen);
		for(i = 0; i < D.stellen; i++) {
			f.terms[i] = T.terms[i].Substitute();
		}
		//f.Variables();
		ins = D.Insert(f);
		(t).Supports(ins);
		if (ins == f) { 
			f.next2 = D.tuples2;
			D.tuples2 = f;
		}
		(T).ClearVariables();
	}
}	



	
	
public class Atoms {

	public int anztuples = 0;
	public GroundAtom tuples2 = null;
	public GroundAtom tuples3 = null;
	public int stellen = 0;
	protected IndexNode indices = null;
	//private Print print = new Print();
	private Index indx = new Index();	
	public  Enumeration enum1 = new Enumeration();
	public static Enumeration enum2 = new Enumeration();
	public long lasttouched = 0;
	public long lastmodified = 0;	
	public long checktime = 0;					// Zeit auf die sich nachfolgende Zahlen bezieht
	public int added = 0;						// seit checktime neu hinzugekommen
	public int deleted = 0;						// seit checktime geloescht
	public int supported = 0;					// seit checktime schon enthaltene versucht einzufuegen
	public boolean modified = false;			// Relation seit checktime veraendert

	public float groundness[];
	public int matchindex[]; // 1:1 Abbildung der Spalten
			
	protected static Matching matching = new Matching();		
	protected static Join join = new Join();
	protected static Negation neg = new Negation();	
	protected static Unify uni = new Unify();
	protected static Match match = new Match();
	protected static Filtering filter = new Filtering();
	protected static Filtering1 filter1 = new Filtering1();
	protected static MatchJoin matchjoin = new MatchJoin();
	protected static MatchNegation matchneg = new MatchNegation();
	protected static Substitute subs = new Substitute();
	protected static Subsumption subsum = new Subsumption();
	protected static Generalization gen = new Generalization();

				

	public Atoms(int stelligkeit) {
	     int i;
	     int index[];
	     stellen = stelligkeit;
	     index = new int[stellen+1];
	     for (i = 0; i < stellen; i++)
	     	index[i] = i;
	     index[stellen] = -1;
	     indices = new IndexNode(index,false);
	     // print.R1 = this;
	     indx.R1 = this;
		matchindex = new int[stelligkeit+1];
		for (i = 0; i < stelligkeit; i++)
			matchindex[i] = i;
		matchindex[i] = -1;
		groundness = new float[stelligkeit];
	}


	protected IndexNode getindex(int s[]) {
	    int i = 0;
	    int set = 0;
	    int anz;
	    IndexNode l;
	    IndexNode ix = null;
	    GroundAtom t;
	    AVLNodeT a;

        for (i = 0; s[i] != -1; i++) set |= (1 << s[i]);
        anz = i;
        l = indices;
        while ((l != null) && (ix == null)) {
            if (set == l.stellen) {
                i = 0;
                while ((s[i] != -1) && (s[i] == l.svec[i])) i++;
                if (s[i] == l.svec[i]) ix = l;
            }
            l = l.next;
        }
        if (ix == null) {
           	ix = new IndexNode(s,true);
            indx.ix = ix;
            indx.Enumerate();
            ix.next = indices.next;
            indices.next = ix;
        }
        return ix;
	}		
	
			

	public void SetCheckTime() {
		// setzt checktime auf die aktuelle Zeit und setzt added und deleted zurueck
		checktime = Time.getTime();
		added = 0;
		deleted = 0;
		supported = 0;
		modified = false;
	}	

	
	public GroundAtom First() {
		enum1.R1 = this;
		return enum1.Enum();
	}
	
	public GroundAtom Next() {
		return enum1.EnumNext();
	}
				
	synchronized public void Union(Atoms R) {
		// vereinige this und die Relation R
		GroundAtom t;
		boolean inserted;
		enum1.R1 = R;
		this.tuples2 = null;
		for(t = enum1.Enum1(); t != null; t = enum1.EnumNext1()) 
			if (t == Insert(t)) {
				t.next2 = this.tuples2;
				this.tuples2 = t;
			}
	}	
	
	public void internalize(PrintStream p, int sym) {
		// vereinige this und die Relation R
		GroundAtom t;
		enum1.R1 = this;
		String s;
		for(t = enum1.Enum1(); t != null; t = enum1.EnumNext1()) {
			t.internalize(p,sym);
			// t.write(f,sym);
			p.println();
		}
	}	

	public void print(PrintStream p) {
		// vereinige this und die Relation R
		GroundAtom t;
		enum1.R1 = this;
		String s;
		for(t = enum1.Enum1(); t != null; t = enum1.EnumNext1()) {
			t.print(p);
			// t.write(f,sym);
			//f.writeBytes(s + ".\n");
			p.println();
		}
	}	

	public void print(PrintStream p, String pr[], String f[], String st[]) {
		// vereinige this und die Relation R
		GroundAtom t;
		enum1.R1 = this;
		String s;
		int i = 0;
		//System.out.print("Atoms.print"); System.out.print(":"); System.out.println(this.stellen);
		for(t = enum1.Enum1(); t != null; t = enum1.EnumNext1()) {
			// System.out.print(i); System.out.print(": ");
			// t.print(System.out,pr,f,st);
			t.print(p,pr,f,st);
			// t.write(f,sym);
			//f.writeBytes(s + ".\n");
			// System.out.print(" "); System.out.println(i); 
			//System.out.println(t.terms.length);
			p.println();
		}
	}	
	synchronized public void UnionSelected(Atoms R) {
		// von der Relation R werden die Tuple in this eingefuegt, die durch next2 verkettet sind
		// dabei wird die Selektion zerstoert
		GroundAtom t,t1;
		boolean inserted;
		this.tuples2 = null;
		t = R.tuples2; 
		while (t != null) {
			t1 = t.next2;
			if (!t.deleted && (t == Insert(t))) {
				t.next2 = this.tuples2;
				this.tuples2 = t;
			}
			t = t1;
		}
	}
		
	synchronized public void DeleteSelected() {
		// in der Relation this werden die Tuple gel�scht, die durch next2 verkettet sind
		// dabei wird die Selektion zerstoert
		GroundAtom t,t1;
		t = this.tuples2; 
		while (t != null) {
			t1 = t.next2;
			Delete(t);
			t = t1;
		}
	}


	public void clearRelation() {
		IndexNode l;
		anztuples = 0;
		for (l = indices; l != null; l = l.next)
			l.ClearIndex();
	}

	public boolean Compare(Atoms R) {
		// true, falls jedes Tupel in this auch in R vorkommt und umgekehrt
		GroundAtom t1, t2;
		int i, res = 0;
		enum1.R1 = this;
		enum2.R1 = R;	
		if (this.anztuples != R.anztuples) return false;
		for(t1 = enum1.Enum(), t2 = enum2.Enum(); t1 != null; t1 = enum1.EnumNext(),t2 = enum2.EnumNext()) {
			if (!t2.deleted && !t1.deleted && ((t2).CompareAtoms(t1) != 0)) 
				return false;
		}
		return true;
	}	
		
		
	public GroundAtom insert(GroundAtom t) {
		// gibt Tupel t zur�ck, falls Einf�gen erfolgreich
		// gibt Tupel b zur�ck, falls t nicht eingef�gt wurde, weil b bereits enthalten und b = t
	    AVLNodeT a,b;
	    IndexNode l;
	    long d;
		
		d = Time.getTime();
		a = new AVLNodeT(t);
		b = (AVLNodeT)indices.avl.Insert(a);
		// b = (AVLNodeT)indices.avl.Search(a);
		// if (indices.avl.Insert(a)) {
		//if (b == null) {
		if (b == a) {
			lastmodified = d;
			lasttouched = d;
			//indices.avl.Insert(a);
			anztuples++;
			added++;
			modified = true;
			t.lasttouched = d;
			l = indices.next;
			while (l != null) {
				a = new AVLNodeT(t);
				l.avl.Insert(a);
				l = l.next;
			}
			return t;
      	}
      	else {
      		//a.Dispose();
      		a = null;
      		//if (b.tuple.lasttouched < checktime)
      			//supported++;
      		//b.tuple.lasttouched = d;
      		lasttouched = d;
      		return b.tuple;
      	}
	}

synchronized public void Delete(GroundAtom t) {
	IndexNode l;
	AVLNodeT a;
	AVLNodeT b;
	long d;
	      
	      
        a = new AVLNodeT(t);
        l = indices;
        while (l != null) {
        	b = (AVLNodeT)l.avl.Delete(a);
        	if (b!= null) {
	    		d = Time.getTime();
        		//b.Dispose();
        		b = null;
        		b = null;
        		lastmodified = d;
        		lasttouched = d;
        		deleted++;
        		modified = true;
        	}
			l = l.next;
		}
		//a.Dispose();
		a = null;
		anztuples--;
	}
	
/*	
	public void print() {
		print.Enumerate();
	}
*/
	

	synchronized public GroundAtom Insert(GroundAtom a) {
		int i;
		GroundAtom t;
		t = insert(a);
		if (a == t) {
			for(i = 0; i < stellen; i++) {
				if ((a).terms[i].groundlevel == -1)
					groundness[i] += 1.0;
				else
					groundness[i] += (1.0 - (1.0/(float)(a).terms[i].groundlevel));
			}
		}
		return t;
	}

	public void Clear() {
		int i;
		for(i = 0; i < stellen; i++) {
			groundness[i] = (float)0.0;
		}
		clearRelation();
	}		
	
	public void checkpaths() {
		GroundAtom t;
		enum1.R1 = this;
		t = enum1.Enum();
		while (t != null) {
			t.path1();
			t = enum1.EnumNext();
		}
	}
	
	public void Terms(TermSet TS, int index) {
		// f�gt alle Terme, die an Index index auftreten in den TermSet TS ein
		GroundAtom t;
		if (index < stellen) {
			enum1.R1 = this;	
			t = enum1.Enum();
			while (t != null) {
				if ((t).terms[index].ground)
					TS.Insert((t).terms[index]);
				t = enum1.EnumNext();
			}
		}
	}

	public void notinTermSet(TermSet TS, int index) {
		// bestimmt alle GroundAtome, die an Index index einen Term haben, der nicht
		// in TermSet TS enthalten ist
		GroundAtom t;
		if (index < stellen) {
			this.tuples2 = null;
			enum1.R1 = this;	
			t = enum1.Enum();
			while (t != null) {
				if (!TS.In((t).terms[index])) {
					t.next2 = this.tuples2;
					this.tuples2 = t;
				}
				t = enum1.EnumNext();
			}
		}
	}
		
			
	public String toString(String p, String pr[],String f[], String st[]) {
		// Ausgabe aller GroundAtome mit Pr�dikatsymbol p und Symboltabelle ids 
		GroundAtom t;
		String s = "";
		enum1.R1 = this;
		t = enum1.Enum();
		while (t != null) {
			s = s.concat((t).toString(p,pr,f,st)+".\n");
			t = enum1.EnumNext();
		}
		return s;
	}

	public void Select(TermSet termsets[]) {
		// L�scht alle GroundAtome, deren Terme nicht an der entsprechenden Stelle
		// in den termsets enthalten sind 
		GroundAtom t;
		boolean delete;
		int i;
		enum1.R1 = this;
		this.tuples2 = null;
		t = enum1.Enum();
		while (t != null) {
			delete = false;
			for(i = 0; (i < t.terms.length) && (!delete); i++)
				if ((t).terms[i].ground && (termsets[i]!=null) && (!termsets[i].In((t).terms[i])))
					delete = true;
			if (delete) {
				t.next2 = this.tuples2;
				this.tuples2 = t;
			}
			t = enum1.EnumNext();
		}
	}

	public void Extend(Atoms R, int index[]) {
		// Fertigt zu jedem Atom A in R eine Kopie A' an. Jeder Term an der Stelle i in A wird an die
		// Stelle index[i] in A' kopiert. 
		GroundAtom t;
		Atom tnew;
		Atom ins;
		int i;
		long timestamp = Time.getTime();
		boolean del;
		enum1.R1 = R;
		this.tuples2 = null;
		for (t = enum1.Enum(); t != null; t = enum1.EnumNext()) {
			// neues GroundAtom
			tnew = ((Atom)t).Extend(index, this.stellen);
			ins = (Atom)Insert(tnew);
			del = ins.deleted;
			(t).Supports(ins);
			if (ins == tnew) { 
				tnew.next2 = tuples2;
				tuples2 = tnew;
			}
			tnew = null;
		}							
	}

	public void Negation(Atoms R1, int index1[], Atoms R2, int index2[]) {
		// index1 = i1,..,ik, index2 = j1,..,jk
		// this enth�lt nach der Operation alle Tupel <x1,..,xn> aus R1 fuer die es kein
		// Tupel <y1,..,ym> aus R2 gibt, mit xi1 = yj1 & xi2 = yi2 & .. & xik = yik
		GroundAtom t, ins;
		boolean inserted;
		neg.timestamp = Time.getTime();
		neg.R1 = R1;
		neg.R2 = R2;
		neg.index1 = index1;
		neg.index2 = index2;
		R1.tuples2 = null;
		R2.tuples2 = null;
		neg.Operate();
		enum1.R1 = R1;
		// Kopiere alle nicht betroffenen GroundAtome
		for(t = enum1.Enum(); t != null; t = enum1.EnumNext()) 
			if (t.lasttouched < neg.timestamp)
				ins = Insert(t);
	}
	
	public void Negation1(int index1[], Atoms R2, int index2[]) {
		// index1 = i1,..,ik, index2 = j1,..,jk
		// In this werden alle Tupel <x1,..,xn> fuer die es ein
		// Tupel <y1,..,ym> aus R2 gibt, mit xi1 = yj1 & xi2 = yi2 & .. & xik = yik
		// gel�scht
		GroundAtom t,t2;
		boolean inserted;
		neg.timestamp = Time.getTime();
		neg.R1 = this;
		neg.R2 = R2;
		neg.index1 = index1;
		neg.index2 = index2;
		this.tuples2 = null;
		R2.tuples2 = null;
		neg.Operate();
		// L�sche Tupel
		for(t = this.tuples2; t != null; t = t2) {
			t2 = t.next2;
			Delete(t);		
		}
	}
	
	public void Negation2(int index1[], Atoms R2, int index2[]) {
		// index1 = i1,..,ik, index2 = j1,..,jk
		// In this werden alle Tupel <x1,..,xn> fuer die es ein
		// Tupel <y1,..,ym> aus R2 gibt, mit xi1 = yj1 & xi2 = yi2 & .. & xik = yik
		// als gel�scht markiert
		GroundAtom t,t2;
		boolean inserted;
		neg.timestamp = Time.getTime();
		neg.R1 = this;
		neg.R2 = R2;
		neg.index1 = index1;
		neg.index2 = index2;
		this.tuples2 = null;
		R2.tuples2 = null;
		neg.Operate();
		/*
		for(t = this.tuples2; t != null; t = t2) {
			t2 = t.next2;
			// l�sche Tupel	
			Delete(t);		
		}*/
		for(t = R2.tuples2; t != null; t = t.next2) {
			(t).Disports((t));
			if ((t).no_supports == 0)
				(t).no_supports = 1;
			t.deleted = false;
		}

	}

	private void sortindices(int index1[], int index2[], int sindex1[], int sindex2[], float groundness[]) {
		int i,j,h,max;
		for(i = 0; i < index1.length; i++)
			sindex1[i] = index1[i];
		for(i = 0; i < index2.length; i++)
			sindex2[i] = index2[i];
		for(i = 0; sindex1[i] != -1; i++) {
			max = i;
			for (j = i+1; sindex1[j] != -1; j++) {
				if (groundness[sindex1[j]] > groundness[sindex1[max]])
					max = j;
			}
			h = sindex1[i]; sindex1[i] = sindex1[max]; sindex1[max] = h;
			h = sindex2[i]; sindex2[i] = sindex2[max]; sindex2[max] = h;
		}
	}

	public void MatchJoin(Atoms hrel, int sindex1[], Atoms up, int sindex2[], int dindex[]) {
		GroundAtom t;
		int i,j,h, max;
		int index1[] = null, index2[] = null;
		matchjoin.timestamp = Time.getTime();
		matchjoin.R1 = hrel;
		matchjoin.R2 = up;
		matchjoin.D = this;
		matchjoin.index1 = sindex1;
		matchjoin.index2 = sindex2;
		matchjoin.dindex2 = dindex;
		hrel.tuples2 = null;
		up.tuples2 = null;
		this.tuples2 = null;
		if ((hrel.anztuples > 0) && (up.anztuples > 0)) {
//matchjoin.anzcmps = 0;

			index1 = new int[sindex1.length];
			index2 = new int[sindex2.length];			
			sortindices(sindex1,sindex2,index1, index2, hrel.groundness);				
			matchjoin.index1 = index1;
			matchjoin.index2 = index2;

			matchjoin.Operate();
/*
System.out.print("Tupel: "); System.out.print(hrel.anztuples); System.out.print("+"); 
System.out.print(up.anztuples);
System.out.print("  Vergleiche: "); System.out.println(matchjoin.anzcmps);
*/
		}
	}
	
	
	
	public void Join(Atoms R1, int index1[], Atoms R2, int index2[], int dix1[], int dix2[]) {
		// index1 = i1,..,in; index2 = j1,..,jn; dix1 = d1,..,dk; dix2 = e1,..,ep
		// f�r Tupelpaare {<x1,..,xr>,<y1,..,ys> | <x1,..,xr> aus R1, <y1,..,ys> aus R2 mit
		// xi1 = yj1 & .. & xin = yin} 
		// entsteht ein Tupel <z1,..,zt> in this mit 
		// 	zdi = xi, falls di != -1 und
		// 	zei = yi, falls ei != -1
		GroundAtom t, th, t1, t2;
		join.D = this;
		join.index1 = index1;
		join.index2 = index2;
		join.dindex1 = dix1;
		join.dindex2 = dix2;
		R1.tuples2 = null;
		R2.tuples2 = null;
		join.timestamp = Time.getTime();
		join.R1 = R1;
		join.R2 = R2;
		if (index1[0] != -1) {
			join.Operate();
		}
		else {
			// keine gemeinsamen Variablen, Bildung des Kreuzprodukts
			enum1.R1 = R1;
			enum2.R1 = R2;
			for(t1 = enum1.Enum(); t1 != null; t1 = enum1.EnumNext()) 
				if (!t1.deleted)
					for(t2 = enum2.Enum(); t2 != null; t2 = enum2.EnumNext()) {
						if (!t2.deleted)
							join.op(t1,t2);	
					}
		}
	}




	public void Matching(Atoms R1, Atoms R2) {
		// produziert jede Variablensubstitution, die daraus entsteht, dass ein GroundAtom
		// aus R1 mit einem GroundAtom aus R2 matcht
		GroundAtom t;
		int i;
		matching.timestamp = Time.getTime();
		matching.R1 = R1;
		matching.R2 = R2;
		matching.D = this;
		matching.index1 = R1.matchindex;
		matching.index2 = R2.matchindex;
		R1.tuples2 = null;
		R2.tuples2 = null;
		//matching.flag = false;
		matching.Operate();
		//return matching.flag;
	}
	
	
	public void Subsumption(Atoms R) {
		// bestimmt alle GroundAtome in this, die von GroundAtomen in R1 subsummiert werden
		GroundAtom t,t1;
		int i, oldanz;
		subsum.timestamp = Time.getTime();
		subsum.R1 = this;
		subsum.R2 = R;
		subsum.index1 = this.matchindex;
		subsum.index2 = this.matchindex;
		this.tuples2 = null;
		R.tuples2 = null;
		//oldanz = this.anztuples+R.anztuples;
		subsum.Operate();
		t = this.tuples2; 
		while (t != null) {
			t1 = t.next2;
			this.Delete(t);
			t = t1;
		}
		this.tuples2 = null;
	}
	
	public void Generalize(Atoms R1, Atoms R2) {
		// produziert jeweils aus einem GroundAtom von R1 und einem aus R2 eine Generalisierung, falls m�glich
		GroundAtom t;
		int i;
		int index1[];
		int index2[];
		float groundness[];
		gen.timestamp = Time.getTime();
		gen.R1 = R1;
		gen.R2 = R2;
		gen.D = this;
		gen.index1 = R1.matchindex;
		gen.index2 = R2.matchindex;
		R1.tuples2 = null;
		R2.tuples2 = null;
/*
		index1 = new int[R1.matchindex.length];
		index2 = new int[R2.matchindex.length];	
		groundness = new float[R1.stellen];
		for(i = 0; i<R1.stellen; i++)
			groundness[i] = R1.groundness[i]+R2.groundness[i];		
		sortindices(R1.matchindex,R2.matchindex,index1, index2, groundness);				
		gen.index1 = index1;
		gen.index2 = index2;
*/
		gen.Operate();
	}
	
	public void Filtering(Atom A, Atoms F, Atoms R2) {
		// This enth�lt nach der Operation alle Substitutionen s2 f�r die es eine Substitution 
		// s1 gibt, so dass es ein a aus R2 und ein f aus F gibt mit s1(f) = a und s2(A) = a
		GroundAtom t;
		int i;
		int index1[];
		int index2[];
		filter.timestamp = Time.getTime();
		filter.R1 = F;
		filter.R2 = R2;
		filter.D = this;
		filter.index1 = F.matchindex;
		filter.index2 = R2.matchindex;
		index1 = new int[F.matchindex.length];
		index2 = new int[R2.matchindex.length];			
		sortindices(F.matchindex,R2.matchindex,index1, index2, F.groundness);				
		filter.index1 = index1;
		filter.index2 = index2;

		filter.T = A;
		F.tuples2 = null;
		R2.tuples2 = null;
		this.tuples2 = null;
		filter.Operate();
/*
System.out.println("Filter: ");
F.print();
System.out.println("Up:");
R2.print();

System.out.print("Tupel: "); System.out.print(F.anztuples); System.out.print("+"); System.out.print(R2.anztuples);
System.out.print("  Vergleiche: "); System.out.println(filter.anzcmps);
*/
	}

	public void Filtering1(Atoms F, Atoms R2) {
		// This enth�lt nach der Operation alle Substitutionen s2 f�r die es eine Substitution 
		// s1 gibt, so dass es ein a aus R2 und ein f aus F gibt mit s1(f) = a
		int index1[];
		int index2[];
		filter1.timestamp = Time.getTime();
		filter1.R1 = F;
		filter1.R2 = R2;
		filter1.D = this;
		filter1.index1 = F.matchindex;
		filter1.index2 = R2.matchindex;
		index1 = new int[F.matchindex.length];
		index2 = new int[R2.matchindex.length];			
		sortindices(F.matchindex,R2.matchindex,index1, index2, F.groundness);				
		filter1.index1 = index1;
		filter1.index2 = index2;

		F.tuples2 = null;
		R2.tuples2 = null;
		this.tuples2 = null;
		//filter1.debug = debug;
		filter1.Operate();
/*
if (debug) {
	System.out.println("Filter:");
	F.getindex(index1).avl.print();
	System.out.println("verf�gbar:");
	R2.getindex(index2).avl.print();
	
}*/
	}
	
	public void Unify(GroundAtom T, Atoms R1) {
		// this enth�lt danach alle Substitutionen s1 f�r die es eine Substitution s2
		// mit s1(T) = s2(a), wobei a aus R1 ist, s1,s2 sind die allgemeinsten Unifikatoren
		uni.timestamp = Time.getTime();
		uni.R1 = R1;
		uni.index1 = R1.matchindex; 
		uni.index2 = R1.matchindex;
		uni.D = this;
		R1.tuples2 = null;
		this.tuples2 = null;
		uni.Search(T);
	}
		
	public void Match(GroundAtom T, Atoms R1) {
		// this enth�lt danach alle Substitutionen s 
		// mit s(T) = a, wobei a aus R1 ist
		match.timestamp = Time.getTime();
		match.R1 = R1;
		match.index1 = R1.matchindex; 
		match.index2 = R1.matchindex;
		match.D = this;
		R1.tuples2 = null;
		this.tuples2 = null;
		match.Search(T);
	}



			
	public void Substitute(Atom T, Atoms R, int index[]) {
		// produziert aus den Substitutionen s in R alle s(T).
		// index = i1,..,ik. ij gibt die Spalte der Variable mit Symbol j in R an 
		subs.R1 = R;
		subs.T = T;
		subs.D = this;
		this.tuples2 = null;
		subs.index1 = index;
		subs.Enumerate();
	}
	



	 void Eval(Atom T, Atoms R, int vars3[], BuiltinFunc f) {
		GroundAtom t;
		f.D = this;
		f.index = vars3;
		f.T = T;
		this.tuples2 = null;
		enum1.R1 = R;
		for(t = enum1.Enum(); t != null; t = enum1.EnumNext()) {
			if (!t.deleted) f.eval((Atom)t);
		}
	}
}




		
	
