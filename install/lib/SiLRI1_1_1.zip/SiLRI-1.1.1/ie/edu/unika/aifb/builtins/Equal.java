/*

Name: Equal.java

Version: 1.0

Purpose:

History:

*/

package edu.unika.aifb.builtins;

import edu.unika.aifb.inference.BuiltinFunc;
import edu.unika.aifb.inference.Variable;
import edu.unika.aifb.inference.Atom;
//import edu.unika.aifb.inference.NumTerm;


public class Equal  extends BuiltinFunc {

  public void eval(Atom t) {
  int i;
  int anzbound = 0;
  boolean ok = true;
  if(t.terms[0].Unify(t.terms[1])) {insert(t);}		
 

  }
}



