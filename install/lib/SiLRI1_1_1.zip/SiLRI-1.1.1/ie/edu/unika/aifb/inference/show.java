/*

Name: show.java

Version: 1.0

Purpose:

History:

*/

package edu.unika.aifb.inference;

import java.util.*;
import java.util.Date;
import java.net.*;
import java.io.*;




public class show {
   public static void main(String args[]) throws IOException {
     long filePointer;
     long length,len = 0; 
     String s = "";
     RandomAccessFile file;
     SParser spars;
     RuleSet rs = null;

    spars = new SParser();
    spars.show = true;
    file = new RandomAccessFile(args[0],"r");
    length = file.length();
    while(len < length) {
    	s = file.readLine() + "\n";
	len = len + s.length();

	try {
		spars.decode(rs,s);
	}
	catch (JanParseError1 p) {
		System.out.println(p.getMessage());
	}
  
    } 
  }
}
 



		
		
		
	
	
