/*

Name: AVLTree.java

Version: 1.0

Purpose:

History:

*/

package edu.unika.aifb.inference;

import java.io.*;
import java.util.*;
import java.net.*;

class AVLEnumeration {
	AVLTree avl;
	public AVLEnumeration(AVLTree T) {avl = T;}
	public void op(AVLNode a) {}
	private void enumerate(AVLNode t) {
		if (t != null) {
			op(t);
			enumerate(t.links);
			enumerate(t.rechts);
		}
	}
	public void Enumerate() {
		if ((avl != null) && (avl.tree != null))
			enumerate(avl.tree);
	}
}
				

// an AVL tree
public abstract class AVLTree {
	// member data
	protected  boolean duplicates = false; 		// indicates whether duplicates are stored
	protected  AVLNode tree = null; 		// the root of the tree
	protected  int number = 0; 			// number of nodes
	protected  boolean HoehenAenderung = false; 	// for balancing
	protected  AVLNode deleted; 			// the node which has been deleted
	protected  AVLNode inserted; 			// the node which has been inserted
	
	// methods which have to be instantiated
	protected abstract int praed(AVLNode t1, AVLNode t2);
	protected abstract boolean equal(AVLNode t1, AVLNode t2);
	
	
	// search for an element
	public AVLNode Search(AVLNode element) {
		return search(tree, element);
	}   
	
	// constructor
	public AVLTree (boolean dups) {
		// dups indicates whether duplicates are stored (in the middle references)
		duplicates = dups;
	}
	
/*
	// insert a new element
	public boolean Insert(AVLNode element) {
		// return whether the element has inserted
		int oldnumber;
		HoehenAenderung = false;
		oldnumber = number;
		tree = insert(tree,element);
		anzinserted++;
		if (oldnumber < number)
			return true;
		else {
			doubleinserted++;
			return false;
		}
	}
*/
	
	// insert a new element
	public AVLNode Insert(AVLNode element) {
		// return whether the element has inserted
		int oldnumber;
		HoehenAenderung = false;
		oldnumber = number;
		tree = insert(tree,element);
		return inserted;
	}

		
	// delete an element
	public AVLNode Delete(AVLNode element) {
		// returns the deleted element
		deleted = null;
		HoehenAenderung = false;
		tree = delete(tree,element);
		return deleted;
	}
		
	// returns the top element of the tree
	public AVLNode Top() {
		return tree;
	}
	
	// number of elements	
	public int NoElements() {return number;}

	// depth of the tree
	public int Depth() {
		return depth(tree,0);
	}
	
	private void prt(AVLNode t) {
		if (t != null) {
			prt(t.links);
			t.print(); System.out.println();
			prt(t.rechts);
		}
	}

	public void print() {
		prt(this.tree);
	}

	private void wrt(RandomAccessFile f, AVLNode t) throws IOException {
		if (t != null) {
			wrt(f,t.links);
			t.write(f); f.writeBytes("\n");
			wrt(f,t.rechts);
		}
	}

	public void write(RandomAccessFile f) throws IOException {
		wrt(f,this.tree);
	}


/*				
	// print tree for debugging purposes
	public void print() {
		int i, d;
		d = depth(tree,0);
		for (i=0; i < d; i++) {
			printlevel(tree,i,0);
			System.out.println();
			}
		}
*/		
	// clear the tree
	public void ClearTree() {
		tree = null;
		number = 0;
	}
			
	// private methods to print the tree, balance the tree, insert and delete an element 
		
	// maximal depth of the tree
	private int depth(AVLNode t, int level) {
		int d1,d2;
		if (t == null) return level;
		else {
			d1 = depth(t.links,level+1);
			d2 = depth(t.rechts,level+1);
			if (d1 < d2) return d2;
			else return d1;
			}
		}
/*
	// print tree for debugging purposes
	private void printlevel(AVLNode t, int level, int actlevel) {
		if (t != null) {
			if (actlevel < level) {
				System.out.print("l"); 
				printlevel(t.links,level, actlevel+1);
				System.out.print("r");
				printlevel(t.rechts,level, actlevel+1);
				}
			else if (actlevel == level) {
				AVLNode t1;
				for (t1 = t; t1 != null; t1 = t1.mitte) {
					System.out.print("  "); t1.print(); System.out.print("  "); 
					}
				}
			}
		else if (actlevel == level) System.out.print(" null ");
		}
*/
	
	private AVLNode BalanceDL(AVLNode baum) {
		AVLNode baum1, baum2;
		int balance1, balance2;

      	switch (baum.balance) {
         	case -1 : 	baum.balance = 0; break;
          	case 0 : 	baum.balance = 1;
              			HoehenAenderung = false; break;
          	case 1 : 	baum1 = baum.rechts;
              			balance1 = baum1.balance;
              			if (balance1 >= 0)  {                   /* single RR rotation */
                 			baum.rechts = baum1.links;
                 			baum1.links = baum;
                 			if (balance1 == 0) { 
                    			baum.balance  = 1;
                    			baum1.balance = -1;
                    			HoehenAenderung  = false;
                    			}
                 			else {
                    			baum.balance  = 0;
                    			baum1.balance = 0;
                    			}
                 			baum = baum1;
                 			}
             			else {                                  /* double RL rotation */
                 			baum2 = baum1.links;
                 			balance2 = baum2.balance;
                 			baum1.links = baum2.rechts;
                 			baum2.rechts = baum1;
                 			baum.rechts = baum2.links;
                 			baum2.links = baum;
                 			if (balance2 == 1) 
                    			baum.balance = -1;
                 			else
                    			baum.balance = 0;
                 			if (balance2 == -1) 
                    			baum1.balance = 1;
                 			else
                    			baum1.balance = 0;
                 			baum = baum2;
                 			baum2.balance = 0;
                 			}
      		}
      		return baum;
      }


	private AVLNode BalanceDR(AVLNode  baum) {
		AVLNode  baum1, baum2;
       	int balance1, balance2;
 
      	switch (baum.balance) {
        	case 1 : 	baum.balance = 0; break;
          	case 0 : 	baum.balance = -1;
              			HoehenAenderung = false; break;
         	case -1 : 	baum1         = baum.links;
              			balance1      = baum1.balance;
              			if (balance1 <= 0) {         /* single LL rotation */
                 			baum.links   = baum1.rechts;
                 			baum1.rechts = baum;
			                if (balance1 == 0) {
			                    baum.balance  = -1;
			                    baum1.balance = 1;
			                    HoehenAenderung  = false;
			                    }
			                else {
			                    baum.balance  = 0;
			                    baum1.balance = 0;
			                    }
			                baum = baum1;
			                }
			              else {                      /* double LR rotation */
			                 baum2        = baum1.rechts;
			                 balance2     = baum2.balance;
			                 baum1.rechts = baum2.links;
			                 baum2.links  = baum1;
			                 baum.links   = baum2.rechts;
			                 baum2.rechts = baum;
			                 if (balance2 == -1)
			                    baum.balance = 1;
			                 else
			                    baum.balance = 0;
			                 if (balance2 == 1) 
			                    baum1.balance = -1;
			                 else
			                    baum1.balance = 0;
			                 baum = baum2;
			                 baum2.balance = 0;
			                 }
      	}
      	return baum;
   }


   private AVLNode BalanceR(AVLNode baum) {

      AVLNode baum1, baum2;

       if (HoehenAenderung) {
          switch (baum.balance) {
              case 1 : 	baum.balance = 0;
                  		HoehenAenderung = false; break;
              case 0 : 	baum.balance = -1; break;
              case -1 : baum1         = baum.links;
                      	if (baum1.balance == -1) { /*single LL rotation*/
                         	baum.links   = baum1.rechts;
                         	baum1.rechts = baum;
                         	baum.balance = 0;
                         	baum          = baum1;
                         	}
                      	else {                    /* double LR rotation */
                         	baum2         = baum1.rechts; 
                         	baum1.rechts = baum2.links;
                         	baum2.links  = baum1;
                         	baum.links   = baum2.rechts;
                         	baum2.rechts = baum;
                         	if (baum2.balance == -1) 
                            	baum.balance = 1;
                         	else
                            	baum.balance = 0;
                         	if (baum2.balance == 1) 
                            	baum1.balance = -1;
                         	else
                            	baum1.balance = 0;
                     		baum = baum2;
                      		}
                      	baum.balance = 0;
                      	HoehenAenderung = false;
          }
       }
       return baum;
    }

   private AVLNode BalanceL(AVLNode baum) {

       AVLNode baum1,baum2;
          
       if (HoehenAenderung) {
          switch (baum.balance) {
             case -1 :  baum.balance = 0;
               			HoehenAenderung = false; break;
             case 0 : 	baum.balance = 1; break;
             case 1 : 	baum1 = baum.rechts;
	                  	if (baum1.balance == 1) { /*single RR rotation */
	                     	baum.rechts  = baum1.links;
	                     	baum1.links  = baum;
	                     	baum.balance = 0;
	                     	baum = baum1;
	                     	}
	                  	else  {                    /* double RL rotation */
	                     	baum2 = baum1.links;
	                     	baum1.links = baum2.rechts;
	                     	baum2.rechts = baum1;
	                     	baum.rechts = baum2.links;
	                     	baum2.links = baum;
	                     	if (baum2.balance == 1)
	                        	baum.balance = -1; 
	                     	else
	                        	baum.balance = 0;
	                     	if (baum2.balance == -1)
	                        	baum1.balance = 1;
	                     	else
	                        	baum1.balance = 0;
	                     	baum = baum2;
	                  		}
	                  	baum.balance = 0;
	                  	HoehenAenderung = false;
          }
    }
    return baum;
 }
 
   private AVLNode insert(AVLNode baum, AVLNode element) {

     AVLNode baum1,baum2;
     int praed;
               
     if (baum == null) {                                  /* insert */
        baum = element;
        HoehenAenderung = true;
        baum.links   = null;
        baum.rechts  = null;
        baum.mitte    = null;
        baum.balance = 0;
        inserted = element;
        number++;
        }
     else {
        praed = praed(baum,element);
        if (praed == 1) {
           baum.links = insert(baum.links, element);
           if (HoehenAenderung) 
               baum = BalanceR(baum);
           }
       	else if (praed == -1) {
           baum.rechts = insert(baum.rechts, element);
           if (HoehenAenderung)
               baum = BalanceL(baum);
		   }
        else {
           /* ELSIF Baum^.praedikat(baum, element) = 0 THEN */
           HoehenAenderung = false; 
           if (duplicates) {
               element.mitte = baum.mitte;
               baum.mitte = element;
               number++;
               inserted = element;
           } 
           else
           	inserted = baum;      
        }
     }
     return baum;
   }


     private AVLNode next(AVLNode r) {
		if (r.links != null) {
			r.links = next(r.links);
			if (HoehenAenderung) 
        		r = BalanceDL(r);
        }
        else {
        	deleted = r;
       		r = r.rechts;
            HoehenAenderung = true;
        }
        return r;	
	 }

	private AVLNode last(AVLNode r) {
		if (r.rechts != null) {
			r.rechts = last(r.rechts);
			if (HoehenAenderung) 
        		r = BalanceDR(r);
        }
        else {
        	deleted = r;
       		r = r.links;
            HoehenAenderung = true;
        }
        return r;	
	 }
	
		
   private AVLNode delete(AVLNode baum, AVLNode element) { 

      AVLNode h, mitte;
      int praed;

      if (baum != null) {                    /* adress not in AVLNode */
         praed = praed(baum,element);
         switch (praed) {
         case 1 : baum.links = delete(baum.links, element);
             if (HoehenAenderung) 
                baum = BalanceDL(baum);
             break;
        case -1 : baum.rechts = delete(baum.rechts, element);
             if (HoehenAenderung)
                baum = BalanceDR(baum); 
  			 break;
        case 0 :  if (equal(baum,element)) {
                 number--;
                 deleted = baum;
                 if (baum.mitte != null) {
                     baum.mitte.links = baum.links;
                     baum.mitte.rechts = baum.rechts;
                     baum.mitte.balance = baum.balance;
                     baum = baum.mitte;
                     }
                 else {
                     if (baum.rechts == null) {
                     	 deleted = baum;
                         baum = baum.links;
                         HoehenAenderung = true;
                         }
                     else if (baum.links == null) {
                     	 deleted = baum;
                         baum = baum.rechts;
                         HoehenAenderung = true;
                         }
                     else if (baum.balance == 1) {                       
                         if (baum.rechts.links == null) {
                         	 deleted = baum;
                             baum.rechts.links = baum.links;
                             baum.rechts.balance = baum.balance;
                             baum = baum.rechts;
                             HoehenAenderung = true;
                             baum = BalanceDR(baum);
                             }
                         else {
                             baum.rechts = next(baum.rechts);
							 deleted.links = baum.links; deleted.rechts = baum.rechts;
                             deleted.balance = baum.balance;
                             h = baum; baum = deleted; deleted = h;
                             /*treeoutput(baum.rechts,out,0);*/
                             if (HoehenAenderung) 
                                 baum = BalanceDR(baum);
                             }
                         }
                     else {                      
                         if (baum.links.rechts == null) {
                         	 deleted = baum;
                             baum.links.rechts = baum.rechts;
                             baum.links.balance = baum.balance;
                             baum = baum.links;
                             HoehenAenderung = true;
                             baum = BalanceDL(baum);
                             }
                         else {
                             baum.links = last(baum.links);
							 deleted.links = baum.links; deleted.rechts = baum.rechts;
                             deleted.balance = baum.balance;
                             h = baum; baum = deleted; deleted = h;
                              if (HoehenAenderung) 
                                 baum = BalanceDL(baum);
                             }
                         }
                     }
                 }
             else if  (baum.mitte != null) {
                h = baum;
                while ((h.mitte != null) && (!equal(h.mitte,element)))
                    h = h.mitte;
                if (h.mitte != null) {
                    number--;
                    deleted = h.mitte;
                    h.mitte = h.mitte.mitte;
                    }
                }
             }
         }
         return baum;
      }
   
		
	private AVLNode search(AVLNode baum, AVLNode element) {

         if (baum == null)
            return null;
         else {
            switch (praed(baum,element)) {
               case 1     : return (search(baum.links,element));
               case -1    : return (search(baum.rechts,element));
               case 0     : return (baum);
            }
        }
        return null;
    }
   
}	


	


