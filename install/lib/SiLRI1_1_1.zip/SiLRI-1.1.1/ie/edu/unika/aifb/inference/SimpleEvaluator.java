/*

Name: SimpleEvaluator.java

Version: 1.01

Purpose:
Capsulates the Inference Engine. Realizes API for 
Logic Programs with Datalog Syntax

History:
3.5.99: Added facility to test for substitutions, SDe

*/

package edu.unika.aifb.inference;

import edu.unika.aifb.builtins.BuiltinConfig;
import java.applet.*;
import java.awt.*;
import java.util.*;
import java.util.Date;
import java.net.*;
import java.io.*;

public class SimpleEvaluator extends Object {
//public static int STRINGSTART = 100000;

public RuleSet RS;   
public AVLTreeSymbol FSymbols;
public AVLTreeSymbol PSymbols;
public AVLTreeString Strings;
public boolean stratified;
public boolean compiled;
public boolean evaluated;
public Hashtable Names;
public Hashtable Numbers;
public PrintStream out = null;

SimpleParser sparser=null;

public SimpleEvaluator() {

}

public void init()
{ 
init(null);
}

public void init(PrintStream f)
{ 
RS = new RuleSet();
if (f != null)
	RS.writeonly(f);
 
Config.ev = this;

FSymbols = new AVLTreeSymbol();
PSymbols = new AVLTreeSymbol();
Strings = new AVLTreeString();
compiled = false;
stratified = true;
Names = new Hashtable();
Numbers = new Hashtable();

FSymbols.searchAndInsert("+",2); // 0
FSymbols.searchAndInsert("-",2); // 1
FSymbols.searchAndInsert("*",2); //  2
FSymbols.searchAndInsert("/",2);// 3
FSymbols.searchAndInsert("%",2); // 4
FSymbols.searchAndInsert("E",0); // 5
FSymbols.searchAndInsert("PI",0); // 6
FSymbols.searchAndInsert("RANDOM",0);// 7
 
FSymbols.searchAndInsert("abs",1); // 8
FSymbols.searchAndInsert("sin",1); // 9
FSymbols.searchAndInsert("cos",1);// 10
FSymbols.searchAndInsert("tan",1);// 11
FSymbols.searchAndInsert("asin",1);// 12
FSymbols.searchAndInsert("acos",1);// 13
FSymbols.searchAndInsert("ceil",1);// 14
FSymbols.searchAndInsert("floor",1);// 15
FSymbols.searchAndInsert("exp",1);// 16
FSymbols.searchAndInsert("log",1);// 17
FSymbols.searchAndInsert("rint",1);// 18
FSymbols.searchAndInsert("sqrt",1);// 19
FSymbols.searchAndInsert("round",1);// 20

FSymbols.searchAndInsert("max",2);// 21
FSymbols.searchAndInsert("min",2);// 22
FSymbols.searchAndInsert("pow",2);// 23

BuiltinConfig.init(PSymbols);

//PSymbols.searchAndInsert("add",3);
//PSymbols.searchAndInsert("concat",3);

}

public void compileSimpleString(String rules)  throws SimpleParseException
   { compileSimpleStream(new StringBufferInputStream(rules));}

public void compileSimpleFile(String filename) throws Exception
   { compileSimpleStream(new FileInputStream(filename)); }


public void compileSimpleStream(InputStream Rules) throws SimpleParseException
{  
   if(sparser==null) sparser=new SimpleParser(this,Rules);
   else sparser.ReInit(Rules);
   sparser.compile();
   compiled = true;
}




public void stratify(){
	stratified = RS.Stratify(); 
}


public void naive() {
	if (!compiled) System.out.println("Please compile first\n");
	else if (!stratified) System.out.println("Cannot evaluate because rules are not stratified\n");
	else {
 		RS.EvaluationMethod(0);
		RS.EvalQueries();
        evaluated = true;
	}
}


    public void dynamic() {
        int i;
	Rule q;
	if (!compiled) System.out.println("Please compile first\n");
	else if (!stratified) System.out.println("Cannot because rules are not stratified\n");
	else {
 		RS.EvaluationMethod(1);
                // System.out.println("Optimizing");
                RS.Optimize2();
                // System.out.println("Evaluating");
		RS.EvalQueries();
        evaluated = true;
  	}
	}


   

   public void WellfoundedAF() {
        int i;
	Rule q;
	if (!compiled) System.out.println("Please compile first\n");
 	else {
 		RS.EvaluationMethod(2);
		RS.EvalQueries();
                evaluated = true;
  		     }
	}

   public void Wellfounded() {
        int i;
	Rule q;
	if (!compiled) System.out.println("Please compile first\n");
 	else {  RS.Optimize2();
 		RS.EvaluationMethod(3);
		RS.EvalQueries();
                evaluated = true;
  	}
}




public void evaluate()
  { 

    /*
    if(stratified) { //   System.out.println("Evaluating Dynamic");
       dynamic(); }
    else { //  System.out.println("Evaluating Wellfounded"); 
     naive(); }

     */    
  //  WellfoundedAF();
  // dynamic();
  // naive();
	Wellfounded();

}


int wandle(String s) {
	Integer zahl = new Integer(0);
	try {
		zahl = new Integer(s);
	}
	catch (NumberFormatException p) {
		System.out.println("number expected");
	}
	return zahl.intValue();
} 

public void write(RandomAccessFile f) throws IOException {

	f.writeBytes(String.valueOf(FSymbols.NoElements())+"\n");
	f.writeBytes(String.valueOf(Strings.NoElements())+"\n");
	f.writeBytes(String.valueOf(PSymbols.NoElements())+"\n");

	FSymbols.write(f);
        Strings.write(f);
	PSymbols.write(f);
}

public void read(RandomAccessFile f) throws IOException {
	int fsyms, strings, psyms;
	String s;
	int i;
	int index, index1;
	int symbol;
	String str;
	int arity;
	int len;

	s = f.readLine(); fsyms = wandle(s);
	s = f.readLine(); strings = wandle(s);
	s = f.readLine(); psyms = wandle(s);
 
	
	for(i = 0; i < fsyms; i++) {
		s = f.readLine(); 
		index = s.indexOf(' '); 
		symbol = wandle(s.substring(0,index)); 
		index1 = s.indexOf(' ',index+1); 
		//System.out.print(s); System.out.print("   ");
		// System.out.print(index); System.out.print(" "); System.out.println(index1);
		arity = wandle(s.substring(index+1,index1)); 
		str = s.substring(index1+1); 
		FSymbols.searchAndInsert(str,arity); 
	} 

	for(i = 0; i < strings; i++) {
		s = f.readLine(); 
		index = s.indexOf(' '); 
		symbol = wandle(s.substring(0,index)); 
		index1 = s.indexOf(' ',index+1); 
		//System.out.print(s); System.out.print("   ");
		// System.out.print(index); System.out.print(" "); System.out.println(index1);
		len = wandle(s.substring(index+1,index1)); 
		str = s.substring(index1+1); 
		while (str.length()<len) {
			str = str + f.readLine()+ "\n";
		}
		Strings.searchAndInsert(str); 
		// System.out.println(str);
	} 

	for(i = 0; i < psyms; i++) {
		s = f.readLine(); 
		index = s.indexOf(' '); 
		symbol = wandle(s.substring(0,index)); 
		index1 = s.indexOf(' ',index+1); 
		//System.out.print(s); System.out.print("   ");
		// System.out.print(index); System.out.print(" "); System.out.println(index1);
		arity = wandle(s.substring(index+1,index1)); 
		str = s.substring(index1+1); 
		PSymbols.searchAndInsert(str,arity); 
	} 

}
 
public  void deleteQueries(){
	Rule q;
	for(q = RS.NextQuery(null); q != null; q = RS.NextQuery(q)){
		RS.DeleteRule(q);
	}
	Names = new Hashtable();
	Numbers = new Hashtable();
}


public void deleteQuery(Rule q){
	Names.remove(q);
	Numbers.remove(q);
	RS.DeleteRule(q);
}


public  boolean testSubstitutions(Rule q){
	Substitution S = RS.Substitution(q);
	Atom A = (Atom) S.First();
	return A != null;
}

public Vector computeSingleSubstitution(Rule q){
	int i,k,m,j;
	Vector Vars = (Vector) Names.get(q);
	Vector Nums =  (Vector) Numbers.get(q);
	Vector SetSubst = new Vector();
	Substitution S = RS.Substitution(q);
	k = S.index.length;
	if(Nums==null) 
		j=0; 
	else 
		j = Nums.size();
     	Atom A = (Atom) S.First();
	while(A !=null){
		Vector SingleSubst = new Vector();
		for(i=0;i<j;i++){
			if(Nums.elementAt(i) != null && S.index[((Integer)(Nums.elementAt(i))).intValue()] >=0){
			SingleSubst.addElement(new SimpleSubst((String) Vars.elementAt(i), 
			toSimpleTerm(A.terms[S.index[((Integer) Nums.elementAt(i)).intValue()]],FSymbols, Strings)));
			}
		}          
	SetSubst.addElement(SingleSubst);
	A = (Atom) S.Next(); 
	}
	return SetSubst;
}

 


public Vector computeSimpleSubstitutions(){
	Vector QSubst = new Vector();
	for(Rule q = RS.NextQuery(null); q != null; q = RS.NextQuery(q))
		QSubst.addElement( computeSingleSubstitution(q));
	return QSubst;                       
}


public void printSubs(Vector QSubst)
{  
 java.util.Enumeration e,f,g;
 for(e = QSubst.elements();e.hasMoreElements();){
   for(f=((Vector)(e.nextElement())).elements(); f.hasMoreElements();){
     for(g=((Vector)(f.nextElement())).elements(); g.hasMoreElements();){
        System.out.println(g.nextElement().toString());
     }
     System.out.println();
   }
 }

}
     
public FTerm toSimpleTerm(Term A,AVLTreeSymbol ids, AVLTreeString Strings ) 
 { 
   if(A instanceof Variable) 
         { 
           return new FTermVariable("X" + Integer.toString(((Variable)A).symbol));
         }
          else if(A instanceof NumTerm) 
         {
           return new FTermFloat(new Double(((NumTerm) A).zahl));
         }
          else if(A instanceof StringTerm)
        {
          return  new FTermString(((StringTerm)A).s);
         }
          else if(A instanceof ConstTerm)
        {        
         ConstTerm C = (ConstTerm) A;
         if(C.symbol >= Config.STRINGSTART) 
             return  new FTermString(Strings.getContent(C.symbol - Config.STRINGSTART)); 
 	 String s1 = (String) ids.getContent(C.symbol);
         FTerm[] t = new FTerm[C.anzpars];
	 if (C.anzpars > 0) {
	       for(int i= 0; i < C.anzpars; i++) {
		  t[i] = toSimpleTerm(C.pars[i],ids,Strings);
		}	
	}
	return new FTermFunction(s1,t);	
     }
 return null;
   
}               


  public static void main(String args[]) throws Exception
   { 
     SimpleEvaluator  eval = new SimpleEvaluator();
     eval.init();   
     int i=0;
    while(i< args.length)
    {
     eval.compileSimpleFile(args[i]);i++;     
     }
     eval.stratify();
     eval.evaluate();
//   eval.dynamic();
//   eval.Wellfounded();
     eval.printSubs(eval.computeSimpleSubstitutions());
   
 }


          
}


/*
abstract class ParserMediator {
 public void mediate(FLObject O) {}
}

class CompMediator extends ParserMediator{
	Evaluator engine;
 	public CompMediator(Evaluator engine){
		this.engine = engine;
	}


	public void mediate(FLObject O){
		engine.compile(O);
	}
}

class TransMediator extends ParserMediator{
	Evaluator engine;
	public TransMediator(Evaluator engine){
		this.engine = engine;
	}
	public void mediate(FLObject O){
		engine.toSimple(O);
	}
}
*/
