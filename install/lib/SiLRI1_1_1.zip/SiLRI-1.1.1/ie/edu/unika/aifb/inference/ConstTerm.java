/*

Name: ConstTerm.java

Version: 1.0

Purpose:

History:

*/

package edu.unika.aifb.inference;

import java.io.*;
import java.util.*;
import java.net.*;

public class ConstTerm extends Term {
	// type == 4
	public int symbol;		// repr�sentiert die Konstante


	public ConstTerm(int sym, Term terms[]) {
		// Funktion mit Symbol sym als Funktionssymbol
		// terms enthaelt die Parameter
		super(terms.length,true);
		int i;
		boolean ground = true;
		if (terms.length > 0) groundlevel = terms[0].groundlevel+1;
		for(i = 0; i < terms.length; i++) {
			if (!terms[i].ground) ground = false;
			if (terms[i].groundlevel+1 < groundlevel) groundlevel = terms[i].groundlevel+1;
			pars[i] = terms[i];
		}
		this.ground = ground;
		symbol = sym; 
	}
	public ConstTerm(int sym) {
		// Konstante
		super(0,true);
		symbol = sym; 
	}	
	public ConstTerm(int sym, int stelligkeit, boolean grnd) {
		super(stelligkeit,grnd);
		symbol = sym;
	}
	public boolean isConstTerm() {
		if (symbol >= 0) return true;
		else return false;
	}
	public int type() {return 4;}
	public boolean isStringTerm() {
		if (symbol < 0) return true;
		else return false;
	}
	public void print1(PrintStream p) {
		if (anzpars == 0) p.print("c");
		else p.print("f");
		p.print(symbol);
	}
	//static int i = 0;
	public void print1(PrintStream pr,String p[],String f[], String s[]) {
		if (symbol >= 100000) {
			pr.print(s[symbol-100000]);
			/*
			if (i == 25) {
				System.out.println(symbol);
				System.out.println(s[symbol-100000]);
				for (int j = 0; j < s[symbol-100000].length(); j++) {
					System.out.print((int)s[symbol-100000].charAt(j)); 
					System.out.print("|");
				}
				System.out.println();
			}
			i++;
			*/
			
		}
		else pr.print(f[symbol]);
	}
	public void internalize1(PrintStream p) {
		//System.out.print("c" +String.valueOf(symbol));
		//f.writeBytes("c"+String.valueOf(symbol));
		p.print("c"+String.valueOf(symbol));	
	}	

	public String toString1(String p[],String f[], String s[]) {
		if (symbol >= 10000) return "\""+s[symbol-10000]+"\"";
		else return f[symbol];
		}	
	public String toString1() {
		// Ausgabe des ConstTerms als Zeichenkette
		return "c"+String.valueOf(symbol);
	}
	public int CompareEqual(Term t) {
		// Vergleicht zwei einzelne ConstTerme aufgrund ihres Symbols
		return symbol <= ((ConstTerm)t).symbol?(symbol<((ConstTerm)t).symbol?-1:0):1;	
	}
	public Term Substitute() {
		// Durchf�hrung einer Substitution, d.h. die Variable wird durch ihren
		// Substituenden im Term ersetzt
		// Dabei werden alle oberen Terme (�berhalb von Variablen) neu generiert
		Term t;
		int i;
		if (ground) return this;
		else {
			t = new ConstTerm(symbol, anzpars, true);
			t.ground = true;
			for(i = 0; i < anzpars; i++) {
				t.pars[i] = pars[i].Substitute();
				if (!t.pars[i].ground) t.ground = false;
			}
			return t;
		}	
	}
	public Term Clone() {
		// Klonen des Terms mit allen Untertermen
		ConstTerm t;
		int i;
		t = new ConstTerm(symbol,anzpars,ground);
		for (i = 0; i < anzpars; i++)
			t.pars[i] = pars[i].Clone();
		return t;
	}
	public Term clone1() {
		return new ConstTerm(symbol,anzpars,ground);
	}

}


