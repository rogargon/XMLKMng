/*

Name: Concat.java

Version: 1.0

Purpose:

History:

*/

package edu.unika.aifb.builtins;


import edu.unika.aifb.inference.BuiltinFunc;
import edu.unika.aifb.inference.Variable;
import edu.unika.aifb.inference.Atom;
import edu.unika.aifb.inference.StringTerm;
import java.lang.Math;


public class Concat extends BuiltinFunc {
	static StringTerm leer = new StringTerm("",0,true);

	public boolean evaluable(Atom t) {
		int i, anzbound = 0;
		boolean ok = true;
		for (i = 0; i < 3; i++) {
			if (t.terms[i].ground) {
				anzbound++;
				if (!(t.terms[i] instanceof StringTerm))
					return false;
			}
		}
		if ((anzbound < 2) && !t.terms[2].ground)
			return false;
		return true;
	}

	public void eval(Atom t) {
		int i,len;
		if (evaluable(t)) {
			if (t.terms[0].ground && t.terms[1].ground && t.terms[2].ground) {
				if (0 == ((StringTerm)t.terms[0]).s.compareTo(((StringTerm)t.terms[1]).s + ((StringTerm)t.terms[2]).s))
					insert(t);
			}
			else if (t.terms[0].ground && t.terms[1].ground) {
				t.terms[2] = new StringTerm(((StringTerm)t.terms[0]).s+((StringTerm)t.terms[1]).s,0,true);
				insert(t);
			}
			else if (t.terms[0].ground && t.terms[2].ground) {
				if (((StringTerm)t.terms[2]).s.startsWith(((StringTerm)t.terms[0]).s)) {
					t.terms[1] = new StringTerm(((StringTerm)t.terms[2]).s.substring(((StringTerm)t.terms[0]).s.length()),0,true);
					insert(t);
				}
			}
			else if (t.terms[1].ground && t.terms[2].ground) {
				if (((StringTerm)t.terms[2]).s.endsWith(((StringTerm)t.terms[1]).s)) {
					try {
						t.terms[0] = new StringTerm(((StringTerm)t.terms[2]).s.substring(0,((StringTerm)t.terms[2]).s.length()-((StringTerm)t.terms[1]).s.length()),0,true);
					}
					catch (StringIndexOutOfBoundsException e) {}
					insert(t);
				}
			}
			else if (t.terms[2].ground) {
				len = ((StringTerm)t.terms[2]).s.length();
				t.terms[0] = leer;
				t.terms[1] = t.terms[2];
				insert(t);
				t.terms[1] = leer;
				t.terms[0] = t.terms[2];
				insert(t);
				for(i = 1; i < len; i++) {
					t.terms[1] = new StringTerm(((StringTerm)t.terms[2]).s.substring(i),0,true);
					try {
						t.terms[0] = new StringTerm(((StringTerm)t.terms[2]).s.substring(0,i),0,true);
					}
					catch (StringIndexOutOfBoundsException e) {
					}
					insert(t);
				}
			}
		}
	}		
}

