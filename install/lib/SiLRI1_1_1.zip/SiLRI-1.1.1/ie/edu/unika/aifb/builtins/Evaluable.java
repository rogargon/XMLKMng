/*

Name: Evaluable.java

Version: 1.01

Purpose:

History:
7.5. corrected import and package declaration SDe 

*/

package edu.unika.aifb.builtins;
import edu.unika.aifb.inference.Variable;
import edu.unika.aifb.inference.Atom;
import edu.unika.aifb.inference.NumTerm;
import edu.unika.aifb.inference.ConstTerm;
import edu.unika.aifb.inference.Term;
import java.lang.Math;


import edu.unika.aifb.inference.BuiltinFunc;

public class Evaluable  extends BuiltinFunc {


  public void w(String X) { System.out.println(X);}


	public boolean evaluable(Atom t) {
		
  return (t.terms[1].ground) &&  ((t.terms[0]  instanceof NumTerm) || (t.terms[0] instanceof Variable));
  }



  public void eval(Atom t) {
  int i;
  int anzbound = 0;
  boolean ok = true;
		
      double old, newd;
      if(t.terms[1].ground) {
          newd = compute(t.terms[1]);
	  if(t.terms[0].ground)
             {  if (t.terms[0]  instanceof NumTerm)
		    {  old = ((NumTerm) t.terms[0]).zahl;
                       if(Math.abs(old - newd) < 0.0001) ok = true;
                       else ok = false;
                    }
                          else ok = false;
		       }
                else { if(t.terms[0] instanceof Variable) 
                             ((Variable) t.terms[0]).subsby = new NumTerm(newd,0,true);
		}
		       
	       if (ok) {insert(t);}
        
      }
  }
		


 double compute(Term t)
  { 
    if(t instanceof ConstTerm)
      { ConstTerm t1 = (ConstTerm) t;
      if( t1.symbol==0 && t1.anzpars==2)    // 0 = PLUS
	{  // System.out.println("PLUS!");

           return compute(t1.pars[0])  +  compute(t.pars[1]); }

     if( t1.symbol==1 && t1.anzpars==2)    // 1 = MINUS
	{ return compute(t1.pars[0]) - compute(t.pars[1]); }

     if( t1.symbol==0 && t1.anzpars==1)    // 0 = unary PLUS
	{ return compute(t1.pars[0]); }

     if( t1.symbol==1 && t1.anzpars==1)    // 1 = aunary MINUS
	{ return -1* compute(t.pars[0]); }



       if(t1.symbol== 2 && t1.anzpars==2)   // *= mul 
       { return compute(t.pars[0]) * compute(t.pars[1]); }
      
					       
       if(t1.symbol== 3 && t1.anzpars==2)   // *= mul 
       { return compute(t.pars[0]) / compute(t.pars[1]); }
     

      if(t1.symbol== 4 && t1.anzpars==2)   // *= div 
       { return compute(t.pars[0]) % compute(t.pars[1]); }

      if(t1.symbol== 5 && t1.anzpars==0)   // *= E 
       { return Math.E; }

       if(t1.symbol== 6 && t1.anzpars==0)   // *= PI
        { return Math.PI; }

       if(t1.symbol== 7 && t1.anzpars==0)   // *= RANDOM
         { return Math.random(); }


       //   System.out.println("Anz " + t1.anzpars + " Symbol" + t1.symbol);
     if(t1.symbol== 8 && t1.anzpars==1)   // *= abs 
       { return Math.abs(compute(t1.pars[0]));
        }
     
         if(t1.symbol==9 && t1.anzpars==1)   // *= sin
       {  return Math.sin(compute(t1.pars[0])); }
     
         if(t1.symbol== 10 && t1.anzpars==1)   // *= cos 
       { return Math.cos(compute(t.pars[0])); }
     
         if(t1.symbol== 11 && t1.anzpars==1)   // *= tan
       { return Math.tan(compute(t.pars[0])); }
     
         if(t1.symbol== 12 && t1.anzpars==1)   // *= asin
       { return Math.asin(compute(t.pars[0])); }
     
         if(t1.symbol== 13 && t1.anzpars==1)  
       { return Math.acos(compute(t.pars[0])); }
     
         if(t1.symbol== 14 && t1.anzpars==1)  
       { return Math.ceil(compute(t.pars[0])); }
     
         if(t1.symbol== 15 && t1.anzpars==1)   
       { return Math.floor(compute(t.pars[0])); }
     
         if(t1.symbol== 16  && t1.anzpars==1)   
       { return Math.exp(compute(t.pars[0])); }
     
          if(t1.symbol== 17  && t1.anzpars==1)   
       { return Math.exp(compute(t.pars[0])); }

      if(t1.symbol== 18  && t1.anzpars==1)   
       { /* return Math.rint(compute(t.pars[0])); */}
     
      if(t1.symbol== 19  && t1.anzpars==1)   
       { return Math.sqrt(compute(t.pars[0])); }
     
      if(t1.symbol== 20  && t1.anzpars==1)   
       { return Math.round(compute(t.pars[0])); }
     

      if(t1.symbol== 21  && t1.anzpars==2)       // max
       { return Math.max(compute(t.pars[0]),compute(t.pars[1])); }
     
      if(t1.symbol== 22 && t1.anzpars==2)        // min 
       { return Math.min(compute(t.pars[0]),compute(t.pars[1])); }
     
      if(t1.symbol== 23  && t1.anzpars==2)      // pow
       { return Math.pow(compute(t.pars[0]),compute(t.pars[1])); }    

  }

    if(t instanceof NumTerm)
      { 
	return ((NumTerm)t).zahl; }


    if(t instanceof Variable)
      {                      
	return 0.0; 
      }
    
        return 0.0;   // this is a difficult thing for debugging - we should tink about it
  }


}

  


