/*

Name: SParser.java

Version: 1.0

Purpose:

History:

*/

package edu.unika.aifb.inference;

import java.util.Date;
import java.util.Random;
import java.lang.Long;
import java.io.*;
import java.util.*;
import java.net.*;

class JanParseError1 extends Exception {
	public JanParseError1(String s) {
		super(s);
	}
}


public class SParser extends Object {

	char[] text;
	int index = 0;
	public boolean show = false;
	
	public SParser(String s) {
 		index = 0;
       		text = (s+"\0").toCharArray(); 
	}

	public SParser() {
 		index = 0;
 	}
 		
	public void ParseString(String s) {
 		index = 0;
       		text = (s+"\0").toCharArray(); 
	}

	boolean sign() {
		if ((text[index] == '+') || (text[index] == '-')) return true;
		else return false;
	}
	boolean digit() {
		if (('0' <= text[index]) && ('9' >= text[index]))
			return true;
		else
			return false;
	}

	int number() throws JanParseError1 {
		Integer zahl;
		String s;
		int startindex;
		startindex = index;
		while (digit()) {index++;}
		s = new String(text,startindex,index-startindex);
		try {
			zahl = new Integer(s);
		}
		catch (NumberFormatException p) {
			throw new JanParseError1("number expected");
		}
		return zahl.intValue();
	}

	String Zeichenkette() throws JanParseError1 {
		int startindex;
		String s;
		startindex = index;
		while ((text[index] != '"') && (text[index] != '\0')) index++;
		if (text[index] == '\0') throw new JanParseError1("closing \" expected");
		index++;
		try {
			s = new String(text,startindex+1,index-startindex-2);
		}
		catch (StringIndexOutOfBoundsException p) {
			throw new JanParseError1("");
		}
		return s;
	}
		

	double Zahl() throws JanParseError1 {
		Double zahl;
		String s;
		int startindex;
		startindex = index;
		// Vorkommateil
		if (!digit() && !sign()) throw new JanParseError1("+,- or digit expected");
		if (sign()) {
			index++;
			if (!digit()) throw new JanParseError1("digit expected");
		}	
		while (digit()) {index++;}
		// Nachkommateil
		if (text[index] == '.') {
			index++;
			while (digit()) {index++;}
		}
		// Exponent
		if ((text[index] == 'e') || (text[index] == 'E')) {
			index++;
			if (!sign() && !digit()) throw new JanParseError1("+,- or digit expected");
			else {
				if (sign()) {
					index++;
					if (!digit()) throw new JanParseError1("digit expected");
				}
				while (digit()) {index++;}
			}
		}
		s = new String(text,startindex,index-startindex);
		try {
			zahl = new Double(s);
		}
		catch (NumberFormatException p) {
			throw new JanParseError1("number expected");
		}
		return zahl.doubleValue();
	}

   Term term() throws JanParseError1 {
        int anz = 0, sym = 0, i;
        String s = "";
        double zahl = 0.0;
	Term t = null;
        Term ts[];
	char ch = text[index++];
	switch (ch) {
		case 'c': sym = number(); /*System.out.print("c"); System.out.print(sym); */ break;
		case 'n': zahl = Zahl(); /*System.out.print(zahl);*/  break;
		case '"': s = Zeichenkette(); /*System.out.print("\""); System.out.print(s); System.out.print("\""); */ break;
		case 'X': sym = number(); /*System.out.print("X"); System.out.print(sym); */ break;
	}
	if (text[index] == 'l') {
		index++;
		anz = number();
	}
	ts = new Term[anz];
	if (anz > 0) {
		ts = new Term[anz];
		// System.out.print("(");
		for(i = 0; i < anz; i++) {
			ts[i] = term();
			// if (i < anz-1) System.out.print(",");
		}
		// System.out.print(")");
	}
	switch (ch) {
		case 'c': t = new ConstTerm(sym,ts); break;
		case 'n': t = new NumTerm(zahl,ts); break;
		case '"': t = new StringTerm(s,ts);  break;
		case 'X': t = new Variable(sym); break;
	}
	return t;
   }

  Atom atom() throws JanParseError1 {
	int sym,len,i;
	Atom a;
	Term ts[];
	index++; len = number();
	ts = new Term[len];
	// System.out.print("(");
	for(i = 0; i < len; i++) {
		ts[i] = term();
		// if (i < len-1) System.out.print(",");
	}
	// System.out.print(")");
	a = new Atom(ts);
	return a;
   }

   Fact fact() throws JanParseError1 {
	int sym,len,i;
	Atom a;
	Term ts[];
 	index++; sym = number(); 
	// System.out.print("p"); System.out.print(sym);
	a = atom();
	// System.out.println(); System.out.print("Fact: "); 
	return new Fact(sym,a.terms);
   }
	

   Body body() throws JanParseError1 {
	Atom a;
	Body b;
	int sym;
	boolean neg = false;
        if (text[index] == '-') { /*System.out.print("-");*/ neg = true;}
	index++; sym = number(); // System.out.print("p"); System.out.print(sym);
	a = atom();
	b = new Body(sym,neg,a.terms);
	return b;
   }

   Head head() throws JanParseError1 {
	Atom a;
	Head h;
	int sym;
	index++; sym = number(); // System.out.print("p"); System.out.print(sym);
	a = atom();
	h = new Head(sym,a.terms);
	return h;
   }


   Rule rule() throws JanParseError1 {
	int anzheads, anzbodies,i;
	Head heads[];
	Body bodies[];
	Rule r;
	index++;
	anzheads=number(); heads = new Head[anzheads];
	index++;
	anzbodies=number(); bodies = new Body[anzbodies];
	for(i = 0; i < anzheads; i++) {
		heads[i]=head();
		// if (i < anzheads-1) System.out.print(" & ");
	}
	// System.out.print(" <- ");
	for(i = 0; i < anzbodies; i++) {
		bodies[i]=body();
		// if (i < anzbodies-1) System.out.print(" & ");
	}
	r = new Rule(heads,bodies);
	// System.out.println(); System.out.print("Rule: "); 
	return r;
  }

  public void decode(RuleSet rs, DB db, String s) throws JanParseError1 {
       Rule r;
       Atom a;
       Fact f;
       index = 0;
       text = (s+"\0").toCharArray(); 
       if (text[0] == 'l') {
		if (rs != null) {
			r = rule();
			if (show) {r.print(System.out); System.out.println();}
			else rs.AddRule(r);
		}
	}
       else if (db != null) {
		f = fact();
		if (show) {f.print(System.out); System.out.println();}
		else db.AddFact(f.symbol,new GroundAtom(f.terms));
	}
       // System.out.println(".");
   }

 public void decode(RuleSet rs, String s) throws JanParseError1 {
       Rule r;
       Atom a;
       Fact f;
       index = 0;
       text = (s+"\0").toCharArray(); 
       if (text[0] == 'l') {
		r = rule();
		if (show) {r.print(System.out); System.out.println();}
		else rs.AddRule(r);
	}
       else {
		f = fact();
		if (show) {f.print(System.out); System.out.println();}
		else rs.AddFact(f.symbol,new GroundAtom(f.terms));
	}
       // System.out.println(".");
   }
 }

