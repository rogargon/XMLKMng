/*

Name: DatabaseServer.java

Version: 1.0

Purpose:

History:

*/

package edu.unika.aifb.inference;

import java.io.*;
import java.net.*;
import java.util.*;



class dbserv {
    private static final int PORTNUM = 1236;
    private ServerSocket serverSocket;
    private DB db;
    private SParser spars;
 

    public dbserv(DB db) {
        //super("TriviaServer");
        try {
            serverSocket = new ServerSocket(PORTNUM);
            System.out.println("DB Server up and running ...");
        }
        catch (IOException e) {
            System.err.println("Exception: couldn't create socket");
            System.exit(1);
        }
	this.db = db;
	spars = new SParser();
    }


    public void run() {
        Socket clientSocket = null;
	
        // Look for clients and ask trivia questions
        while (true) {
            // Wait for a client
            if (serverSocket == null)
                return;
            try {
                clientSocket = serverSocket.accept();
            }
            catch (IOException e) {
                System.err.println("Exception: couldn't connect to client socket");
                System.exit(1);
            }

            // Perform the question/answer processing
            try {
                DataInputStream is = new DataInputStream(clientSocket.getInputStream());
                PrintStream os = new PrintStream(new BufferedOutputStream(clientSocket.getOutputStream()), false);
                String outLine, inLine;
		long sec1, sec2;
		int symbol = -1;
		Atoms R,A = null;
		Fact f;
		GroundAtom a;

	      	// os.println("start");
	      	// os.flush();

              	while (true) {	
			// create new filter  
	      		// read in a line
	        	inLine = is.readLine();
	        	if (inLine.length() > 0) {
				// Einlesen der Filterterme
				System.out.println("Filterterme: ");
				while (!inLine.equals("stop")) {
					spars.ParseString(inLine);
					try {
						f = spars.fact();
						f.print(System.out); System.out.println();
						//System.out.println(r.hrelation.stellen);
					}
					catch (JanParseError1 e){
						f = null;
					}
					if (A == null) {
						A = new Atoms(f.terms.length);
						symbol = f.symbol;
						//System.out.print("Pr�diaktsymbol: "); System.out.println(symbol);
					}
					a = A.Insert(new Atom(f.terms));
					inLine = is.readLine();
				}
						
				//System.out.print("DBServer: "); System.out.println(inLine);

				// Zugriff auf Datenbank
				R = db.GetFacts(symbol, A);
				//System.out.println("Ergebnis:");
				if (R != null) {
					//R.print(System.out);
					R.internalize(os,symbol);
					os.println("stop"); // Beenden des Clients
					os.flush(); 
					break;
				}
				R = null;
			}
		}
	        // Cleanup
		// System.out.println("Closing Client");
	        os.close();
	        is.close();
	        clientSocket.close();
            }
            catch (Exception e) {
                System.err.println("Exception: " + e);
                e.printStackTrace();
            }
        }
    }

  
}

public class DatabaseServer {
    public static void main(String[] args) throws IOException {
	RandomAccessFile file;
	DB db;
	int i;
	db = new DB();
	for(i = 0; i < args.length; i++) {
		file = new RandomAccessFile(args[i],"r");    
		db.read(file);
		file.close();
	}
        dbserv server = new dbserv(db);
        server.run();
    }
}
