/*

Name: SimpleSubst.java

Version: 1.0

Purpose: 
Represents simple answer substitutions returned from the
inference engine

History:
3.5.99 created SDe
*/




package edu.unika.aifb.inference;



public class SimpleSubst{ 
	String Var;
	FTerm Substitution;
	SimpleSubst(String Var,FTerm Substitution){
		this.Var = Var; this.Substitution = Substitution;
	}

	public String toString(){
		return Var + " = " + Substitution.toString();
	}
  	public String getVariable(){
		return Var;
	}
	public FTerm getTerm(){
		return Substitution;
	}
}                      

