/*

Name: Substitution.java

Version: 1.0

Purpose:

History:

*/

package edu.unika.aifb.inference;

public class Substitution extends Atoms {
	// beinhaltet eine Menge von Variablensubstitutionen
	int index[]; // index[i] gibt die Spalte in der Tabelle fuer Variable i an
	
	public Substitution(int index[], int anzvars) {
		// Index ist ein Index auf die Variablen s.o.
		// anzvars gibt die Anzahl aller Variablen an
		super(anzvars);
		this.index = index;
	}
	
	public Atoms Substitute(Atom A) {
		// Substitution der Variablen im Atom A durch die Menge der Variablensubstitutionen
		Atoms result;
		result = new Atoms(A.terms.length);
		result.Substitute(A,this,index);
		return result;
	}
}




