/*

Name: FreeMem.java

Version: 1.0

Purpose:

History:

*/

package edu.unika.aifb.inference;

class MemNode {
	boolean used = true;
	MemNode mem = null;      	     // Listenverzeigerung
	MemNode lastmem = null;     	 // R�ckw�rtsverzeigerung
}


public class FreeMem {
	//  Speicherverwaltung realisiert durch Freispeicherliste
	protected MemNode free = null; 			// Freispeicherliste
	protected MemNode used = null; 			// Liste der benutzten Knoten
	protected MemNode mark1 = null, mark2 = null; // Markierungen in Liste der benutzten Knoten zur Freigabe
	public  int anzFree() {
		MemNode h;
		int i;
		for (h = free, i = 0; h != null; h = h.mem, i++);
		return i;
	}
	public int anzUsed() {
		MemNode h;
		int i = 0;
		if (used != null)
			for (h = used, i = 1; h.mem != used; h = h.mem, i++);
		return i;
	}
	
	public void Register(MemNode a) {
		// F�ge Knoten in Belegtliste ein
		if (used == null) {
			a.mem = a; a.lastmem = a; used = a;
		}
		else {
			a.mem = used; a.lastmem = used.lastmem;
			used.lastmem.mem = a; used.lastmem = a;
			used = a; 
		}
	}
		
	public MemNode GetFree() {
		MemNode a = null;
		if (free != null) {
			// Knoten in Freispeicherliste vorhanden
			// entnehme Knoten aus Freispeicherliste
			a = free; free = a.mem; 
			Register(a);
			a.used = true;
		}
		return a;
	}
	private void unregister(MemNode a) {
		// L�sche Knoten aus Belegtliste
		if (a.mem == a) // Belegtliste besteht nur aus diesem einen Knoten
			used = null;
		else {
			if (used == a) 
				used = a.mem;
			a.lastmem.mem = a.mem;
			a.mem.lastmem = a.lastmem;
		}
	}
	private void insertfree(MemNode a) {
		// F�ge Knoten in Freispeicherliste ein
		a.mem = free; free = a; a.lastmem = null;
	}
	public void Dispose(MemNode a) {
		if (a.used) {
			// L�sche Knoten aus Belegtliste
			unregister(a);
			// F�ge Knoten in Freispeicherliste ein
			insertfree(a);
			a.used = false;
		}
	}	
	public void Extract(MemNode a) {
		// tauscht einen Knoten in der Belegtliste an den Anfang der Belegtliste. Dadurch kann er der
		// Freigabe entgehen (wenn er sich dann nicht mehr zwischen der Markierung 1 und der Markierung 2
		// befindet
		if ((mark2 != null) && (mark2 != mark1)) {
			if (mark2 == a) 
				// versetze Markierung, falls sie gerade auf a zeigt
				mark2 = mark2.mem;
			else {
				// L�sche Knoten aus Belegtliste
				unregister(a);
				// F�ge Knoten wieder (vorne) in Belegtliste ein
				Register(a);
			}
		}
	}
						
	public void Mark1() {
		// Markiere aktuellen Knoten
		mark1 = used; mark2 = null;
		//System.out.print("Mark1 Free: "); System.out.print(anzFree()); System.out.print("  Used: "); System.out.println(anzUsed()); 
	} 
	public  void Mark2() {
		// Markiere aktuellen Knoten
		mark2 = used;
		//System.out.print("Mark2 Free: "); System.out.print(anzFree()); System.out.print("  Used: "); System.out.println(anzUsed()); 
	}  
	public  void Clear() {
		// fuegt die Liste der benutzten Knoten zwischen den Markierungen in die Liste der freien Knoten ein
		// Vorsicht eine sehr gefaehrliche Methode
		if ((mark2 != null) && (mark2 != mark1)) {
			if ((mark1 == null) && (mark2 == used)) {
				used.lastmem.mem = free; free = mark2; 
				used = null;
			}
			else if ((mark1 == null) && (mark2 != used)) {
				used.lastmem.mem = free; free = mark2;
				mark2.lastmem.mem = used; used.lastmem = mark2.lastmem;
			}				
			else if ((mark1 != null) && (mark2 == used)) {
				mark1.lastmem.mem = free; free = mark2;
				used.lastmem.mem = mark1; mark1.lastmem = used.lastmem;
				used = mark1;
			}
			else if ((mark1 != null) && (mark2 != used)) {
				mark1.lastmem.mem = free; free = mark2;
				mark2.lastmem.mem = mark1; mark1.lastmem = mark2.lastmem;
			}
			mark1 = null; mark2 = null;
		}
	}				
				
}

class FreeMems {
	FreeMem mems[];
	public FreeMems(int maxindex) {
		int i;
		mems = new FreeMem[maxindex];
		for (i = 0; i < maxindex; i++)
			mems[i] = new FreeMem();
	}
	public  int anzFree(int index) {
		return mems[index].anzFree();
	}
	public int anzUsed(int index) {
		return mems[index].anzUsed();
	}
	public void Register(MemNode a, int index) {
		mems[index].Register(a);
	}
		
	public MemNode GetFree(int index) {
		return mems[index].GetFree();
	}
	public void Dispose(MemNode a, int index) {
		mems[index].Dispose(a);
	}	
	public void Extract(MemNode a, int index) {
		mems[index].Extract(a);
	}		
	public void Mark1(int index) {
		mems[index].Mark1();
	} 
	public  void Mark2(int index) {
		mems[index].Mark2();
	} 
	public  void Clear(int index) {
		mems[index].Clear();
	}	
	public int Length() {
		return mems.length;
	}
}			
	
