/*

Name: BuiltinConfig.java

Version: 1.01

Purpose:
Configures Builtins. Builtins are introduced into the system
by adding them to the list builtinList. New entries must(!) be added
to the end of the list to keep old programs saved in the internal
format running.

History:

7.5.99 Added support for new builtin mechanism. SDe

*/


package edu.unika.aifb.builtins;
import java.io.*;
import edu.unika.aifb.inference.BuiltinFunc;
import edu.unika.aifb.inference.AVLTreeSymbol;


public class BuiltinConfig{
static Builtin [] builtinList ={
	new Builtin("Add",3, new edu.unika.aifb.builtins.Add()),
	new Builtin("Concat",3, new edu.unika.aifb.builtins.Concat()),
	new Builtin("unify",2, new edu.unika.aifb.builtins.Equal()),
	new Builtin("isNum",1,new edu.unika.aifb.builtins.isNum()),
	new Builtin("less",1, new edu.unika.aifb.builtins.less()),
	new Builtin("isString",1,new edu.unika.aifb.builtins.isString()),
	new Builtin("isConst",1,new edu.unika.aifb.builtins.isConst()),
	new Builtin("greater",2, new edu.unika.aifb.builtins.greater()),
	new Builtin("string2double",2, new edu.unika.aifb.builtins.string2double())	
	};

public static int getBuiltinNumber(){
	return 	builtinList.length;
}


static public void init(AVLTreeSymbol PSymbols){
	int i = builtinList.length;
	for(int k=0;k<i;k++){
		PSymbols.searchAndInsert(builtinList[k].getSymbol(),builtinList[k].getArity());
	}
}



static public BuiltinFunc newInstance(int symbol){
	return builtinList[symbol].newInstance();
}


}

