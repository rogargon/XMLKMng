/*

Name: DynamicVector.java

Version: 1.0

Purpose:

History:

*/

package edu.unika.aifb.inference;

import java.io.*;
import java.util.Enumeration;
import java.util.NoSuchElementException;
/*
A vector class that that can dynamically grow with logarithmic time. c * ln e
(e = number of elements) the constant c is very small.
If base is a power of 2 (e.g. 1024) then multiplication
and remainder computation can be done with bit-shift operations)

This datastructure consists of a tree of arrays, which can dynamically add root elements.
The leaf arrays are storing the data. With level 2 and base 1000 this array
can store 1000x1000 = 1000000 elements. Max overhead is 1999 x pointersize,
is 1001 elements are present.

The difference to the original vector class is, that enlargements need no reallocation
of the whole array.
*/


public class DynamicVector{

Object [] root;
int level =0;
final int base = 1024;
final int basepow = 10;
int pow;
Object[] nextarray;
int nextpointer;
int number;
int capacity;

public DynamicVector() {
	root = new Object[base];
	nextarray = root;
	nextpointer = 0;
	capacity = base;
	number=0;
	level=0;
	//pow = 1;
	pow = 0;
 }

public final int addElement(Object o){ 
	if(nextpointer<base){
		//System.out.println("Storing "+ o + " at "+ new Integer(nextpointer));
		nextarray[nextpointer++] = o;
		return number++;
	}
	else
		return setElementAt(o,number);
}

public final int setElementAt(Object o, int position){
 Object [] aktarray = root;
 //System.out.println("Trying to insert " + o + " at level "+ aktlevel + " .current number is " + number + " capacity is " + capacity);
 if(position < capacity){ 
	int aktnumber = position; 
	int aktlevel = level; 
	int aktpow = pow;
 	int index;
  	while(aktlevel > 0) { 
      		index = aktnumber >> aktpow;              
		aktnumber = aktnumber & ( (1 << aktpow) -1);
		aktpow=aktpow - basepow;
      		if(aktarray[index] == null) {
  			aktarray[index] = new Object[base];

      		}
        aktarray = (Object[])  aktarray[index];
        aktlevel --;
        }
        aktarray[aktnumber] = o; 
	if(position >= number)
		{ number = position + 1;
	          nextarray=aktarray;
		  nextpointer=aktnumber + 1;
		}
	/* if we have insertet at a position larger then the current size, the new size is 
	   the position
        */
        return position;
        }
 else{
  root = new Object[base];
  root[0] = aktarray;
  level+=1;
  capacity*=base;
  //pow*=base;
  pow +=basepow;
  return addElement(o);
}
}

public final Object elementAt(int position){
 int aktcapacity = capacity;
 int aktlevel = level;
 int aktpow = pow;
 Object [] aktarray = root;
 //System.out.println("Trying to insert " + o + " at level "+ aktlevel + " .current number is " + number + " capacity is " + capacity);
 
 int aktnumber = position;
 if(aktnumber < number){
 	int index;
  	while(aktlevel > 0) { 
		index = aktnumber >> aktpow;              
		aktnumber = aktnumber & ( (1 << aktpow) -1);
		aktpow-= basepow;             
      		if(aktarray[index] == null) {
  			aktarray[index] = new Object[base];
      		}
        aktarray = (Object[])  aktarray[index];
        aktlevel --;
        }
        return aktarray[aktnumber]; 
 }
 else{
   throw new ArrayIndexOutOfBoundsException(position + " >= " + number);
}


}
// deletion of objects is a bit tricky - still to be done.
/*
    public final void removeElementAt(int index) {
	if (index >= elementCount) {
	    throw new ArrayIndexOutOfBoundsException(index + " >= " + 
						     elementCount);
	}
	else if (index < 0) {
	    throw new ArrayIndexOutOfBoundsException(index);
	}
	int j = elementCount - index - 1;
	if (j > 0) {
	    System.arraycopy(elementData, index + 1, elementData, index, j);
	}
	elementCount--;
	elementData[elementCount] = null; 
    }
*/



public final int size(){
	return number;
}

public final boolean isEmpty(){
	return number==0;
}

public final Object firstElement(){
	return elementAt(0);
}

public final Enumeration elements() {
	return new DynamicVectorEnumerator(this);
}


public static void main(String[] argv)
{
  DynamicVector v = new DynamicVector();
  for(int i = 0;i<300000;i++)
      v.addElement(new Integer(i));
  System.out.println(" 0 " + v.elementAt(0));
  System.out.println(" 50 " + v.elementAt(50));
  System.out.println(" 5000 " + v.elementAt(1000));
  System.out.println(" 50000 " + v.elementAt(50000));
  System.out.println(" 11150 " + v.elementAt(11150));
}
}


class DynamicVectorEnumerator implements Enumeration {
    DynamicVector v;
    int count;

    DynamicVectorEnumerator(DynamicVector v) {
	this.v = v;
	count = 0;
    }

    public boolean hasMoreElements() {
	return count < v.number;
    }

    public Object nextElement()  {
	    if (count < v.number) {
		return v.elementAt(count++);
	    }
	throw new NoSuchElementException("DynamicVectorEnumerator");
    }



}
