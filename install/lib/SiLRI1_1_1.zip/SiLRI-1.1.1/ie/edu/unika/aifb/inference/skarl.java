/*

Name: skarl.java

Version: 1.0

Purpose:

History:

*/

package edu.unika.aifb.inference;

import java.util.*;
import java.util.Date;
import java.net.*;
import java.io.*;


class KEvaluator1 extends Object{
	RuleSet ruleset = new RuleSet();
	boolean stratified = false;
		
	public void out() {
		Rule q;
		String out;
		Substitution subs;
		int i;
		for(q = ruleset.NextQuery(null); q != null; q = ruleset.NextQuery(q)) {
			/*
			for (i = 0; i < q.anzbodies; i++)
				out = out.concat(ruleset.Result(q,i).toString(comp.preds[q.bodies[i].symbol],comp.constants));
			*/
			subs = ruleset.Substitution(q);
			subs.print(System.out);
		}
	}

	public void init() {
		ruleset.Optimize2();
		if (!ruleset.Stratify()) {
			stratified = false;
	   	}
	}

	public void eval(int evalmethod) {
	// naive = 0, dynamic = 1, wellfoundedaf = 2, wellfounded = 3
		if (ruleset == null) System.out.println("Please compile first\n");
		else if (((evalmethod == 0) || (evalmethod == 1)) && !stratified) System.out.println("Cannot evaluate because rules are not stratified\n");
		else {
			// ruleset.AddRule(query);
			ruleset.EvaluationMethod(evalmethod);
			ruleset.EvalQueries();
			out();
			//ruleset.DeleteRule(query);
			//ruleset.ClearRuleSet();
		}
	}
	

	public void Read(RandomAccessFile f) {
		String error = "";
		String out ="";
		stratified = true;
		try {
			ruleset.read(f);
		}
		catch (IOException p) {
			System.out.println(p.getMessage());
		}
    }
 } 

 
public class skarl {
	static public void main(String args[]) throws IOException {
		String s = "";
		KEvaluator1 eval;
		RandomAccessFile file;
		long sec1, sec2;
		int i;

		eval = new KEvaluator1();
		System.out.println("Loading files");
		for(i = 0; i < args.length; i++) {
			file = new RandomAccessFile(args[i],"r");    
			eval.Read(file);
		}
		System.out.println("Starting optimization");
		eval.init();
		System.out.println("Starting evaluation");
		sec1 = (new Date()).getTime();
		eval.eval(1);
		sec2 = (new Date()).getTime();
		System.out.print("milliseconds used: "); System.out.println(sec2-sec1);
	}
}


		
		
		
	
	
