/*

Name: ATMS.java

Version: 1.0

Purpose:

History:

*/

package edu.unika.aifb.inference;

public class ATMS {
	GroundAtom atom = null;
	ATMS next = null;
	boolean pos = true;
	
	public ATMS(GroundAtom a) {
		atom = a;
	}
}

