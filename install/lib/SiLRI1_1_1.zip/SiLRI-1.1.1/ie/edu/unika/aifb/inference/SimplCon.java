/*
	A basic Java class stub for a Win32 Console Application.
 */


public class SimplCon {

	public SimplCon () {

	}

    static public void main(String args[]) {
        System.out.println("Hello World");
    }

}

