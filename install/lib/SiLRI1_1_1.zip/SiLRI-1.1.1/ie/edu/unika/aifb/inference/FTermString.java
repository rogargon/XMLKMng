/*

Name: FTermString.java

Version: 1.01

Purpose: 
Represents general logic program string terms

History:
3.5.99 created from FNode.java
*/

package edu.unika.aifb.inference;
import java.util.*;
import java.lang.*;
import java.io.*;

public class FTermString extends FTerm {
String Contents;

FTermString(String S){
	Contents = S;
}

final public String toString(){ 
	return "\""+Contents+"\"";              
}


final public String toSimple(){
	 return "\"" + Contents + "\"";
}


final public String toXSB(){
	return "\'" + Contents.replace('\'','�') + "\'";              
}

final FTerm copyTerm(Hashtable h){ 
	return new FTermString(new String(Contents));        
}

final FTerm copyTerm(){
	return new FTermString(new String(Contents));
}


final public String getContent(){
	return Contents;
}

final public Term toTerm(Hashtable mapping,IntWrapper varcount,AVLTreeSymbol Symbols, AVLTreeString Strings){ 
	int k = Strings.searchAndInsert(Contents);
	return new ConstTerm(k+Config.STRINGSTART);
}

}
