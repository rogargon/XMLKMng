/*

Name: string2double.java

Version: 1.0

Purpose:
Realizes Builtin: string2double

History:

*/




package edu.unika.aifb.builtins;
import edu.unika.aifb.inference.BuiltinFunc;
import edu.unika.aifb.inference.Variable;
import edu.unika.aifb.inference.Atom;
import edu.unika.aifb.inference.NumTerm;
import edu.unika.aifb.inference.StringTerm;



public class string2double  extends BuiltinFunc {

	public boolean evaluable(Atom t) {
        return (t.terms[1]  instanceof NumTerm) || (t.terms[0] instanceof Variable);
    }

  
	public void eval(Atom t) {
  //System.out.println("string2double:" + t.terms[0].toString()+ " ," + t.terms[1]);
  boolean ok = false; 
    if ((t.terms[1]  instanceof NumTerm) && (t.terms[0] instanceof Variable))
	{  
	((Variable) t.terms[0]).subsby = new StringTerm(Double.toString(((NumTerm)t.terms[1]).zahl)); ok = true; 
        }
    else 
       if ((t.terms[1]  instanceof NumTerm) && (t.terms[0] instanceof StringTerm) && 
	   ((StringTerm) t.terms[0]).s.equals(Double.toString(((NumTerm)t.terms[1]).zahl))) ok=true;
    else
      if ((t.terms[1]  instanceof Variable) && (t.terms[0] instanceof StringTerm))
	{  ((Variable)t.terms[1]).subsby = new NumTerm( Double.valueOf(((StringTerm) t.terms[0]).s).doubleValue()) ; 
	ok = true; }

  if (ok) {insert(t);}
 
  }
}
  
