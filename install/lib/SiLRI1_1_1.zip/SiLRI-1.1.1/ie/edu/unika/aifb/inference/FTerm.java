/*

Name: FTerm.java

Version: 1.01

Purpose: 
Represents general logic program terms

History:
3.5.99 created from FNode.java
*/

package edu.unika.aifb.inference;
import java.util.*;
import java.lang.*;
import java.io.*;

public class FTerm extends Object {
 
FTerm copyTerm(Hashtable h)
{return null;}

FTerm copyTerm() { return null; }
 

 void FreeBoundVariables(Vector Free,Vector Bound)
{ return;}

public Term toTerm(Hashtable mapping,IntWrapper varcount,AVLTreeSymbol Symbols,AVLTreeString Strings) 
  { System.out.println("Wrong Method");return null;}
public String toXSB() { return toString();}
public String toSimple() { return toString();}

}








class FTermInteger extends FTerm {
 Integer Contents;
FTermInteger(Integer I)
  {      Contents = I; }

final public String toString()
   { return Contents.toString();              
      }

final public String toXSB()
   { return Contents.toString();              
      }

final public String toSimple(){
	return Contents.toString(); 
}


final FTerm copyTerm(Hashtable h)
{ return new FTermInteger(new Integer(Contents.intValue()));        
}


final FTerm copyTerm()
 { return new FTermInteger(new Integer(Contents.intValue()));}


final public Term toTerm(Hashtable mapping,IntWrapper varcount,AVLTreeSymbol  Symbols, AVLTreeString String)
 { return new NumTerm((double) Contents.doubleValue()); }



}

class FTermFloat extends FTerm {
 Double Contents;
FTermFloat(Double D)
  {      Contents = D; }
final public String toString()
   { return Contents.toString();              
      }

final public String toSimple()
   { return Contents.toString();              
      }



final public Term toTerm(Hashtable mapping,IntWrapper varcount,AVLTreeSymbol Symbols, AVLTreeString Strings)
 { return new NumTerm((double) Contents.doubleValue()); }



final FTerm copyTerm(Hashtable h)
{ return new FTermFloat(new Double(Contents.doubleValue()));        
}

final FTerm copyTerm()
  {return new FTermFloat(new Double(Contents.doubleValue()));}

}

class FTermConstant extends FTerm {

String s;

FTermConstant(String s) 
  { this.s=s;}


final public Term toTerm(Hashtable mapping,IntWrapper varcount,AVLTreeSymbol Symbols, AVLTreeString Strings)
 { 
   int k=Symbols.searchAndInsert(s,0);
   return new ConstTerm(k);

}
   



final public String toString()
   { 
     return s;
}


final public String toXSB(){ 
	return "f_" + s;
}

final public String toSimple(){ 
	return "f_" + s;
}

final FTerm copyTerm(Hashtable h)
{ return new FTermConstant(s);}

final FTerm copyTerm()
{ return new FTermConstant(s);}




final void FreeBoundVariables(Vector Free,Vector Bound){ 
}



}



class FTermVariable extends FTerm {
String v ;

FTermVariable(String v)
  { this.v=v; }

final public String toString(){ 
	return v;
} 
           
 
final public String toXSB (){ 
	return "X_"+v;
}  

final public String toSimple(){ 
	return "X_"+v;
}


final public Term toTerm(Hashtable mapping,IntWrapper varcount,AVLTreeSymbol Symbols, AVLTreeString Strings)
 { Integer kk = (Integer) mapping.get(v); 
   if(kk==null) { kk=new Integer(varcount.i); varcount.i++; mapping.put(v,kk);}
   return new Variable(kk.intValue());
}

final FTerm copyTerm(Hashtable h)
{ FTermVariable copy;
  String n  = (String) h.get(v);
  if(n!=null) copy = new FTermVariable(n); 
  else copy = new FTermVariable(v);
  return copy;          
}

final FTerm copyTerm()
 {  return new FTermVariable(v); }


final void FreeBoundVariables(Vector Free,Vector Bound)
{ 
  if(!Bound.contains(v) && !Free.contains(v))               
                 Free.addElement(v);
               
}         

}

