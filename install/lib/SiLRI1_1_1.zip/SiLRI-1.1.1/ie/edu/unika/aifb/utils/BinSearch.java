/*

Name: BinSearch.java

Version: 1.0

Purpose: Simple  Binary Search Utility

History: 2.5.99 First Version SDe

*/

package edu.unika.aifb.utils;


import java.util.Vector;

public class BinSearch { 


  public static int binarySearch(Object s[], Object x,Comparator cmp) {
	int low = 0;
	int high = s.length - 1;
	int mid;
	int result;

        while( low <= high ){
		mid = ( low + high ) / 2;
			result=cmp.compare(s[ mid ],x )	;

		if(result < 0 )
			low = mid + 1;
		else 
			if( result > 0 )
				high = mid - 1;
			else	{//System.out.println("Found it at " + new Integer(mid));
				return mid;}
        }
	return -1;
   }

  public static int binarySearch(Vector v, Object x,Comparator cmp) {
    	int low = 0;
	int high = v.size() - 1;
	int mid;
	int result;

        while( low <= high ){
		mid = ( low + high ) / 2;
		result=cmp.compare(v.elementAt(mid),x )	;

		if(result< 0 )
			low = mid + 1;
		else 
			if( result > 0 )
				high = mid - 1;
			else
				return mid;
        }
	return -1;
   }
  
}

