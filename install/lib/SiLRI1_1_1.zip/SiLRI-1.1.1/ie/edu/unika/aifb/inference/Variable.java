/*

Name: Variable.java

Version: 1.0

Purpose:

History:

*/

package edu.unika.aifb.inference;

import java.io.*;
import java.util.*;
import java.net.*;

public class Variable extends Term {
	// type == 1
	public int symbol;			// Variablensymbol
	public int hsymbol;			// Feld zum Retten des Variablensymbols bei Umbenennungen
	//public int index;
	public Term subsby = null;		// hier wird ein Term zur Substitution der Variablen angeh�ngt
	public Variable next = null;		// Verzeigerung der Variablen innerhalb eines Atoms
	
	public int type() {return 1;}

	public Variable(int sym) {
		super(0,false);
		symbol = sym;
		ground = false;
		subsby = null;
		groundlevel = 1;
	}
	
	public boolean isVariable() {return true;}
	
	public String toString1() {
	    return "X"+String.valueOf(symbol);
	}
	public void print1(PrintStream p) {
		p.print("X"); p.print(symbol);
		if (subsby != null) {
			p.print('/');
			subsby.print(p);
		}
	}
	public void internalize1(PrintStream p) {
		// System.out.print("X"); System.out.print(symbol);
		//f.writeBytes("X"+String.valueOf(symbol));
		p.print("X" + String.valueOf(symbol));
		/*
		if (subsby != null) {
			System.out.print('/');
			subsby.print();
		} */
	}

	public String toString1(String p[], String f[], String st[]) {
		// Ausgabe der Variablen mit dem Substitutenden als String, 
		Character ch;
		String s;
		ch = new Character((char)((int)(('X')+symbol)));
		s = ch.toString();
		if (subsby != null) {
			s = s.concat("/");
			s = subsby.toString(p,f,st);
		}
		return s;
	}
	public void print1(PrintStream pr, String p[], String f[], String s[]) {
		// Ausgabe der Variablen mit dem Substitutenden als String, 
		Character ch;
		ch = new Character((char)((int)(('X')+symbol)));
		pr.print(ch.toString());
		if (subsby != null) {
			pr.print("/");
			subsby.print(pr,p,f,s);
		}
	}
	public int CompareEqual(Term t) {
		// vergleicht zwei Variablen aufgrund ihrer Symbole
		return symbol <= ((Variable)t).symbol?(symbol<((Variable)t).symbol?-1:0):1;	
	}	
	protected boolean occurs(Variable v) {
		// Occurence Check
		if (subsby != null) return subsby.occurs(v);
		else if (symbol == v.symbol) return true;
		else return false;
	}
	
	public boolean Unify(Term t2) {
		// Unifikation der Variable this mit Term t2
		if (this.subsby != null) 
			// first is a variable and is already substituted
			return t2.Unify(this.subsby);
		else if (t2 instanceof Variable) {
			// second is also a variable 
			if (((Variable)t2).subsby != null) 
				// second is substituted 
				return this.Unify(((Variable)t2).subsby);
			else // both are variables which are not substituted
				((Variable)t2).symbol = symbol;
			return true;
			}
		else {
			// second is no variable
			if (!t2.occurs(this)) {
				this.subsby = t2;
				return true;
				}
			else
				// first variable occurs in second term 
				return false;
		}
	}
	public boolean Match(Term t2) {
		if (this.subsby != null) 
			// first is a variable and is already substituted
			return this.subsby.Match(t2);
		else if ((t2 instanceof Variable) && (((Variable)t2).subsby != null)) {
			this.subsby = ((Variable)t2).subsby;
			return true;
		}
		else {
			// Substitutiere Variable mit t2
			this.subsby = t2;
			return true;
		}
	}
	public Term Substitute() {
		// Durchf�hrung einer Substitution, d.h. die Variable wird durch ihren
		// Substituenden im Term ersetzt
		// Dabei werden alle oberen Terme (�berhalb von Variablen) neu generiert
		if (subsby != null) 
			if (subsby.ground) return subsby;
			else return subsby.Substitute();
		else {
			return new Variable(symbol);
		}
	}
	
	
	public Term Clone() {
	// kloniert den Term
		Variable v;
		v = new Variable(this.symbol);
		if (subsby != null)
			v.subsby = subsby.Clone();
		return v;
	}

	public Term clone1() {
		return new Variable(this.symbol);
	}
}
	
