/*

Name: Atom.java

Version: 1.0

Purpose:

History:

*/

package edu.unika.aifb.inference;

import java.io.*;
import java.util.*;
import java.net.*;



public class Atom extends GroundAtom {
	// Instanz repraesentiert ein Atom

	public Variable variables = null; 		// verkettete Liste von Variablen des Atoms
	public int anzvars = 0; 			// Anzahl Variablen
	int maxvarsym = -1;				// maximales Variablensymbol des Atoms
	public long vars = 0;				// Bitleiste der Variablen
	public long mark = 0;				// Markierungen

	public Atom(Term t[]) {
		super(t);
		Variables();
		//no = Atom.actno++;
	}

	public Atom(int anz) {
		super(anz);
		variables = null;
	}

	
	public void MarkVar(int i) {
		// setzt in den Variablenmarkierungen Bit i
		vars |= (1 << i);
	}

	public boolean isMarked(int i) {
		// fragt in den Markierungen Bit i ab
		if (((1 << i) & mark) != 0) 
			return true;
		else 
			return false;
	}
	public void Mark(int i) {
		// setzt in den Markierungen Bit i
		mark |= (1 << i);
	}

/*
	public void Copy(int i1, Atom t2, int i2) {
		if ((t2).terms[i2] != null)
			terms[i1] = variables((t2).terms[i2]);
		else
			terms[i1] = null;
	}
*/

	public void Variables() {
		int i;
		Variable v;
		variables = null; anzvars = 0; maxvarsym = -1; vars = 0;
		for (i = terms.length-1; i >= 0; i--) 
			terms[i] = variables(terms[i]);
	}


	private Term variables(Term t) {
		Variable v;
		int i;
		if (!t.ground) {
			if (t instanceof Variable) {
				for (v = variables; (v != null) && (v.symbol != ((Variable)t).symbol); v=v.next);
				if (v == null) {
					((Variable)t).next = variables;
					variables = (Variable)t;
					if (((Variable)t).symbol > maxvarsym) 
						maxvarsym = ((Variable)t).symbol;
					anzvars++;
					vars = vars | (1L << ((Variable)t).symbol);
					return t;
				}
				else {
					//t.Dispose();
					t = null;
					return v;
				}	
			}
			else if (t.anzpars > 0) 
				for (i=0; i < t.anzpars; i++)
					t.pars[i] = variables(t.pars[i]);
		}
		return t;
	}

	public boolean Unify(Atom A) {
		// Unifiziert zwei Atome miteinander
		int max,i;
		Variable v;
		boolean res = true;
		if (A.maxvarsym > maxvarsym) max = A.maxvarsym;
		else max = maxvarsym;
		// Retten und Umbenennen von Variablen
		for (v = A.variables; v != null; v = v.next) {
			v.hsymbol = v.symbol;
			v.symbol += max+1;
		}
		for (v = variables; v != null; v = v.next) {
			v.hsymbol = v.symbol;
		}
		// Unifikation
		for (i = 0; (i < terms.length) && res; i++)
			res = terms[i].Unify(A.terms[i]);
		// Zurueckbenennen von Variablen
		for (v = A.variables; v != null; v = v.next)
			v.symbol = v.hsymbol;
		for (v = variables; v != null; v = v.next)
			v.symbol = v.hsymbol;
		return res;	
	}

	public boolean Match(GroundAtom A) {
		// Matcht Atom mit Atom A
		int i;
		Variable v;
		boolean res = true;
		for (i = 0; (i < terms.length) && res; i++)
			res = terms[i].Match(A.terms[i]);
		return res;
	}	

	public void ClearVariables() {
		// L�scht alle Variablensubsitutionen
		Variable v;
		for(v = variables; v!= null; v=v.next) 
			v.subsby = null;
	}
	
	public Atom Extend(int index[], int len) {
		// legt ein neues Atom B der L�nge len an. Alle Terme an der Stelle i in A werden an die Stelle index[i]
		// in B kopiert. Alle anderen Stellen in B werden durch Variablen aufgef�llt
		Atom t, tnew;
		int i;
		boolean inserted;
		// neues Atom
		tnew = new Atom(len);
		tnew.and = true;
		// kopiere Terme
		for (i = 0; index[i] != -1; i++) {
			tnew.terms[index[i]] = this.terms[i];
		}
		// erg�nze um Variablen
		for (i = 0; i < len; i++)
			if (tnew.terms[i] == null) 
				tnew.terms[i] = new Variable(i);
		// registriere Variablen
		tnew.Variables();
		this.Supports(tnew);
		return tnew;
	}

	public Atom Generalize(Atom A) {
		Atom t = null;
		int i;
		int max;
		Variable v;
		boolean res = true;
		if ((this != A) && (CompareAtoms(A) != 0)) {
			// Umbenennen von Variablen
			if (A.maxvarsym > maxvarsym) max = A.maxvarsym;
			else max = maxvarsym;
			// Retten und Umbenennen von Variablen
			for (v = A.variables; v != null; v = v.next) {
				v.hsymbol = v.symbol;
				v.symbol += max+1;
			}
			for (v = variables; v != null; v = v.next) {
				v.hsymbol = v.symbol;
			}
			// Unifikation
			for (i = 0; (i < terms.length) && res; i++)
				res = terms[i].Unify(A.terms[i]);
			if (res) {
				this.ClearVariables();
				A.ClearVariables();
				t = new Atom(terms.length);
				for(i = 0; i < terms.length; i++) 
					t.terms[i] = this.terms[i].Generalize(A.terms[i]);
				t.Variables();
			}
			// Zurueckbenennen von Variablen
			for (v = A.variables; v != null; v = v.next)
				v.symbol = v.hsymbol;
			for (v = variables; v != null; v = v.next)
				v.symbol = v.hsymbol;
		}
		return t;
	}		
}

		




