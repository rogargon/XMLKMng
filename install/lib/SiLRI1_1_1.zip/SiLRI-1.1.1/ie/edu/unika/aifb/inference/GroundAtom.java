/*

Name: GroundAtom.java

Version: 1.0

Purpose:

History:

*/

package edu.unika.aifb.inference;

import java.io.*;
import java.util.*;
import java.net.*;


public class GroundAtom {
	// Instanz repraesentiert ein GrundAtom
	// public int len = 0;				Gr��e der Reihung, Anzahl Indices
	public GroundAtom next2 = null;			// Verkettung von Tupeln
	public long lasttouched = 0;			// Zeitstempel f�r letzten Touch
	public boolean deleted = false;			// L�schmarke	

	public Term terms[]; 				// Terme des Atoms
	ATMS supported = null;				// Verweise auf abhaengige Atome
	int no_supports = 0;				// Anzahl Verweise auf dieses Atom
	int max_supports = 0;
	boolean and = false;				// f�r ATMS
	// public static int actno = 0;

	public GroundAtom(Term t[]) {
		int anz = 0;
		int i;
		if (t != null) anz = t.length;
		//this.len = anz;
		terms = new Term[anz];
		for(i = 0; i < anz; i++)
			terms[i] = t[i];
		//no = Atom.actno++;
	}

	public GroundAtom(int anz) {
		//len = anz;
		terms = new Term[anz];
		//no = Atom.actno++;
		//hashit();
	}

	public void Supports(GroundAtom a) {
		ATMS h;
			for (h = this.supported; (h!=null) && (h.atom != a); h = h.next);
			if (h == null) {
				h = new ATMS(a);
				h.next = this.supported;
				this.supported = h;
				a.changeSupport(true,this);			
				if (a.max_supports < a.no_supports) a.max_supports = a.no_supports;
			}
			else
				// System.out.println("doppelt")
				;
	}
	
	public void path1() {
		ATMS at;
		//System.out.print(this.no);System.out.print(":");
		System.out.print(this.no_supports);
		if (and) System.out.print("a");
		System.out.print("->");
		for(at = this.supported; at != null; at = at.next) {
			at.atom.path1();
			if (at.next != null) System.out.print("|");
		}
	}
	
	
	boolean path() {
		ATMS at;

			for(at = this.supported; at != null; at = at.next) {
				if (at.atom.path()) {
					System.out.print("<-");
					//System.out.print(this.no);
					return true;
				}
			}

		return false;
	}
		
	public void negDependency(GroundAtom a) {
		ATMS h;
		for (h = this.supported; (h!=null) && (h.atom != a); h = h.next);
		if (h == null) {
			h = new ATMS(a);
			h.pos = false;
			h.next = this.supported;
			this.supported = h;
			// a.changeSupport(false, this);
			//if (this.path())
				//System.out.println();
		}
		else
			// System.out.println("doppelt")
			;
	}
	
	public void Disports(GroundAtom a) {
		ATMS h;
		for (h = this.supported; h!=null; h = h.next) {
			if (!h.pos)
				(h.atom).changeSupport(false,a);
		}
	}

	private void changeSupport(boolean pos, GroundAtom source) {
		ATMS at;
		if (this != source) {
			if (pos) {
				no_supports++;
				if (this.deleted) {
					if ((and && (no_supports >= max_supports)) || (!and && (no_supports > 0))){
						this.deleted = false;
						//this.print(); System.out.print(" : undeleted by ");System.out.println(source.no);
						for(at = this.supported; at != null; at = at.next)
							at.atom.changeSupport(at.pos, source);
					}
				}
			}
			else {
				no_supports--;
				if (!this.deleted) {
					if (and || (!and && (no_supports <= 0))) {
						this.deleted = true;
						//this.print(); System.out.print(" : deleted by ");System.out.println(source.no);
						for(at = this.supported; at != null; at = at.next)
							at.atom.changeSupport(!at.pos,source);
					}
				}
			}
		}
	}				

	public int Compare(int i1, GroundAtom t2, int i2) {
		return terms[i1].Compare((t2).terms[i2]);
	}
	

	public int CompareAtoms(GroundAtom t) {
		// vergleicht zwei Tupel miteinander
		int i;
		int res = 0;
		for (i = 0; (i < terms.length) && (res == 0); i++)
			res = terms[i].Compare((t).terms[i]);
		return res;
	}

	public void print(PrintStream p) {
		int i;
		Variable v;
		// System.out.print("lastchanged: "); System.out.print(lastchanged);
		for (i = 0; i < terms.length; i++) {
			if (terms[i] != null) terms[i].print(p);
			else p.print("null");
			if (i<terms.length-1) p.print(",");
		}	
		// System.out.print(" : "); System.out.print(no);			
	}

	public void internalize(PrintStream p) {
		int i;
		//System.out.print("l"); System.out.print(len);	
		//f.writeBytes("l"+String.valueOf(len));
		p.print("l" + String.valueOf(terms.length));
		for (i = 0; i < terms.length; i++) {
			if (terms[i] != null) terms[i].internalize(p);
		}
	}

	public void internalize(PrintStream p, int sym) {
		int i;
		//System.out.print("p"); System.out.print(sym); 
		// f.writeBytes("p"+String.valueOf(sym));
		p.print("p"+String.valueOf(sym) + "l"+String.valueOf(terms.length));
		//System.out.print("l"); System.out.print(len);	
		// f.writeBytes("l"+String.valueOf(len));
	
		for (i = 0; i < terms.length; i++) {
			if (terms[i] != null) terms[i].internalize(p);
		}	

	}

	public void print(PrintStream p,int sym) {
		int i;
		Variable v;
		p.print("p"); p.print(sym); p.print("(");
		for (i = 0; i < terms.length; i++) {
			if (terms[i] != null) terms[i].print(p);
			else p.print("null");
			if (i<terms.length-1) p.print(",");
		}
		p.print(")");	
	}
	public void print(PrintStream p,int sym,String pr[],String f[], String s[]) {
		int i;
		Variable v;
		p.print(pr[sym]); p.print("(");
		for (i = 0; i < terms.length; i++) {
			if (terms[i] != null) terms[i].print(p,pr,f,s);
			else p.print("null");
			if (i<terms.length-1) p.print(",");
		}
		p.print(")");	
	}

	public void print(PrintStream p, String pr[],String f[], String s[]) {
		int i;
		Variable v;
		//System.out.println("Atom.print");
		// System.out.print("lastchanged: "); System.out.print(lastchanged);
		for (i = 0; i < terms.length; i++) {
			p.print("\""); //System.out.print("->");
			if (terms[i] != null) terms[i].print(p,pr,f,s);
			//if (terms[i] != null) terms[i].print(System.out,pr,f,s);
			else p.print("null");
			p.print("\""); //System.out.print("<-"); 
			if (i<terms.length-1) {
				p.print(",");
				//System.out.print(",");
			}
		}
		//System.out.println();
		// System.out.print(" : "); System.out.print(no);			
	}


	public String toString(String p, String pr[],String f[], String st[]) {
		int i;
		Variable v;
		String s = p+"(";
		for (i = 0; i < terms.length; i++) {
			if (terms[i] != null) s = s.concat(terms[i].toString(pr,f,st));
			if (i<terms.length-1) s = s.concat(",");
		}
		s = s.concat(")");
		return s;				
	}
}
