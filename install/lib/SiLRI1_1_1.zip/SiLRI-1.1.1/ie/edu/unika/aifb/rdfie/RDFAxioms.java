/*

Name: RDFAxioms.java

Version: 1.0

Purpose:

History:

*/

package edu.unika.aifb.rdfie;

public class RDFAxioms {

static final String RDFAXIOMS = 

 "FORALL O,A,V O[A->>V] <- triple(A,O,V).\n" ; 




}
