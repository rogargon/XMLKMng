/*

Name: Karl.java

Version: 1.0

Purpose:
Historic Reasons, obsolete now, (use Evaluator.java)

History:

*/

package edu.unika.aifb.inference;

import java.util.*;
import java.util.Date;
import java.net.*;
import java.io.*;


public class KARL extends Object {
   public static void main(String args[]) throws Exception
   { 
     Evaluator  eval = new Evaluator();
     eval.init();   
     int i=0;
    while(i< args.length)
    {
      if(args[i].equals("-simple"))
         if ( i !=args.length - 1)
              { eval.compileSimpleFile(args[i+1]); i=i+2;}
         else System.out.println("Not enough arguments!");

      else {eval.compileFile(args[i]);i++;};
      
     }
     eval.stratify();
    eval.evaluate();
//    eval.naive();
//   eval.dynamic();
//   eval.Wellfounded();
     eval.printSubs(eval.computeSubstitutions());
   
 }

}


