/*

Name: Recompiler.java

Version: 1.0

Purpose:

History:

*/

package edu.unika.aifb.inference;


import java.util.*;
import java.util.Date;
import java.net.*;
import java.io.*;

public class Recompiler  {
	public static int STRINGSTART = 100000;
	public String strings[];
	public String predicates[];
	public String functions[];



int wandle(String s) {
	Integer zahl = new Integer(0);
	try {
		zahl = new Integer(s);
	}
	catch (NumberFormatException p) {
		System.out.println("number expected");
	}
	return zahl.intValue();
} 


public void readSymTab(RandomAccessFile f) throws IOException {
	int anzfsyms, anzstrings, anzpsyms;
	String s;
	int i;
	int index, index1;
	int symbol;
	String str;
	int arity;
	int len;


	s = f.readLine(); anzfsyms = wandle(s); functions = new String[anzfsyms];
	s = f.readLine(); anzstrings = wandle(s); strings = new String[anzstrings]; 
	s = f.readLine(); anzpsyms = wandle(s); predicates = new String[anzpsyms];
 
	
	
	for(i = 0; i < anzfsyms; i++) {
		s = f.readLine(); 
		index = s.indexOf(' '); 
		symbol = wandle(s.substring(0,index)); 
		index1 = s.indexOf(' ',index+1); 
		//System.out.println(s); System.out.print("   ");
		// System.out.print(index); System.out.print(" "); System.out.println(index1);
		arity = wandle(s.substring(index+1,index1)); 
		str = s.substring(index1+1); 
		functions[symbol] = str;
		// FSymbols.searchAndInsert(str,arity); 
	} 

	for(i = 0; i < anzstrings; i++) {
		s = f.readLine(); 
		index = s.indexOf(' '); 
		symbol = wandle(s.substring(0,index)); 
		index1 = s.indexOf(' ',index+1); 
		//System.out.print(s); System.out.print("   ");
		// System.out.print(index); System.out.print(" "); System.out.println(index1);
		len = wandle(s.substring(index+1,index1)); 
		str = s.substring(index1+1); 
		while (str.length()<len) {
			str = str + f.readLine();
		}

		s = str.replace((char)13,' '); 
		/*
		if (symbol == 422) {
			System.out.println(s);
			System.out.println(s.indexOf((char)13));
			for (int j = 0; j < s.length(); j++) {
					System.out.print((int)s.charAt(j)); 
					System.out.print("|");
				}
			System.out.println();
		}
		*/
		strings[symbol] = s;
		//Strings.searchAndInsert(str); 
		// System.out.println(str);
	} 

	for(i = 0; i < anzpsyms; i++) {
		s = f.readLine(); 
		index = s.indexOf(' '); 
		symbol = wandle(s.substring(0,index)); 
		index1 = s.indexOf(' ',index+1); 
		//System.out.print(s); System.out.print("   ");
		// System.out.print(index); System.out.print(" "); System.out.println(index1);
		arity = wandle(s.substring(index+1,index1)); 
		str = s.substring(index1+1); 
		// PSymbols.searchAndInsert(str,arity); 
		predicates[symbol] = str;
	} 

}



}                      
