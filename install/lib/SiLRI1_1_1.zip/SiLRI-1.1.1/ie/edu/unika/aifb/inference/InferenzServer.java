/*

Name: InferenzServer.java

Version: 1.0

Purpose:

History:

*/



package edu.unika.aifb.inference;

import java.io.*;
import java.net.*;
import java.util.*;


class KEvaluator {
	RuleSet ruleset = new RuleSet();
	boolean stratified = false;
	SParser spars = new SParser();
	Recompiler recomp;
	Vector rules;
	int pegel = 0;


	public KEvaluator(RandomAccessFile f) throws IOException {
		recomp = new Recompiler();
		recomp.readSymTab(f);
		rules = new Vector();
	}
	

	public void AddRule(String inLine) {	
		Rule r;
		spars.ParseString(inLine);
		try {
			r = spars.rule();
			System.out.print("Query: "); r.print(System.out); System.out.println();
			//System.out.println(r.hrelation.stellen);
		}
		catch (JanParseError1 e){
			r = null;
		}
		rules.addElement(r);
		ruleset.AddRule(r);
	}

	public void DeleteRules() {
		int i;
		Rule r;
		for(i = 0; i < rules.size(); i++) {
			r = (Rule)rules.elementAt(i);
			ruleset.DeleteRule(r);
		}
		rules.removeAllElements();
		//pegel = rules.size();
	}	

	public void out(PrintStream p) {
		Rule q;
		String out;
		Substitution subs;
		int i;
//System.out.println("Answering");
		for(q = ruleset.NextQuery(null); q != null; q = ruleset.NextQuery(q)) {
//q.print(System.out);
//System.out.println();
//		for(i = pegel; i < rules.size(); i++) {
			//q = (Rule)rules.elementAt(i);
			if (q.anzheads == 0) {
				subs = ruleset.Substitution(q);
				subs.print(p,recomp.predicates, recomp.functions, recomp.strings);
				subs.print(System.out);
			}
		}
	}

	public void init() {
		stratified = true;
		if (!ruleset.Stratify()) {
			stratified = false;
	   	}
		ruleset.Optimize2();
	}

	public void eval(int evalmethod, PrintStream p) {
	// naive = 0, dynamic = 1, wellfoundedaf = 2, wellfounded = 3
		if (ruleset == null) System.out.println("Please compile first\n");
		else if (((evalmethod == 0) || (evalmethod == 1)) && !stratified) System.out.println("Cannot evaluate because rules are not stratified\n");
		else {
			ruleset.EvaluationMethod(evalmethod);
			ruleset.EvalQueries();
			out(p);
			//ruleset.DeleteRule(query);
			// ruleset.ClearRuleSet();
		}
	}
	

	public void Read(RandomAccessFile f) {
		String error = "";
		String out ="";
		try {
			ruleset.read(f);
		}
		catch (IOException p) {
			System.out.println(p.getMessage());
		}
    	}
 } 
  


class TriviaS2 {
    private static final int PORTNUM = 1234;
    private ServerSocket serverSocket;
    private KEvaluator eval;
    private SParser spars;

    public TriviaS2(KEvaluator ev) {
        //super("TriviaServer");
        try {
            serverSocket = new ServerSocket(PORTNUM);
            System.out.println("Inference Server up and running ...");
        }
        catch (IOException e) {
            System.err.println("Exception: couldn't create socket");
            System.exit(1);
        }
	eval = ev;
	spars = new SParser();
    }


    public void run() {
        Socket clientSocket = null;
	
        // Look for clients and ask trivia questions
        while (true) {
            // Wait for a client
            if (serverSocket == null)
                return;
            try {
                clientSocket = serverSocket.accept();
            }
            catch (IOException e) {
                System.err.println("Exception: couldn't connect to client socket");
                System.exit(1);
            }

            // Perform the question/answer processing
            try {
                DataInputStream is = new DataInputStream(clientSocket.getInputStream());
                PrintStream os = new PrintStream(new BufferedOutputStream(clientSocket.getOutputStream()), false);
                String outLine, inLine;
		long sec1, sec2;

	      	os.println("start");
	      	os.flush();

              	while (true) {	  
	      		// read in a line
	        	inLine = is.readLine();
	        	if (inLine.length() > 0) {
				//System.out.print("InferenzServer: "); System.out.println(inLine);
				if (inLine.equals("stop")) {
					sec1 = (new Date()).getTime();
					// naive = 0, dynamic = 1, wellfoundedaf = 2, wellfounded = 3
					eval.eval(1,os);
					sec2 = (new Date()).getTime();
					System.out.print("milliseconds used: "); System.out.println(sec2-sec1);
					eval.DeleteRules();
					os.println("stop"); // Beenden des Clients
					os.flush(); 
					break;
				}
				else {
					eval.AddRule(inLine);
				}
			}
		}
	        // Cleanup
		// System.out.println("Closing Client");
	        os.close();
	        is.close();
	        clientSocket.close();
            }
            catch (Exception e) {
                System.err.println("Exception: " + e);
                e.printStackTrace();
            }
        }
    }

  
}

public class InferenzServer {
    public static void main(String[] args) throws IOException {
	RandomAccessFile file;
	KEvaluator ev;
	int i;
	file = new RandomAccessFile(args[0],"r");  
	ev = new KEvaluator(file);
	file.close();
	for(i = 1; i < args.length; i++) {
		file = new RandomAccessFile(args[i],"r");    
		ev.Read(file);
		file.close();
	}
	ev.init();
        TriviaS2 server = new TriviaS2(ev);
        server.run();
    }
}
