/*

Name: IESiRPAC.java

Version: 1.0

Purpose:

History:

*/

package edu.unika.aifb.rdfie;

import org.w3c.rdf.*;



import java.net.URL;
import java.util.*;
import java.io.*;

public class IESiRPAC extends SiRPAC
{
   public IESiRPAC(String s){
	super(s);
}

   RDFEvaluator eval=null;
 
   public static void computeTriples (String ResourceName, boolean fetchSchemas,RDFEvaluator eval) throws Exception {
	
	
	IESiRPAC compiler = new IESiRPAC (System.getProperties().getProperty("org.xml.sax.parser"));
	compiler.eval = eval;

	if (fetchSchemas) {
	    compiler.fetchSchemas (true);
	}

	URL url = null;
	try {
	    url = new URL (ResourceName);
	} catch (Exception e) {
	    url = new URL ("file", null, ResourceName);
	}
	RDFSource source = new RDFSource(url);

	compiler.setRDFSource (source);
	compiler.fetchRDF ();

	String sErrors = compiler.errors ();
	if (sErrors != null && sErrors.length() > 0) {
	    System.out.println ("Errors during parsing:\n"+sErrors);
	} else {
	    compiler.printTriples (System.out);
	}
	/*
	String sWarnings = compiler.warnings ();
	if (sWarnings != null && sWarnings.length() > 0) {
	    System.out.println ("Warnings during parsing:\n"+sWarnings);
	}
	*/
    }





   public void addTriple (Property predicate,
			   Resource subject,
			   RDFnode object) {
	/**
	 * If there is no subject (about=""), then use the URI/filename where
	 * the RDF description came from
	 */
	if (predicate == null) {
	    addWarning ("Predicate null when subject="+subject+" and object="+object);
	    return;
	}

	if (subject == null) {
	    addWarning ("Subject null when predicate="+predicate+" and object="+object);
	    return;
	}

	if (object == null) {
	    addWarning ("Object null when predicate="+predicate+" and subject="+subject);
	    return;
	}

	if (subject.toString() == null ||
	    subject.toString().length() == 0) {
	    subject = new Resource(source());
	}


	eval.addTriple(predicate, subject, object);

    }



}



