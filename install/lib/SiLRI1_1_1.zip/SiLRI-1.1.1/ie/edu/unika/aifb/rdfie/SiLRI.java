/*

Name: SiLRI.java

Version: 1.0

Purpose:

History:

*/

package edu.unika.aifb.rdfie;

import java.util.*;
import java.util.Date;
import java.net.*;
import java.io.*;


public class SiLRI extends Object {
 


   public static void main(String args[]) throws Exception
   { 
   RDFEvaluator engine = new RDFEvaluator();
   engine.init();
   int i=0;      
   while(i< args.length)
    {
      if(args[i].equals("-rdf"))
         if ( i !=args.length - 1) {
     		{engine.compileRDFFile(args[i+1]); i=i+2;};
   	}
         else System.out.println("Not enough arguments!");
      else if(args[i].equals("-rdfurl"))
         if ( i !=args.length - 1) {
     		{engine.compileRDFURL(args[i+1]); i=i+2;};
   	}
         else System.out.println("Not enough arguments!");

      else if(args[i].equals("-simple"))
         if ( i !=args.length - 1)
              { engine.compileSimpleFile(args[i+1]); i=i+2; }
         else System.out.println("Not enough arguments!");
      else {engine.compileFile(args[i]);i++;};
     }
   engine.stratify();
   engine.evaluate();
   engine.printSubs(engine.computeSubstitutions());  
   }      
}

