/*

Name: TermSet.java

Version: 1.0

Purpose:

History:

*/

package edu.unika.aifb.inference;

import java.util.Hashtable;

class ListElement extends Object {
	Object element;
	Object key;
	ListElement next;
	public ListElement(Object el) {
		element = el;
		next = null;
	}
}

class Liste extends Object {
	ListElement first;
	ListElement last;
	ListElement act;
	Hashtable hash;
	int anz;
	
	public Liste() {
		first = new ListElement(null);
		last = new ListElement(null);
		first.next = last;
		act = null;
		anz = 0;
		hash = new Hashtable();
	}

	public boolean Append(Object key, Object element) {
		if (!hash.containsKey(key)) {
			try {
				last.element = element;
				last.key = key;
				hash.put(key,last);
				last.next = new ListElement(null);
				last = last.next;
				anz++;
			}
			catch (NullPointerException np) {
				System.out.println("Hashtable overflow");
			}
			return true;
		}
		else {
			return false;
		}
	}	

	public void Concat(Liste list) {
	    ListElement l;
	    boolean b;
	    for(l = list.first.next; l != list.last; l = l.next)
		b = Append(l.key, l.element);
	}
	
	private ListElement get(Object key) {
		ListElement l;
		if (hash.containsKey(key)) {
			l = (ListElement)hash.get(key);
			return l;
		}
		else
		    return null;
	}		

	public boolean In(Object key) {
		return hash.containsKey(key);
	}

	public void Intersect(Liste list1, Liste list2) {
	    ListElement l,l1;
	    boolean b;
	    if (list1.anz < list2.anz) {
	    	for(l = list1.first.next; l != list1.last; l = l.next) {
			if (list2.In(l.key))
				b = Append(l.key, l.element);
		}
	    }
	    else {
	    	for(l = list2.first.next; l != list2.last; l = l.next) {
			if (list1.In(l.key))
				b = Append(l.key, l.element);
		}
	    }
	}
	
	public Object Get(Object key) {
		ListElement l;
		l = get(key);
		if (l != null)
		    return l.element;
		else
		    return null;
	}	
	

	public void ClearList() {
		ListElement l;
		//hash = new Hashtable();
		for(l = first.next; l != last; l = l.next) 
			hash.remove(l.key);
		first = last = act = null;
		anz = 0;
	}
				



	public Object First() {
		act = first.next;
		if (act != null)
			return act.element;
		else
			return null;
	}

	public Object Next() {
		if (act != null)
			act = act.next;
		if (act != last)
			return act.element;
		else
			return null;
	}

}
			
public class TermSet extends Object {
	public static int anz = 0;
	public int anzterms;
	Liste liste;

	public TermSet() {
		liste = new Liste();
		anzterms = 0;
	}
	
	public boolean Insert(Term t) {
		boolean inserted;
		inserted = liste.Append(t.toString(),t);
		anzterms = liste.anz;
		if (inserted) {
			anz++;
			return true;
		}
		else
			return false;
	}

	public void Union(TermSet TS) {
	    this.liste.Concat(TS.liste);
	    this.anzterms = liste.anz;
	}
	
	public void Intersect(TermSet T1, TermSet T2) {
	    liste.Intersect(T1.liste, T2.liste);
	    this.anzterms = liste.anz;
	}

	public boolean In(Term t) {
		return liste.In(t.toString());
	}
	public void print() {
	    ListElement l;
	    for(l = this.liste.first.next; l != this.liste.last; l = l.next) {
		((Term)l.element).print(System.out);
		System.out.println();
	    }
	}
}
