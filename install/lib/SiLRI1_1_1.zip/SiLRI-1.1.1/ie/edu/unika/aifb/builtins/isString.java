/*

Name: isString.java

Version: 1.0

Purpose:

History:

*/

package edu.unika.aifb.builtins;

import edu.unika.aifb.inference.BuiltinFunc;
import edu.unika.aifb.inference.Variable;
import edu.unika.aifb.inference.Atom;
import edu.unika.aifb.inference.NumTerm;


public class isString extends BuiltinFunc {

	public void eval(Atom t) {
		
		if (t.terms[0].ground && (t.terms[0].isStringTerm())) {
			insert(t);	
		}
	}			
}

