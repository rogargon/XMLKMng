/*

Name: Fact.java

Version: 1.0

Purpose:

History:

*/




package edu.unika.aifb.inference;

import java.io.*;
import java.util.*;
import java.net.*;

public class Fact {
	public int symbol;
	public Term terms[];
	public Fact(int sym, Term ts[]) {
		terms = ts;
		symbol = sym;
	}
	public void print(PrintStream p) {
		int i;
		p.print("p"); p.print(symbol); p.print("(");
		for (i = 0; i < terms.length; i++) {
			terms[i].print(p);
			if (i < terms.length-1) p.print(",");
		}
		p.print(").");
	}
}
