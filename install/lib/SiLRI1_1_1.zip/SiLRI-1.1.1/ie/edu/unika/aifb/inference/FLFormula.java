/*

Name: FLFormula.java

Version: 1.0

Purpose: 
Classes needed to represent Frame-Logic formulas

History:

*/

package edu.unika.aifb.inference;

import java.util.*;
import java.lang.*;


public class FLFormula extends Object 
{ 
/*  
 static final String[] METHODSYMBOL = {"att_",  
                                       "setatt_",
                                       "atttype_",
                                       "setatttype_",
                                       "inatt_",
                                       "insetatt_"};
  static final String INASYMBOL= "isa_";
  static final String ISASYMBOL = "sub_";
  static final String PARTOFSYMBOL = "partof_";
  static final String METHODARGSYMBOL = "args_";
  static final String METHODNAMESYMBOL= "methodname_";
  static final String OBJECTSYMBOL = "object_";
  static final String PATHSYMBOL = "path_";
  public static final String NIL = "nil_";
  public static final String LIST = "l_";
  static final String DIRECT = "direct_";
  static final String SETDIRECT = "setdirect_";
*/




static FNode merge(FNode fn1, FNode fn2)
{  
 if(fn1!=null)
   if(fn2!=null) return new AND_FNode(fn1,fn2);
   else return fn1;
 else return fn2;

} 
 
FTerm[] mergeTerms(FTerm arg)
{ FTerm [] tt = new FTerm[1];
  tt[0]=arg;
  return tt;
}      


FTerm[] mergeTerms(FTerm arg1,FTerm arg2)
{ FTerm [] tt = new FTerm[2];
  tt[0]=arg1;
  tt[1]=arg2;
  return tt;
}      

FTerm[] mergeTerms(FTerm arg1,FTerm arg2,FTerm arg3)
{ FTerm [] tt = new FTerm[3];
  tt[0]=arg1;
  tt[1]=arg2;
  tt[2]=arg3;
  return tt;
}      

FNode trans(Hashtable h) { return trans(h,true); }
FNode trans(Hashtable h,boolean b) { return null; }



}



//********************************************************

class AND_FLFormula extends FLFormula
{ public FLFormula l;
  public FLFormula r;

 AND_FLFormula(FLFormula l, FLFormula r) { this.l = l; this.r = r;}
 public String toString()
  { return   "(" + l.toString() + " and " + r.toString() + ")"; }


public FNode trans(Hashtable h, boolean head) 
  { return new AND_FNode(l.trans(h,head), r.trans(h,head));}

}
//********************************************************





class OR_FLFormula extends FLFormula 
{ public FLFormula l;
  public FLFormula r;

OR_FLFormula(FLFormula l, FLFormula r) { this.l = l; this.r = r;}
public String toString()
  { return "(" + l.toString() + " or " + r.toString() + ")"; }

public FNode trans(Hashtable h,boolean head) 
  { return new OR_FNode(l.trans(h,head), r.trans(h,head));}


}

//********************************************************



class IMPLIES_FLFormula extends FLFormula
 { public FLFormula l;
   public FLFormula r;
IMPLIES_FLFormula(FLFormula l, FLFormula r) { this.l = l; this.r = r;}
public String toString()
 { return  "(" + l.toString() + " -> " + r.toString() + ")"; }

public FNode trans(Hashtable h,boolean head) 
  { return new IMPLIES_FNode(l.trans(h,head), r.trans(h,head));}

}



//********************************************************


class IMPLIEDBY_FLFormula extends FLFormula
 { public FLFormula l;
   public FLFormula r;
IMPLIEDBY_FLFormula(FLFormula l, FLFormula r) { this.l = l; this.r = r;}
public String toString()
{ return  "(" + l.toString() + " <- " + r.toString() + ")"; }


public FNode trans(Hashtable h,boolean head) 
  { return new IMPLIEDBY_FNode(l.trans(h,head), r.trans(h,head));}

}



//********************************************************



class EQUIV_FLFormula extends FLFormula 
{ public FLFormula l;
  public FLFormula r;

EQUIV_FLFormula(FLFormula l, FLFormula r) { this.l = l; this.r = r;}
public String toString()
{ return  "(" + l.toString() + " <-> " + r.toString() + ")"; }

public FNode trans(Hashtable h,boolean head) 
  { return new EQUIV_FNode(l.trans(h,head), r.trans(h,head));}



}

//********************************************************

 
class FORALL_FLFormula extends FLFormula 
{ 
  public FLFormula l;
  public Vector v;
 
FORALL_FLFormula( Vector v, FLFormula l) { this.l = l;this.v = v;}


public String toString()
{ String result = "FORALL ";  
  for(java.util.Enumeration e=v.elements(); e.hasMoreElements();)
     { result = result + (String) e.nextElement();
       if(e.hasMoreElements()) result = result + ",";
     }
   result = result + "(" + l.toString() + ")";
   return result;
}
public FNode trans(Hashtable h,boolean head) 
  {Hashtable h1 = (Hashtable) h.clone();
   for(java.util.Enumeration e=v.elements(); e.hasMoreElements();)
     { String s = (String) e.nextElement();
       h1.put(s,s);
     }
    return new FORALL_FNode(v,l.trans(h1,head));}



}
//********************************************************

class EXISTS_FLFormula extends FLFormula 
{ 
  public FLFormula l;
  public Vector v;
 
EXISTS_FLFormula( Vector v, FLFormula l) { this.l = l; this.v = v;}


public String toString()
{ String result = "EXISTS ";  
  for(java.util.Enumeration e=v.elements(); e.hasMoreElements();)
     { result = result + (String) e.nextElement();
       if(e.hasMoreElements()) result = result + ",";
     }
   result = result + "(" + l.toString() + ")";
   return result;
}

public FNode trans(Hashtable h,boolean head) 
  { Hashtable h1 = (Hashtable) h.clone();
   for(java.util.Enumeration e=v.elements(); e.hasMoreElements();)
     { String s = (String) e.nextElement();
       h1.put(s,s);
     }
     return new EXISTS_FNode(v,l.trans(h1,head));}


}
//********************************************************

class NOT_FLFormula extends FLFormula
 { public FLFormula l; 


NOT_FLFormula(FLFormula l)   { this.l = l;}

public String toString()
{
 return "not (" + l.toString() + ")";
}

public FNode trans(Hashtable h,boolean head) 
  { return new NOT_FNode(l.trans(h,head));}

}
  
//********************************************************





class Molecule extends FLFormula
{ public String toString() { return "";}
  public FNode trans(Hashtable h, boolean head) 
   { return null;}


 }
 

//********************************************************


class FMolecule extends Molecule
{
  Reference r;
  Specification s;

 FMolecule(Reference r, Specification s)
  { this.r = r ; this.s = s ;}


public String toString()
{
   return r.toString() + s.toString();
}


public FNode trans(Hashtable h,boolean head) 
  {  ObjectWrapper o = new ObjectWrapper();
     return mtrans(h,o,head); 
  }


public FNode mtrans(Hashtable h,ObjectWrapper o, boolean head) 
  {  FNode f1 = r.mtrans(h,o,head);
     FNode f2 = s.mtrans(h,o,head);
     return merge(f1,f2); 
  }

}
//********************************************************

class PMolecule extends Molecule
{ String s;
  Vector v;
  
PMolecule(String s, Vector v)
  { this.s = s ; this.v = v ;}

public String toString()
{ String result = s;  
  if(v!=null && !v.isEmpty()) 
     { result = result + "(";
       for(java.util.Enumeration e=v.elements(); e.hasMoreElements();)
       { result = result + ((Path) e.nextElement()).toString();
        if(e.hasMoreElements()) result = result + ",";
       }
      result = result + ")";
     }
  return result;
}


public FNode trans(Hashtable h,boolean head) 
  { ObjectWrapper o = new ObjectWrapper();
    int k;
    if(v==null) k=0; else k = v.size();
    FTerm[] Fargs = new FTerm[k];
    FNode f1=null; 
    for(int i = 0; i< k ; i++)
       {  f1 = merge(f1,((Terms)v.elementAt(i)).mtrans(h,o,head));
                   Fargs[i] = o.getValue();// Fargs[i] = o.getValue();
       }
    return merge( new FAtom(s, Fargs), f1);   
   }

}
//********************************************************
class Terms extends FLFormula
{ public FNode mtrans(Hashtable h, ObjectWrapper o, boolean head) {return null;}}



class FObject extends Terms
 
{ public FNode mtrans(Hashtable h,ObjectWrapper o, boolean head) 
  {  return null;}
 }
//********************************************************
class FObjectPath extends FObject {
Path p;

FObjectPath(Path p)
{ this.p = p; }

public String toString()
 { return "(" + p.toString() + ")"; }



public FNode mtrans(Hashtable h,ObjectWrapper o, boolean head) 
  {  return p.mtrans(h,o,head);}

}

//********************************************************
class FObjectIDTerm extends FObject{
IDTerm t;
 	
FObjectIDTerm(IDTerm t)
  { this.t = t; }

public String toString()
 { return t.toString(); }

public FNode mtrans(Hashtable h,ObjectWrapper o, boolean head) 
  {  return t.mtrans(h,o,head);}


}

//********************************************************


class Reference extends Terms
{FObject o;
 Vector r;

 Reference(FObject o, Vector r)
 {this.o = o ; this.r = r;}

  public String toString() 
    {String result = o.toString(); 
      for(java.util.Enumeration e=r.elements(); e.hasMoreElements();)
         { Object o = e.nextElement();
           if(o instanceof Integer)
           { int i = ((Integer) o).intValue();
             if(i==0) result = result + "#";
             else result = result + "##";  
           }
         else result = result + o.toString();   
        }  
    return result;
   }

public FNode mtrans(Hashtable h,ObjectWrapper ow, boolean head) 
  { int k=r.size();
    ObjectWrapper ObjectName = new ObjectWrapper(); 
    ObjectWrapper MethodName = new ObjectWrapper();
    FTerm result;
    Object obj;
    FNode f1 = o.mtrans(h,ObjectName, head);
    result = ObjectName.getValue();
    //result = ObjectName.getValue();
    for(java.util.Enumeration  e=r.elements();e.hasMoreElements();)
      {  
        obj = e.nextElement();
        if(obj instanceof Specification)
            { f1=merge(f1, ((Specification) obj).mtrans(h,ObjectName,head)); }
        else if(obj instanceof Integer)
              { int type= ((Integer) obj).intValue();         
              
                MethodApplication m = (MethodApplication)  e.nextElement();
                f1 =  merge(f1,m.mtrans(h,MethodName,head));
                if(head)
                        result = new FTermFunction(Config.PATHSYMBOL,
                              mergeTerms(ObjectName.getValue(),
                                      MethodName.getValue())); 
                else result = new FTermVariable(VariableGenerator.getVariable());
                f1 = merge(f1,new FAtom(Config.METHODSYMBOL[type],
                            mergeTerms( ObjectName.getValue(),MethodName.getValue(),result)));


               if(head)
                 if(type == 0) f1 = merge(f1, new FAtom(Config.DIRECT, 
                                          mergeTerms(ObjectName.getValue(),
                                          MethodName.getValue())));
                 else if(type==1) f1 = merge(f1, new FAtom(Config.SETDIRECT, 
                                          mergeTerms(ObjectName.getValue(),
                                          MethodName.getValue())));

               
                }
        ObjectName.setValue(result);
         }
  ow.setValue(result);
  return f1;      
 }

}
//********************************************************
 class Path extends Terms
{FObject o;
 Vector r;

Path(FObject o, Vector r)
 {this.o = o ; this.r = r;}

  public String toString() 
    {String result = o.toString(); 
     if(r!=null)
      for(java.util.Enumeration e=r.elements(); e.hasMoreElements();)
         { Object o = e.nextElement();
           if(o instanceof Integer)
           { int i = ((Integer) o).intValue();
             if(i==0) result = result + "#";
             else result = result + "##";  
           }
         else result = result + o.toString();   
        }  
    return result;
}


Path(IDTerm t)
  { o = new FObjectIDTerm(t);
    r = null;
  }

public FNode mtrans(Hashtable h,ObjectWrapper ow, boolean head) 
  { 
    ObjectWrapper ObjectName = new ObjectWrapper(); 
    ObjectWrapper MethodName = new ObjectWrapper();
    FTerm result;
    Object obj;
    FNode f1 = o.mtrans(h,ObjectName, head);
    result = ObjectName.getValue();
    //result = ObjectName.getValue();
    if(r!=null)
    for(java.util.Enumeration  e=r.elements();e.hasMoreElements();)
      {  
        obj = e.nextElement();
        if(obj instanceof Specification)
            { f1=merge(f1, ((Specification) obj).mtrans(h,ObjectName,head)); }
        else if(obj instanceof Integer)
              { int type= ((Integer) obj).intValue();         
              
                MethodApplication m = (MethodApplication)  e.nextElement();
                f1 =  merge(f1,m.mtrans(h,MethodName,head));
                if(head)
                        result = new FTermFunction(Config.PATHSYMBOL,
                              mergeTerms(ObjectName.getValue(),
                                      MethodName.getValue())); 
                else result = new FTermVariable(VariableGenerator.getVariable());
                f1 = merge(f1,new FAtom(Config.METHODSYMBOL[type],
                            mergeTerms( ObjectName.getValue(),MethodName.getValue(),result)));


               if(head)
                 if(type == 0) f1 = merge(f1, new FAtom(Config.DIRECT, 
                                          mergeTerms(ObjectName.getValue(),
                                          MethodName.getValue())));
                 else if(type==1) f1 = merge(f1, new FAtom(Config.SETDIRECT, 
                                          mergeTerms(ObjectName.getValue(),
                                          MethodName.getValue())));

               
                }
        ObjectName.setValue(result);
         }
  ow.setValue(result);
  return f1;      
 }







}
 //********************************************************

class MethodApplication extends Terms
{FObject o; Vector a;
MethodApplication(FObject o, Vector a) {this.o = o; this.a=a;}
  
public String toString() 
    { String result = o.toString(); 
      if(a!=null)
      {  result = result + "@(";
         for(java.util.Enumeration e=a.elements(); e.hasMoreElements();)
          result = result + ((String) e.nextElement()).toString();
         result = result + ")";
 
      }
       return result;
   
   }


public FNode mtrans(Hashtable h,ObjectWrapper Method, boolean head) 
  {  int k;
     if(a==null) k=0; else k=a.size();
    ObjectWrapper MethodName = new ObjectWrapper(); 
    ObjectWrapper o2 = new ObjectWrapper();
    FTerm [] newargs = new FTerm[k];
    FNode f1 = o.mtrans(h,MethodName, head); 
   
    for(int i=0; i<k;i++)      
        { 
         f1 =  merge(f1,((Terms) a.elementAt(i)).mtrans(h,o2, head));
         newargs[i] = o2.getValue();
        }
    
   if(k>0)
   Method.setValue(new FTermFunction( 
                           Config.METHODNAMESYMBOL,
                           mergeTerms(MethodName.getValue(),
                                      new FTermFunction(Config.METHODARGSYMBOL,newargs))));
     

   else
   Method.setValue(MethodName.getValue());
   return f1;
 }

}



//********************************************************
 class MethodResult extends Terms
{  
int a; Vector r;
MethodResult(int a, Vector r) {this.a = a; this.r =r;}
  public String toString()
  {
     String result = "";
     int i = r.size();
    switch( a) {
                        case 0 : result = result.concat("->"); break;
                        case 1 : result = result.concat("->>"); break;
                        case 2 : result = result.concat("=>"); break;
                        case 3 : result = result.concat("=>>"); break;
                        case 4 : result = result.concat("*->"); break;
                        case 5 : result = result.concat("*->>"); break;
                                                              }
    switch(i) {
          case 0 : result = result.concat("{}"); break;
          case 1 : result = result.concat(r.elementAt(0).toString());break;
          default: 
            {   result = result.concat("{");
                for(int k=0; k < i; k++) {
                   result = result.concat(r.elementAt(k).toString());
                   if(k < i-1) result = result.concat(",");
                 }
                 result = result.concat("}");
           }
   }

  return result;
}         


public FNode mtrans(Hashtable h,ObjectWrapper ObjectName,ObjectWrapper MethodName, boolean head) 
  { int k=r.size();
    FTerm [] newargs = new FTerm[k];
    FNode f1 =null;
    FNode f2 = null;
    ObjectWrapper o1 = new ObjectWrapper();
    FTerm t;
 
     
     for(int i= 0; i<k; i++)
        { 
          f1=merge(f1, ((Terms) r.elementAt(i)).mtrans(h,o1,head));
          f2=merge(f2, new FAtom(Config.METHODSYMBOL[a],
                             mergeTerms(ObjectName.getValue(),
                             MethodName.getValue(),     
                             o1.getValue())));

       if(head)
         { if(a == 0) f2 = merge(f2, new FAtom(Config.DIRECT, 
                                             mergeTerms(ObjectName.getValue(),
                                              MethodName.getValue())));
          else if(a==1) f2 = merge(f2, new FAtom(Config.SETDIRECT, 
                                              mergeTerms(ObjectName.getValue(),
                                              MethodName.getValue())));
 
         }
// Add DIRECT-Atoms to Head to determine, if inheritance is overwritten


        }
       return merge(f1,f2);
}

}

 //********************************************************
class Method extends Terms
{MethodApplication ma;MethodResult mr;
Method(MethodApplication ma,MethodResult mr)
 { this.ma=ma; this.mr=mr;} 

public String toString()
{
 return ma.toString() + mr.toString();
}


public FNode mtrans(Hashtable h,ObjectWrapper ObjectName, boolean head) 
  { ObjectWrapper MethodName = new ObjectWrapper();
    FNode f1 = ma.mtrans(h,MethodName,head);
    FNode f2 = mr.mtrans(h,ObjectName, MethodName,head);
    return merge(f1,f2);
  }
                                          
 

}
//********************************************************

class Specification extends Terms
{ 
  int s;
  FObject o; 
  Vector m;
  Specification(  int s, FObject o, Vector m)
  {this.s =s; this.o =o; this.m=m;}

public String toString()
{
    String result = "";
    int i;
    if(m==null) i=0; else i=m.size();
    switch( s) {
         case 0 : break;
         case 1 :
           result = result.concat(":").concat(o.toString()); break;
         case 2 : result = result.concat("::").concat(o.toString()); break;
         case 3 : result = result.concat("<:").concat(o.toString()); break;
                }
    if(i>0 || (i==0 && s==0)) { result = result.concat("[");
      for(int k=0; k < i; k++) {
           result = result.concat(m.elementAt(k).toString());
           if(k < i-1) result = result.concat(",");
      }
           result = result.concat("]");
    }   
  
      return result;
}


public FNode mtrans(Hashtable h,ObjectWrapper ObjectName, boolean head) 
  { int k;
    if(m==null) k=0; else  k = m.size();
    String sy=""; 
    FNode f1 = null;
    FNode f2 = null;
    ObjectWrapper o1 = new ObjectWrapper();
    if(s!=0)
       {
         switch(s) {
           case 1:  sy = Config.INASYMBOL;break;
           case 2:  sy = Config.ISASYMBOL;break;
           case 3:  sy = Config.PARTOFSYMBOL;break;
          }

          f1 = o.mtrans(h,o1,head);
          f2 = new FAtom(sy, mergeTerms(ObjectName.getValue(),o1.getValue()));
          f1 =merge(f1,f2);
       }
 
    for(int i=0; i< k; i++)
        { f2 = ((Terms) m.elementAt(i)).mtrans(h,ObjectName,head);
          f1 = merge(f1,f2); 
        }
    if(k==0 && s ==0)    
/* object_ -facts are no only generated, if type = 0 (and no methods, that means
   only something like o[] is given .

*/
         {
        f1 = merge(f1, new FAtom(Config.OBJECTSYMBOL,mergeTerms(ObjectName.getValue())));
             }

    return f1;
          
   }
         
}

//********************************************************
class IDTerm extends Terms
{  public FNode mtrans(Hashtable h,ObjectWrapper O, boolean head) { return null;}
}

class IDTermString extends IDTerm
{
String s;

IDTermString(String s)
  { 
    this.s = s; }

public String toString()
   { return "\""+s+"\"";              
      }


public FNode mtrans(Hashtable h,ObjectWrapper O, boolean head) 
{ 

  O.setValue(new FTermString(s));
  return null;}





}


//********************************************************
class IDTermInteger extends IDTerm
{

Integer i;
IDTermInteger(Integer i)
  { 
    this.i= i; }

public String toString()
   { return i.toString();              
      }

public FNode mtrans(Hashtable h,ObjectWrapper O, boolean head) 
{ 

  O.setValue(new FTermInteger(i));
  return null;}




}

//********************************************************
class IDTermFloat extends IDTerm
{
 Double d;
IDTermFloat(Double d)
  { 
    this.d = d; }
public String toString()
   { return d.toString();              
      }

public FNode mtrans(Hashtable h,ObjectWrapper O, boolean head) 
{ 

  O.setValue(new FTermFloat(d));
  return null;}



}

//********************************************************


class IDTermVariableorConstant extends IDTerm
{
 String v;

IDTermVariableorConstant(String v)
  { this.v=v; }


public String toString()
   { return v;              
      }

public FNode mtrans(Hashtable h,ObjectWrapper O, boolean head) 
{ 
  Object hh = h.get(v);
  if(hh==null) O.setValue(new FTermConstant(v));
  else O.setValue(new FTermVariable(v));
  return null;}
}


class IDTermVariable extends IDTerm
{
 String v;

IDTermVariable(String v)
  { this.v=v; }


public String toString()
   { return v;              
      }

public FNode mtrans(Hashtable h,ObjectWrapper O, boolean head) 
{ 
  O.setValue(new FTermVariable(v));
  return null;}
}

class IDTermConstant extends IDTerm
{
 String v;

IDTermConstant(String v)
  { this.v=v; }


public String toString()
   { return v;              
      }

public FNode mtrans(Hashtable h,ObjectWrapper O, boolean head) 
{ 
  
  O.setValue(new FTermConstant(v));
  return null;}
}



//********************************************************
class IDTermFunction extends IDTerm
{
String s;
Vector a;


IDTermFunction(String s, Vector a) 
  { 
    this.s = s;
    this.a = a;
}


IDTermFunction(String s, Path p)
  { this.s = s;
    this.a = new Vector(1);
    this.a.addElement(p);
  }


IDTermFunction(String s, Path p1, Path p2)
   { this.s = s;
    this.a = new Vector(2);
    this.a.addElement(p1);
    this.a.addElement(p2);
  }


IDTermFunction(String s)
  { this.s = s;
    this.a = null;
  }

public String toString(){ 
	String result = s;
        if(a!=null && !a.isEmpty())
         { result = result + "(";
           for(java.util.Enumeration e=a.elements(); e.hasMoreElements();)
            {result = result + e.nextElement().toString();
             if(e.hasMoreElements()) result = result+",";
            }
            result=result + ")";
         }
     return result;
}

public FNode mtrans(Hashtable h,ObjectWrapper O, boolean head) 
{ int k;
  if(a==null) k=0; else k = a.size();
  ObjectWrapper o1 = new ObjectWrapper();
  FTerm[] args = new FTerm[k];
  FNode f1 = null;
  FNode f2 = null;
    for(int i=0; i< k; i++) 
       { f2 = ((Terms) a.elementAt(i)).mtrans(h,o1,head);
         args[i] = o1.getValue();
         f1 = merge(f1,f2);
         }
  O.setValue(new FTermFunction(s, args));
  return f1;}

}

//********************************************************
class IDTermList extends IDTerm
{

Vector l;
Path r;

IDTermList(Vector l, Path r) 
  { 
    this.l = l;
    this.r = r;
}

public String toString()
   { String result = "" ;
       if(l==null || l.isEmpty()) result = "[]";
       else
        {  result = "[";
           for(java.util.Enumeration e=l.elements(); e.hasMoreElements();)
            {result = result +  e.nextElement().toString();
             if(e.hasMoreElements()) result = result+",";
            }
       if(r!=null)
         result = result + "|" + r.toString();
       
       result = result + "]";
      }   

     return result;
}


public FNode mtrans(Hashtable h,ObjectWrapper O, boolean head) 
{ FTermConstant nil = new FTermConstant(Config.NIL);
  int k;
  if(l==null) k=0; else k = l.size(); 
  ObjectWrapper o1 = new ObjectWrapper();
  FTerm start;
  FNode f1 = null;
  if(r == null) start = nil;
  else { f1 = r.mtrans(h,o1,head);
         start = o1.getValue();}
  for(int i = k-1; i>=0; i--)
     {  f1 = merge( ((Terms)l.elementAt(i)).mtrans(h,o1,head),f1);
        start = new FTermFunction(Config.LIST,mergeTerms(o1.getValue(),start));
     }
   O.setValue(start);
   return f1;
}
 

}

//********************************************************

class FLObject extends Object
{
  public Vector trans() {  return null;}
}



class FLRule extends FLObject 
{ Vector v;
  FLFormula h;
  FLFormula b;  


 FLRule(Vector v, FLFormula h, FLFormula b)
 {this.v = v; this.h = h; this.b = b;}

 
 public String  toString()
{
String result = "";
  if(v!=null && !v.isEmpty())
   { result= result + "FORALL ";
     for(java.util.Enumeration e=v.elements(); e.hasMoreElements();)
     { result = result + (String) e.nextElement();
       if(e.hasMoreElements()) result = result + ",";
     }
   }
if(b!=null) result = result + " ( " + h.toString() + " )" + " <- " + "( " + b.toString() + " )";
else result =  result +  h.toString() + ".";
return result;
}

public Vector trans()
{  Hashtable tab = new Hashtable(6);
   Vector vec=new Vector(1);
   FNode f1,f2;
   if(v!=null && !v.isEmpty())
   { for(java.util.Enumeration e=v.elements(); e.hasMoreElements();) 
     { String obj = (String) e.nextElement();
      tab.put(obj,obj);
     }
   }
   f1 = h.trans(tab);
   if(b!=null) f2=b.trans(tab,false); 
   else f2 = null;
   vec.addElement(new FRule(v,f1,f2));
   return vec;  
}


}

//*****************************************************************


class FLDoubleRule extends FLObject 
{ Vector v;
  FLFormula h;
  FLFormula b;  


 FLDoubleRule(Vector v, FLFormula h, FLFormula b)
 {this.v = v; this.h = h; this.b = b;}

 
 public String  toString()
{
String result = "";
  if(v!=null && !v.isEmpty())
   { result= result + "FORALL ";
     for(java.util.Enumeration e=v.elements(); e.hasMoreElements();)
     { result = result + (String) e.nextElement();
       if(e.hasMoreElements()) result = result + ",";
     }
   }
  return result + " ( " + h.toString() + " )" + " <-> " + "( " + b.toString() + " )";
}
public Vector trans()
{  Hashtable tab = new Hashtable(6);
   Vector vec=new Vector(2);
   FNode f1,f2;
   if(v!=null && !v.isEmpty())
   { for(java.util.Enumeration e=v.elements(); e.hasMoreElements();) 
       { String obj = (String) e.nextElement();
         tab.put(obj,obj);
       }
   }
   f1 = h.trans(tab,true);
   f2 = b.trans(tab,false); 
   vec.addElement(new FRule(v,f1,f2));
   f1 = b.trans(tab);
   f2=h.trans(tab,false); 
   vec.addElement(new FRule(v,f1,f2));
   return vec;  
}
}






//********************************************************************




class FLQuery extends FLObject
{  Vector v;
   FLFormula b;
    


FLQuery(Vector v, FLFormula b)
 { this.v=v; this.b=b; }

  
public String  toString()
{
String result = "";
  if(v!=null && !v.isEmpty())
   { result= result + "FORALL ";
     for(java.util.Enumeration e=v.elements(); e.hasMoreElements();)
     { result = result + (String) e.nextElement();
       if(e.hasMoreElements()) result = result + ",";
     }
   }
  return result + " <- " + b.toString();
}

public Vector trans()
{Vector vec = new Vector(1);
 Hashtable tab = new Hashtable(6);
 if(v!=null && !v.isEmpty())
    for(java.util.Enumeration e=v.elements(); e.hasMoreElements();) 
     { Object o = e.nextElement();
       tab.put(o,o);
     }
 FNode f=b.trans(tab,false);
 vec.addElement(new FQuery(v,f));
 return vec;   
}



}  

 class VariableGenerator
{ static int num = -1 ;
 static String getVariable() { num++; return "_X"+ new Integer(num).toString();}
 static void reset() { num = -1; }
}

 

class ObjectWrapper extends Object
{
public FTerm value;

public FTerm getValue() { return value;}
public void setValue(FTerm t) { value = t;}
}
