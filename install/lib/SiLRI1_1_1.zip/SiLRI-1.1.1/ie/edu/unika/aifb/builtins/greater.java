/*

Name: greater.java

Version: 1.0

Purpose:

History:

*/

package edu.unika.aifb.builtins;

import edu.unika.aifb.inference.BuiltinFunc;
import edu.unika.aifb.inference.Variable;
import edu.unika.aifb.inference.Atom;
import edu.unika.aifb.inference.NumTerm;
import java.lang.Math;

public class greater  extends BuiltinFunc {

	public boolean evaluable(Atom t) {
  return (t.terms[0]  instanceof NumTerm) && (t.terms[1] instanceof NumTerm);
 }

	public  void eval(Atom t) {
  boolean ok = false; 
    if ((t.terms[0]  instanceof NumTerm) && (t.terms[1] instanceof NumTerm))
      if( ((NumTerm)t.terms[0]).zahl >  ((NumTerm)t.terms[1]).zahl) ok = true; 
  if (ok) {insert(t);}
  }
}
 
       
  
