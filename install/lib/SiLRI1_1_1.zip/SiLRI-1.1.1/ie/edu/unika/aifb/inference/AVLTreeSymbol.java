/*

Name: AVLTreeSymbol.java

Version: 1.0

Purpose:

History:

*/

package edu.unika.aifb.inference;

import java.io.*;

class AVLNodeSymbol extends AVLNode {
	public String s;
	public int a;
        public int i;
	public AVLNodeSymbol(String s, int a) {super(); this.s = s; this.a=a;i=-1;}
	public void print() {		
		System.out.print(i); System.out.print(" "); System.out.print(s); 
	}
	public void write(RandomAccessFile f) throws IOException {		
		f.writeBytes(String.valueOf(i)); f.writeBytes(" "); f.writeBytes(String.valueOf(a)); f.writeBytes(" "); f.writeBytes(s); 
	}
}


public class AVLTreeSymbol extends AVLTree {
		private DynamicVector nodes;
                private AVLNodeSymbol pre;
		
		public AVLTreeSymbol() {
			super(false); // no duplicates
			nodes = new DynamicVector();
                        pre = new AVLNodeSymbol("",0);
		}

		public void write(RandomAccessFile f) throws IOException {
			int i;
			AVLNodeSymbol a;
			for (i = 0; i < nodes.size(); i++) {
				a = (AVLNodeSymbol)nodes.elementAt(i);
				a.write(f); f.writeBytes("\n");
			}
		}

		protected int praed(AVLNode t1, AVLNode t2) {
			int i = ((AVLNodeSymbol)t1).s.compareTo(((AVLNodeSymbol)t2).s);
			if(i>0) return 1;
                        else if(i<0) return -1;
			else if(((AVLNodeSymbol)t1).a > ((AVLNodeSymbol)t2).a) return 1;
                        else if(((AVLNodeSymbol)t1).a < ((AVLNodeSymbol)t2).a) return -1;
                        return 0;			
		}
		protected boolean equal(AVLNode t1, AVLNode t2) {
	        	 return (((AVLNodeSymbol)t1).s.equals(((AVLNodeSymbol)t2).s) &&
                                     ((AVLNodeSymbol)t1).a == ((AVLNodeSymbol)t2).a);
		}

                public int search(String s,int a){
		  pre.s=s;
                  pre.a=a;
		  AVLNodeSymbol r= (AVLNodeSymbol) Search(pre);
                  if(r==null) return -1; else return r.i;     
                }


                public int searchAndInsert(String s, int a){
			  AVLNodeSymbol n= new AVLNodeSymbol(s,a);
			  n= (AVLNodeSymbol) Insert(n);
                          if(n.i==-1) {n.i=nodes.size(); nodes.addElement(n);}
                          return n.i;
	                }
                public String getContent(int i)
                { return ((AVLNodeSymbol) nodes.elementAt(i)).s;}


public static void main(String  argv[])
{
 AVLTreeString t= new AVLTreeString();
 System.out.println(t.searchAndInsert("a"));
 System.out.println(t.searchAndInsert("b"));
 System.out.println(t.searchAndInsert("c"));
 System.out.println(t.searchAndInsert("d"));
 System.out.println(t.searchAndInsert("e"));
 System.out.println(t.searchAndInsert("a"));
 System.out.println(t.searchAndInsert("c"));
 System.out.println(t.searchAndInsert("e"));
 System.out.println(t.getContent(1));
System.out.println(t.getContent(2));
System.out.println(t.getContent(3));
System.out.println(t.getContent(4));
}
				
}
