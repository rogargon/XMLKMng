/*

Name: Axioms.java

Version: 1.0

Purpose:
Container for Builtin Axioms of Frame-Logic

History:

*/

package edu.unika.aifb.inference;

public class Axioms {

static final String FLOGICAXIOMS = 

// static final String test =

// closure rules for X :: Y
//"FORALL X  sub_(X,X)." +
"FORALL X,Y,Z sub_(X,Z) <- sub_(X,Y) and sub_(Y,Z)." +
// Attributes are inherited
"FORALL C1,C2,A,T C1[A=>>T] <- C1 :: C2 and C2[A=>>T]." +  
// closure rules for X : C 
"FORALL O,C,C1 isa_(O,C) <-  sub_(C1,C) and isa_(O,C1)." +
// monotone inheritance
// direct_ denotes, that a value for the method is derived directly, i.e.
// without inheritance.

//"FORALL O,M,V,C  att_(O,M,V) <- inatt_(C,M,C) and isa_(O,C) and not direct(O,M)." + 
//"FORALL O,M,V,C  setatt_(O,M,V) <- insetatt_(C,M,C) and isa_(O,C) and not setdirect_(O,M)." +
// definition of object
//"FORALL O  object_(O) <- EXISTS X sub_(O,Y) or sub_(Y,O) or isa_(O,Y) or isa_(Y,O) or partof(O,Y) or partof(Y,O)." +
//"FORALL O object_(O) <- EXISTS M,V ( att_(O,M,V) or setatt_(O,M,V))." +
// Methods and attributes are up to now NO objects. Maybe we should
// change this 
// Equality Rules
// Acyclicity of SUB_
//"FORALL C1,C2 equality_(C1,C2) <- sub_(C1,C2) and sub_(C2,C1)." +
// Scalarity
//"FORALL O,M,V1,V2 equality_(V1,V2) <- att_(O,M,V1) and att_(O,M,V2)." +
//"FORALL O,M,V1,V2 equality_(V1,V2) <- inatt_(O,M,V1) and inatt_(O,M,V2)." +

// Part-Of-Relation
"FORALL O1,O2 partof_(O1,O2) <- setatt_(O2,methodname_(hasParts,args_),O1)." +
"FORALL O1,O2 setatt_(O1,methodname_(hasParts,args_),O2) <- partof_(O2,O1)."

;
// To Do: Object Rules



}
