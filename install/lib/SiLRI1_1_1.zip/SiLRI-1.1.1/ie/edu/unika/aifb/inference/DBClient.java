/*

Name: DBClient.java

Version: 1.0

Purpose:

History:

*/


package edu.unika.aifb.inference;

import java.util.Date;
import java.util.Random;
import java.lang.Long;
import java.io.*;
import java.util.*;
import java.net.*;

public class DBClient extends Thread {
	static int no = 0;
        Socket socket = null;
        DataInputStream is = null;
        PrintStream os = null;
   	private static final int PORTNUM1 = 1236;
	Rule rule;
	SParser spars;
	Atoms filter;

	public DBClient(Rule r) {
		rule = r;
		rule.evaluating = true;
		spars = new SParser();
		filter = new Atoms(rule.heads[0].adddown.stellen);
		filter.Union(rule.heads[0].adddown);
		rule.heads[0].adddown.Clear();
    		this.setPriority( Thread.NORM_PRIORITY );
		System.out.println("DBAccess");
		this.start();
	}


	public void run() {
		System.out.print("running DBClient no ");
		System.out.println(no++);

		// Initialize the sockets and streams
		while (true) {
		        try {
			    InetAddress ina = InetAddress.getByName("");
		            socket = new Socket(ina, PORTNUM1);
		            is = new DataInputStream(socket.getInputStream());
		            os = new PrintStream(socket.getOutputStream(),true);
			    break;

		        }
		        catch (IOException e) {
		            System.err.println("Exception: couldn't create stream socket to database"
		                + e.getMessage());
		        }
		}

		// Process user input and server responses
	        try {
	            	String inLine;
		    	Fact f;
			GroundAtom a,b;

			filter.internalize(os,rule.heads[0].symbol);
		     	os.println("stop");
	             	os.flush();
			System.out.println("Ergebnisse: ");
	             	while ((inLine = is.readLine()) != null) {
	                   if (inLine.length() > 0) {
		        	if (inLine.equals("stop"))
	                            break;
				spars.ParseString(inLine);
				try {
					f = spars.fact();
					b = new Atom(f.terms);
					a = rule.heads[0].up.Insert(b);
					if (a == b)
						a = rule.heads[0].addup.Insert(b);
					f.print(System.out); System.out.println();
					//System.out.println(r.hrelation.stellen);
				}
				catch (JanParseError1 e){
					f = null;
				}
	                    }
	        	}
	   		// Cleanup
	    		os.close();
	    		is.close();
	    		socket.close();

	        }
	        catch (IOException e) {
	            System.err.println("I/O error: "+ e.toString());
	        }
		rule.heads[0].adddown.Clear();	
		rule.stoppedevaluating = true;
		rule.evaluating = false;
	}
}

