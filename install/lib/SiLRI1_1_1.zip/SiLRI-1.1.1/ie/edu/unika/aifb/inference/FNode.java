/*

Name: FNode.java

Version: 1.01

Purpose: 
Translation between general logic programs and normal logic programs
Adds clauses to RuleSet

History:
2.5.99 Added support for new builtin mechanism. SDe
*/




package edu.unika.aifb.inference;

import java.util.Vector;
import java.util.Hashtable;
import edu.unika.aifb.builtins.BuiltinConfig;
  


class FNode extends Object{

public final String toString(FNode left, String Op, FNode right){ 
	return "(".concat(left.toString()).concat(Op).concat(right.toString()).concat(")");
}

public final String toString(String Quantor, Vector Vars, FNode Formula){ 
	String result = Quantor;  
	int k = Vars.size();
	for(int i=0;i < k;i++){
		result = result + Vars.elementAt(i);
		if(i< (k - 1))
			result = result.concat(",");
		else result = result.concat(" ");
	}
	result = result.concat("(").concat(Formula.toString()).concat(")");
	return result; 
}

FNode copyFormula(Hashtable h){
	return null;
}

void FreeBoundVariables(Vector f, Vector b){
	return;
}

 
public boolean isQuantor()  { return false; }
public boolean isExists() { return false; }
public boolean isForall() { return false; }
public boolean isNot() { return false; }
public boolean isAnd() { return false; }
public boolean isOr() { return false; }
public boolean isImplies() { return false; }
public boolean isImpliedBy() { return false; }
public boolean isQuery() { return false; }
public boolean isEquiv() { return false; }
public boolean isAtom() { return false; }
public boolean isNegAtom() { return false; }
public boolean isLiteral() { return false; }
public FNode getLeft() { return null;}
public FNode getRight() { return null;}
public Vector getVariables() { return null;}
public Literal toLiteral() { return null;}
}


 
class AND_FNode extends FNode{
FNode left, right;


AND_FNode(FNode l, FNode r){
	left = l; right = r;
}

public boolean isAnd(){
	return true;
}

public FNode getLeft(){
	return left;
}
public FNode getRight(){
	return right;
}


final FNode copyFormula(Hashtable h){
	return new AND_FNode(left.copyFormula(h), right.copyFormula(h));
}

final public void FreeBoundVariables(Vector Free, Vector Bound){
	left.FreeBoundVariables(Free,Bound); 
	right.FreeBoundVariables(Free,Bound);
}  


final public String toString(){
	return toString(left," and ", right);
}
}

//******************************************************************

class OR_FNode extends FNode{
FNode left, right;

OR_FNode(FNode l, FNode r){
	left = l; right = r;
}

final public boolean isOr(){
	return true;
}

final public FNode getLeft(){
	return left;
}

final public FNode getRight(){
	return right;
}

final FNode copyFormula(Hashtable h){
	return new OR_FNode(left.copyFormula(h), right.copyFormula(h));
}


final public void FreeBoundVariables(Vector Free, Vector Bound){
	left.FreeBoundVariables(Free,Bound); 
	right.FreeBoundVariables(Free,Bound);
}  




final public String toString(){
	return toString(left," or ", right);
}

}
//******************************************************************

class IMPLIES_FNode extends FNode{
FNode left, right;

IMPLIES_FNode(FNode l, FNode r)
{ left = l; right = r; }


final public boolean isImplies() { return true;}
final public FNode getLeft() { return left;}
final public FNode getRight() { return right;}

 
final FNode copyFormula(Hashtable h)
{ return new IMPLIES_FNode(left.copyFormula(h), right.copyFormula(h));}


final public void FreeBoundVariables(Vector Free, Vector Bound){
	left.FreeBoundVariables(Free,Bound); 
	right.FreeBoundVariables(Free,Bound);
}  


final  public String toString(){
	return toString(left," -> ", right); 
}

}
//******************************************************************
class IMPLIEDBY_FNode extends FNode{
  FNode left, right;



IMPLIEDBY_FNode(FNode l, FNode r)
{ left = l; right = r; }
final public boolean isImpliedBy() { return true;}


final public FNode getLeft() { return left;}
final public FNode getRight() { return right;}


final FNode copyFormula(Hashtable h)
{ return new IMPLIEDBY_FNode(left.copyFormula(h), right.copyFormula(h));}


final public void FreeBoundVariables(Vector Free, Vector Bound)
{ left.FreeBoundVariables(Free,Bound); 
  right.FreeBoundVariables(Free,Bound);}  



final  public String toString()
{ return toString(left," <- ", right); }

}
//******************************************************************
class EQUIV_FNode extends FNode{
  FNode left, right;

EQUIV_FNode(FNode l, FNode r)
{ left = l; right = r; }

final public boolean isEquiv() { return true; }

final public FNode getLeft() { return left;}
final public FNode getRight() { return right;}

final FNode copyFormula(Hashtable h)
{ return new EQUIV_FNode(left.copyFormula(h), right.copyFormula(h));}

final public void FreeBoundVariables(Vector Free, Vector Bound)
{ left.FreeBoundVariables(Free,Bound); 
  right.FreeBoundVariables(Free,Bound);}  




final  public String toString()
{ return toString(left," <-> ", right); }



}
//******************************************************************

class FORALL_FNode extends FNode{
  Vector VarList;
  FNode left;

FORALL_FNode(Vector v, FNode l)
{ VarList =v; left = l;}

final public boolean isForall() { return true; }
final public boolean isQuantor()  { return true; }
final public FNode getLeft() { return left;}


final FNode copyFormula(Hashtable h)
{  

   Hashtable h1 = (Hashtable) h.clone();
   Vector NewVarList = new Vector(6);  
           for(int i=0;i < VarList.size();i++)
             { NewVarList.addElement(VariableGenerator.getVariable());
               h1.put(VarList.elementAt(i),NewVarList.elementAt(i));
             }
           
return new FORALL_FNode(NewVarList,left.copyFormula(h1));
}

final public void FreeBoundVariables(Vector Free, Vector Bound)
{    
   for(int i=0;i < VarList.size();i++)
               Bound.addElement(VarList.elementAt(i));
   left.FreeBoundVariables(Free,Bound);
}

final public Vector getVariables() { return VarList;}


final public String toString()
{ return toString("FORALL ",VarList,left); }


}
//******************************************************************

class EXISTS_FNode extends FNode{
  Vector VarList;
  FNode left;
EXISTS_FNode(Vector v, FNode l)
{ VarList =v; left = l;}



final public boolean isExists() { return true; }
final public boolean isQuantor()  { return true; }

final public FNode getLeft() { return left;}
 

final FNode copyFormula(Hashtable h)
{  Hashtable h1 = (Hashtable) h.clone();
   Vector NewVarList = new Vector(6); 
           for(int i=0;i < VarList.size();i++)
             { NewVarList.addElement(VariableGenerator.getVariable());
               h1.put(VarList.elementAt(i),NewVarList.elementAt(i));
             }
           
return new EXISTS_FNode(NewVarList,left.copyFormula(h1));
}

final public Vector getVariables() { return VarList;}



final public void FreeBoundVariables(Vector Free, Vector Bound)
{    
   for(int i=0;i < VarList.size();i++)
               Bound.addElement(VarList.elementAt(i));
   left.FreeBoundVariables(Free,Bound);
}




final public String toString()
{ return toString("EXISTS ",VarList,left); }


}
//******************************************************************

class NOT_FNode extends FNode{
  FNode left;


NOT_FNode(FNode l)
{ left = l;}

final public boolean isNegAtom() { return left.isAtom(); }
final public boolean isLiteral() { return left.isAtom(); }
final public boolean isNot() { return true; }

final public FNode getLeft() { return left;}

final public Literal toLiteral()
{  if(isNegAtom()) return new Literal(true,((FAtom) left).Name,((FAtom)left).Arguments);
  return null;
}

final FNode copyFormula(Hashtable h)
 { return new NOT_FNode(left.copyFormula(h));}

final public void FreeBoundVariables(Vector Free, Vector Bound)
  { left.FreeBoundVariables(Free,Bound);}


final public String toString()
{  return "not (".concat(left.toString()).concat(")");}



}
//******************************************************************

class FAtom extends FNode{
String Name;
FTerm[] Arguments;

FAtom(String s, FTerm[] a)
{ Name = s; Arguments = a;}

final public boolean isAtom() { return true; }
final public boolean isLiteral() { return true; }


final public Literal toLiteral()
{  return new Literal(Name,Arguments);
}


final public String toString()
{ String result = Name;
  int k = Arguments.length;
  if(k > 0) {
             result = result.concat("(");
                 for(int i=0; i< k; i++) {
                     result=result.concat(Arguments[i].toString());
                     if(i< k-1) result = result.concat(",");
                                         }
              result = result.concat(")"); 
             } 
  return result;
              
}

final FNode copyFormula(Hashtable h) 
  { int k = Arguments.length;
    FTerm[] NewArguments = new FTerm[k]; 
    for(int i=0; i< k; i++)
         NewArguments[i] = Arguments[i].copyTerm(h);
    return new FAtom(Name, NewArguments);                              
                         
}

final FNode copyFormula() 
  { int k = Arguments.length;
    FTerm[] NewArguments = new FTerm[k]; 
    for(int i=0; i< k; i++)
         NewArguments[i] = Arguments[i].copyTerm();
    return new FAtom(Name, NewArguments);                              
                         
}


final public void FreeBoundVariables(Vector Free, Vector Bound)
 {  int k = Arguments.length;
        for(int i=0; i< k; i++)
              Arguments[i].FreeBoundVariables(Free,Bound);
 }
        
}
//******************************************************************




class GeneralClause
{ public Vector translate() { return null;}
}




class FRule extends GeneralClause
{
  Vector Vars;
  FNode Head;
  FNode Body;

FRule(Vector v, FNode h, FNode b)
{ Vars = v; Head = h; Body=b;}


FRule(FNode h, FNode b)
{ Vars = null; Head = h; Body = b; } 



final public FNode getHead()
{ return Head; }

final public FNode getBody()
{ return Body; }

final public boolean isFact() { return (Body == null);  }

final public String toString()
{ String result = "";
  int k;
  if(Vars==null) k=0; else k = Vars.size();
  if(k>0) 
     { result = "FORALL ";
      for(int i=0;i < k;i++)
       { result = result + Vars.elementAt(i);
         if(i< (k - 1)) result = result.concat(",");
         else result = result.concat(" ");
       }
      }
   result = result.concat(Head.toString());
   if(Body!=null) result = result.concat(" <- ").concat(Body.toString());
   result = result.concat(".");
return result;
}
         
final static void FNodetoVector(FNode f, Vector v)
{
  if(f==null || !(f.isAtom() || f.isAnd())) return; 
  //   System.out.println("Error in toVector! not Conjunction!");
  if(f.isAtom()) v.addElement(f.toLiteral());
  else { FNodetoVector(f.getLeft(),v);
         FNodetoVector(f.getRight(),v);
       }
  }

final static public Vector toVector(FNode f)
 { Vector v = new Vector(5,2);
   FNodetoVector(f,v);
   return v;
 }

final public Vector getVectorHead()
 { return toVector(Head); }

final public Vector translate()
{  Vector PRule = new Vector(1,5);
   if(isFact())
       PRule.addElement(new ProgRule(toVector(Head)));
   else FOLTransformer.transf(getHead(),getBody(),PRule);
   return PRule;
}       

}


class FQuery extends GeneralClause
{ Vector Vars;
  FNode Body;

FQuery(Vector v, FNode b)
{ Vars = v; Body =b;}

 

 
final public FNode getBody()
{ return Body; }
 
final public Vector getVars()
{ return Vars;  }

final public Vector getVarNames()
{ return Vars;  }


final public String toString()
{ String result = "";
  int k;
  if(Vars==null) k=0; else k = Vars.size();
  if(k>0) 
     { result = "FORALL ";
      for(int i=0;i < k;i++)
       { result = result + Vars.elementAt(i);
         if(i< (k - 1)) result = result.concat(",");
       }
      }
   result = result.concat(" <- ").concat(Body.toString());
    result = result.concat(".");

return result;
}
        

final public Vector translate()
{  Vector result = new Vector(5);
   int qarity;
   if(Vars==null) qarity=0; else qarity = Vars.size();
   FTerm[] qargs = new FTerm[qarity];
   FNode QueryHead; 
   String querysymbol;
   
   FRule r;
   FQuery q;
   int counter = 0;
   int l,m;
   Vector qr = new Vector(5,5);
   querysymbol = PredicateGenerator.getNewPredicate();
   for(int c=0;c < qarity ; c++)
        qargs[c]= new FTermVariable((String) Vars.elementAt(c));
   QueryHead = new FAtom(querysymbol,qargs);
   FOLTransformer.transf(QueryHead,Body,qr);
   Vector Head;
      
   l = qr.size();
   /*System.out.println("Direct");
   for(m = 0; m<l; m++) System.out.println(qr.elementAt(m).toString());
   System.out.println("End Direct");*/
   for(m = 0; m<l; m++)
      {Head = ((ProgRule) (qr.elementAt(m))).getHead();
              if((Head.size() == 1) && ((Literal) Head.elementAt(0)).getSymbol().equals(querysymbol)) 
                { counter = counter + 1; }
      }
   if(counter>1) 
      {
        Vector bod = new Vector(5,5);
        bod.addElement(QueryHead.toLiteral());
        qr.addElement(new ProgQuery(bod, Vars));
        return qr;
      } 

   else
   {
   Vector qr2= new Vector(5,5);    
   for(m = 0; m<l; m++)
            { ProgRule rule = (ProgRule) qr.elementAt(m);
              /*System.out.println("s:");
              System.out.println(rule); */
              Head =  rule.getHead();
              if((Head.size() == 1) && 
                ((Literal) Head.elementAt(0)).getSymbol().equals(querysymbol)&& counter==1)
                       qr2.addElement(new ProgQuery(rule.getBody(),Vars));
	      else qr2.addElement(qr.elementAt(m)); 
             
    	    } 
    return qr2;
    }

}              

}


class Literal extends Object {
  public String Atom;
  public FTerm[] Arguments;
  public boolean isNegated;
Literal(String Symbol, FTerm[] args)
{ Atom = Symbol;
  Arguments = args;
  isNegated = false;
}






Literal( boolean isNeg, String Symbol, FTerm[] args)
{ Atom = Symbol;
  Arguments = args;
  isNegated = isNeg;
}



final public boolean isAtom()
{ return !isNegated;}


final public boolean isNegAtom()
{ return isNegated;}

final public String getSymbol() { return Atom;}
final public FTerm[] getArguments() { return Arguments; }





final Head toHead(Hashtable mapping,IntWrapper varcount,AVLTreeSymbol PredSym,  
            AVLTreeSymbol FuncSym, 
            AVLTreeString Strings)
{
  int i;
  int arity = Arguments.length;
  int k=PredSym.searchAndInsert(Atom,arity);
   Term[] t = new Term[arity];
  for( i = 0; i<arity; i++)
    { t[i] = Arguments[i].toTerm(mapping,varcount,FuncSym, Strings); }
  return new Head(k,t);
}


final void addFact(RuleSet RS,AVLTreeSymbol PredSym,  
            AVLTreeSymbol FuncSym,
            AVLTreeString Strings)
{
  int i;
  Hashtable mapping = new Hashtable(7);
  IntWrapper varcount = new IntWrapper(0);
  int arity = Arguments.length;
  int k=PredSym.searchAndInsert(Atom,arity);
   Term[] t = new Term[arity];
  for( i = 0; i<arity; i++)
    { t[i] = Arguments[i].toTerm(mapping,varcount,FuncSym, Strings); }
  if(varcount.i==0)  RS.AddFact(k, new Atom(t));
  else {   
        Head[] he = new Head[1]; 
        he[0] = new Head(k,t); 
        RS.AddRule(new Rule(he,null)); 
  }
}


final Body toBody(Hashtable mapping,IntWrapper varcount,AVLTreeSymbol PredSym,AVLTreeSymbol FuncSym, 
             AVLTreeString Strings){
	int i;
	int arity = Arguments.length;
	int k=PredSym.searchAndInsert(Atom,arity);
	Term[] t = new Term[arity];
	for( i = 0; i<arity; i++){
		t[i] = Arguments[i].toTerm(mapping,varcount,FuncSym, Strings);
	}
	if(k < BuiltinConfig.getBuiltinNumber()){
		return new BuiltinBody(k,isNegated,t, BuiltinConfig.newInstance(k));
	}
	return new Body(k,isNegated,t);
}

final public String toString()
{ String result = ""; 
  if(isNegated) result=result.concat("-");    
  result = result.concat(Atom);
   result = result.concat("(");
  if((Arguments!=null) && (Arguments.length>0)) 
      {
        int k = Arguments.length;
             for(int i=0; i< k; i++) {
           result=result.concat(Arguments[i].toString());
           if(i< k-1) result = result.concat(",");
                                }
               } 
  result = result.concat(")"); 

   return result;             
  } 


final public String toXSB(){ 
	String result = ""; 
	if(isNegated) result=result.concat("tnot(");    
  		result = result + "p_" + Atom;
	if((Arguments!=null) && (Arguments.length>0)){ 
		result = result.concat("(");
		int k = Arguments.length;
             		for(int i=0; i< k; i++) {
           			result=result.concat(Arguments[i].toXSB());
           			if(i< k-1) result = result.concat(",");
			}
		result = result.concat(")"); 
	} 
	if(isNegated) result=result.concat(")"); 
	return result;             
} 
final public String toSimple(){ 
	String result = ""; 
	if(isNegated) result=result.concat("-");    
  		result = result + "p_" + Atom;
	if((Arguments!=null) && (Arguments.length>0)){ 
		result = result.concat("(");
		int k = Arguments.length;
             		for(int i=0; i< k; i++) {
           			result=result.concat(Arguments[i].toSimple());
           			if(i< k-1) result = result.concat(",");
			}
		result = result.concat(")"); 
	} 
	return result;             
} 


}

class NormalClause
{ }


class ProgRule extends NormalClause
  { Vector Head;
    Vector Body;

    ProgRule(Vector H, Vector B)
       { Head = H;
         Body = sort(B);
       }
 final    Vector getHead() { return Head;}
 final    Vector getBody() { return Body;}

ProgRule(Vector H)
       { Head = H;
         Body = null;
       }


final public Rule translate(AVLTreeSymbol PredSymbol, 
                                    AVLTreeSymbol FuncSymbol,
                         AVLTreeString Strings)
{ 
 
  int h = Head.size();
  int i = 0;



/* Head[] he = new Head[h];
 if(Body==null || Body.size()==0) // we have ad fact: add Head as a fact to ruleset!
     { for(i=0;i < h ; i++)
        he[i] =  ((Literal) Head.elementAt(i)).toHead(mapping,varcount,PredSymbol,
                                                      FuncSymbol,
                                                      Strings); 
       RS.AddRule(new Rule(he,null));
          
     }
*/
/*
    if(Body==null || Body.size()==0) // we have a fact: add Head as a fact to ruleset!
     { for(i=0;i < h ; i++)
          ((Literal) Head.elementAt(i)).addFact(RS,PredSymbol,
                                                      FuncSymbol,
                                                      Strings); 

          
     }
 

  else {
*/
      Hashtable mapping = new Hashtable(7);
      IntWrapper varcount = new IntWrapper(0);
      Head[] heads = new Head[h];
      int b = Body.size();
      Body[] bodies = new Body[b];
      for(i=0; i < h; i++)
         { heads[i]=  ((Literal)Head.elementAt(i)).toHead(mapping,varcount,PredSymbol,
                                                          FuncSymbol,
                                                          Strings); 
         }
	for(i=0;i < b; i++){
	bodies[i]=  ((Literal)Body.elementAt(i)).toBody(mapping,varcount,PredSymbol,
                                                           FuncSymbol,
                                                           Strings); 
	}
      return new Rule(heads,bodies);
}

 

final public String toString()
 { String result = "";
   int i;
   if(Body ==null || Body.size()==0)  {   //is a fact   
      for(i= 0; i< Head.size(); i++) 
         { 
     result = result.concat(Head.elementAt(i).toString()).concat(". ");
         }
       }
  else
   {int l;
    if(Head==null) l=0; else l=Head.size();
    for(i= 0; i< Head.size(); i++) 
         { 
    result = result.concat(Head.elementAt(i).toString());
    if(i< Head.size()-1) result=result.concat(" & ");
         }


    result=result.concat("<-");   
  for(i= 0; i< Body.size(); i++) 
         { 
    result = result.concat(Body.elementAt(i).toString());
    if(i< Body.size()-1) result=result.concat(" & ");
         }
   result=result.concat(".");
  }
   return result;
}






final public String toXSB(){
	String result = "";
	String body="";
   	if(Body!=null && Body.size()>0)  {   //is a rule  
		for(java.util.Enumeration e=Body.elements();e.hasMoreElements();){ 
			body = body +  ((Literal)e.nextElement()).toXSB();
			if(e.hasMoreElements()) result=result.concat(",");
 	        }
	}
	body = body + " .\n";
	for(java.util.Enumeration e=Head.elements();e.hasMoreElements();) { 
    		result = result + ((Literal) e.nextElement()).toXSB() + body;
	}
	return result;
}


final public String toSimple(){
	String result = "";
	String body="";
	if(Body==null || Body.size()>=0)
		for(java.util.Enumeration e=Head.elements();e.hasMoreElements();) { 
    			result = result + ((Literal) e.nextElement()).toXSB() + ".";
		}
	else{
		for(java.util.Enumeration e=Head.elements();e.hasMoreElements();) { 
    			if(e.hasMoreElements()) result=result.concat(" & ");
		}
		for(java.util.Enumeration e=Body.elements();e.hasMoreElements();){ 
			body = body +  ((Literal)e.nextElement()).toXSB();
			if(e.hasMoreElements()) result=result.concat(" & ");
 	        }
	}
	body = body + " .\n";
    	return result;
}





private Vector sort(Vector V)
{ Vector NV = new Vector(V.size());
  int i;
  for(i=0;i<V.size();i++)
    if(((Literal)V.elementAt(i)).isAtom()) NV.addElement(V.elementAt(i));
 
  for(i=0;i<V.size();i++)
    if(((Literal)V.elementAt(i)).isNegAtom()) NV.addElement(V.elementAt(i));
  return NV;
 
}

       




}

class ProgQuery extends NormalClause
  { 
    Vector Body;
    Vector Vars;

 ProgQuery(Vector F)
       { 
         Body = sort(F);
         Vars= null; 
        }


ProgQuery(Vector F, Vector Vars)
       { 
         Body = sort(F);
         this.Vars = Vars;
       }


final Vector getBody() { return Body;}






final public String toString()
// This should now exactly return the syntax j"urgen needs
{ String result = "<-";
  for(int i= 0; i< Body.size(); i++) 
         { 
    result = result.concat(Body.elementAt(i).toString());
    if(i< Body.size()-1) result=result.concat(" & ");
         }
result=result.concat(".\n");
   return result;
}


final public String toSimple(){
// This should now exactly return the syntax j"urgen needs
	String result = "<-";
  	for(int i= 0; i< Body.size(); i++) { 
		result = result.concat(((Literal)Body.elementAt(i)).toSimple());
    		if(i< Body.size()-1) result=result.concat(" & ");
	}
	result=result.concat(".\n");
	return result;
}



final public String toXSB()
// This should now exactly return the syntax j"urgen needs
{ String result = "?-";
  for(int i= 0; i< Body.size(); i++) 
         { 
    result = result.concat(((Literal)Body.elementAt(i)).toXSB());
    if(i< Body.size()-1) result=result.concat(" , ");
         }
result=result.concat(".");
   return result;
}


final public Rule translate(AVLTreeSymbol PredSymbol,
                         AVLTreeSymbol FuncSymbol, 
                         Hashtable Names,Hashtable Numbers,AVLTreeString Strings)
{ 
  Hashtable mapping = new Hashtable(7);
  IntWrapper varcount = new IntWrapper(0);
 
  int i;
  int b = Body.size();
  Body[] bodies = new Body[b];
  for(i=0;i < b; i++)
      { bodies[i]=  ((Literal)Body.elementAt(i)).toBody(mapping,varcount,PredSymbol,
                                                        FuncSymbol, 
                                                         Strings); 
      }
   Rule q = new Rule(null,bodies);
   if(Vars!= null)
   { Vector Nums = new Vector(5,5);
     for(java.util.Enumeration e = Vars.elements();e.hasMoreElements();)
       Nums.addElement(mapping.get(e.nextElement()));
     Names.put(q,Vars);
     Numbers.put(q,Nums);
   } 
return q;
}


private Vector sort(Vector V)
{ Vector NV = new Vector(V.size());
  int i;
  for(i=0;i<V.size();i++)
    if(((Literal)V.elementAt(i)).isAtom()) NV.addElement(V.elementAt(i));
 
  for(i=0;i<V.size();i++)
    if(((Literal)V.elementAt(i)).isNegAtom()) NV.addElement(V.elementAt(i));
  return NV;
 
}
}
 


class FOLTransformer extends Object {
 
final static void transf(FNode Head, FNode Formula,Vector Rules)
{
// Transformation of FOL-Formulas to Rules, using the algorithm i described
// in my diploma thesis p.151 - 154

  Vector Disj = new Vector(10,5);
  Vector ToDo = new Vector(10,5);
  Vector Program = new Vector(10,5);
  getDisjunction(true,Formula, Disj, ToDo); // Results in Disj and ToDo1 ! 
 
  genDisjunction(Head, Disj,ToDo,Rules);
  newRules(ToDo,Rules);

}    

final static void  newRules(Vector ToDo, Vector Rules)
{ 
  for(int i=0;i<ToDo.size();i++)
    {
      transf(((FRule) ToDo.elementAt(i)).getHead(),
             ((FRule) ToDo.elementAt(i)).getBody(),Rules);
    }
}


final static void genDisjunction(FNode Head, Vector Disj,Vector ToDo,Vector Rules)
{ 
  Vector Conj;
  for(int i= 0;i<Disj.size();i++)
      { Conj = new Vector(10,5);
        getConjunction(true,(FNode)(Disj.elementAt(i)),Conj,ToDo);
        Rules.addElement(new ProgRule(FRule.toVector(Head),genBody(Conj,ToDo)));
       }  
}
 
final static Vector genBody(Vector Conj, Vector ToDo)
{ 
  Vector Body = new Vector(10,5);
  for(int i=0; i<Conj.size(); i++)
    { 
      if(((FNode)Conj.elementAt(i)).isLiteral())
         { Body.addElement( ((FNode) Conj.elementAt(i)).toLiteral());}
      else
       {
          Vector Free = new Vector(10,5);
          Vector Bound = new Vector(10,5);
          ((FNode)Conj.elementAt(i)).FreeBoundVariables(Free,Bound);

          FTerm[] Arguments1 = new FTerm[Free.size()];
          FTerm[] Arguments2 = new FTerm[Free.size()];
          String k;
          for(int l=0; l< Free.size();l++)
	     { k =  ((String) Free.elementAt(l)); 
                Arguments1[l] =   new FTermVariable(k);
                Arguments2[l] =   new FTermVariable(k);
             }
          String P = PredicateGenerator.getNewPredicate(); 
          FNode Pred1 = new FAtom(P,Arguments1);
          FNode Pred2 = new FAtom(P,Arguments2);
          Body.addElement(Pred1.toLiteral());
          ToDo.addElement(new FRule(Pred2,(FNode)Conj.elementAt(i)));
        }
     }
return Body;
}
  

final static void getDisjunction(boolean Pol, FNode Formula, Vector Disj, Vector ToDo)
{ if(Formula.isNot()) { 
               getDisjunction(!Pol, Formula.getLeft(),Disj,ToDo);
                      }
  else if(Pol && Formula.isOr()) {
               getDisjunction(Pol, Formula.getLeft(),Disj,ToDo);
               getDisjunction(Pol, Formula.getRight(),Disj,ToDo);
                                 }
  else if(!Pol && Formula.isAnd())
                                 {
               getDisjunction(Pol, Formula.getLeft(),Disj,ToDo);
               getDisjunction(Pol, Formula.getRight(),Disj,ToDo);
                                 }
  else if(Pol && Formula.isImpliedBy())
                                 {
               getDisjunction(Pol, Formula.getLeft(),Disj,ToDo);
               getDisjunction(!Pol, Formula.getRight(),Disj,ToDo);
                                 }
  else if(Pol && Formula.isImplies())
                                 {
               getDisjunction(!Pol, Formula.getLeft(),Disj,ToDo);
               getDisjunction(Pol, Formula.getRight(),Disj,ToDo);
                                 }
  else if(!Pol && Formula.isEquiv())
                                 {
               Hashtable h = new Hashtable(7);
               Hashtable h1 = new Hashtable(7);
               IMPLIEDBY_FNode NF1 = new  IMPLIEDBY_FNode(Formula.getLeft(),Formula.getRight());
               IMPLIES_FNode NF2 = new IMPLIES_FNode(Formula.getLeft().copyFormula(h),Formula.getRight().copyFormula(h1));
               getDisjunction(Pol,NF1,Disj,ToDo);
               getDisjunction(Pol,NF2,Disj,ToDo);
                                  }
  else if(!Pol && Formula.isExists()) 
                                 {
	       // System.out.println("In getDISjunction");
               Vector Free = new Vector(10,5);
     
               Vector Bound = new Vector(10,5);
               Formula.FreeBoundVariables(Free,Bound);
               // System.out.println("Free = " + Free.toString());
               // System.out.println("Bound = " + Bound.toString());
               FTerm[] Arguments1 = new FTerm[Free.size()];
               FTerm[] Arguments2 = new FTerm[Free.size()];
               String k;
               for(int i=0; i< Free.size();i++)
		 { k =  ((String)Free.elementAt(i)); 
                   Arguments1[i] =   new FTermVariable(k);
                   Arguments2[i] =   new FTermVariable(k);
                 }
               String P = PredicateGenerator.getNewPredicate(); 
               FNode Pred1 = new FAtom(P,Arguments1);
               FNode Pred2 = new FAtom(P,Arguments2);
               FNode not = new NOT_FNode(Pred1);
               Disj.addElement(not);
               // System.out.println("ToDo: " + Pred2.toString() + "<-" + Formula.toString());
               ToDo.addElement(new FRule(Pred2,Formula)); 
                                   }

   else if(Pol && Formula.isExists())
                                  {
                getDisjunction(Pol, Formula.getLeft(),Disj,ToDo);
                                  }
   else if(Formula.isForall())
                                  {
               NOT_FNode not = new  NOT_FNode(Formula.getLeft());
               EXISTS_FNode newF = new EXISTS_FNode(Formula.getVariables(),not);
               getDisjunction(!Pol, newF,Disj,ToDo);
                                  }
   else if(Pol)          
                                  {
               Disj.addElement(Formula);
                                  }
   else if(!Pol)
                                  {
               NOT_FNode not = new NOT_FNode(Formula);
               Disj.addElement(not);
                                  }
}
  
final static void getConjunction(boolean Pol, FNode Formula, Vector Conj, Vector ToDo)
{ 

  if(Formula.isNot()) { 


          
               getConjunction(!Pol, Formula.getLeft(),Conj,ToDo);
                      }
  else if(Pol && Formula.isAnd()) {
               getConjunction(Pol, Formula.getLeft(),Conj,ToDo);
               getConjunction(Pol, Formula.getRight(),Conj,ToDo);
                                 }
  else if(!Pol && Formula.isOr())
                                 {
               getConjunction(Pol, Formula.getLeft(),Conj,ToDo);
               getConjunction(Pol, Formula.getRight(),Conj,ToDo);
                                 }
  else if(!Pol && Formula.isImpliedBy())
                                 {
               getConjunction(!Pol, Formula.getRight(),Conj,ToDo);
               getConjunction(Pol, Formula.getLeft(),Conj,ToDo);
                                 }
  else if(!Pol && Formula.isImplies())
                                 {
               getConjunction(!Pol, Formula.getLeft(),Conj,ToDo);
               getConjunction(Pol, Formula.getRight(),Conj,ToDo);
                                 }
  else if(Pol && Formula.isEquiv())
                                 {
               Hashtable h = new Hashtable(7);
               Hashtable h1 = new Hashtable(7);
               IMPLIEDBY_FNode NF1 = new IMPLIEDBY_FNode(Formula.getLeft(),Formula.getRight());
               IMPLIES_FNode NF2 = new IMPLIES_FNode(Formula.getLeft().copyFormula(h),Formula.getRight().copyFormula(h1));
               getConjunction(Pol,NF1,Conj,ToDo);
               getConjunction(Pol,NF2,Conj,ToDo);
                                  }
  else if(!Pol && Formula.isExists()) 
                                 {
               Vector Free = new Vector(10,5);
               Vector Bound = new Vector(10,5);
	       //System.out.println("In getConjuntion");
               Formula.FreeBoundVariables(Free,Bound);
               //System.out.println("Free = " + Free.toString());
               //System.out.println("Bound = " + Bound.toString());
               FTerm[] Arguments1 = new FTerm[Free.size()];
               FTerm[] Arguments2 = new FTerm[Free.size()];
               String k;
               for(int i=0; i< Free.size();i++)
		 { k =  ((String)Free.elementAt(i)); 
                             Arguments1[i] =   new FTermVariable(k);
                             Arguments2[i] =   new FTermVariable(k);
                 }
               String P = PredicateGenerator.getNewPredicate(); 
               FNode Pred1 = new FAtom(P,Arguments1);
               FNode Pred2 = new FAtom(P,Arguments2);
               NOT_FNode not = new NOT_FNode(Pred1);
               // System.out.println("New Atom " + Pred1.toString());
               Conj.addElement(not);
               ToDo.addElement(new FRule(Pred2,Formula));
                                  }
   else if(Pol && Formula.isExists())
                                  {
                getConjunction(Pol, Formula.getLeft(),Conj,ToDo);
                                  }
   else if(Formula.isForall())
                                  {
               NOT_FNode not = new  NOT_FNode(Formula.getLeft());             
               EXISTS_FNode newF = new EXISTS_FNode(Formula.getVariables(),not);
               getConjunction(!Pol, newF,Conj,ToDo);
                                  }
   else if(Pol)          
                                  {
               Conj.addElement(Formula);
                                  }
   else if(!Pol)
                                  {
               NOT_FNode not = new NOT_FNode(Formula);
               Conj.addElement(not);
                                  }
}
   
}



class IntWrapper
{ public int i;
  IntWrapper() { i=0;}
  IntWrapper(int i) {this.i=i;}
  
}





class PredicateGenerator{ 
static int numb = 0;
final public static int getNewPredNumber() 
  { numb ++;
    return numb;
  }

final public static void resetPredNumber() { numb = 0;}
final static public String getNewPredicate()
  {return "p" + new Integer(numb++).toString();} 

}

