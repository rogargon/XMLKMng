/*

Name: BuiltinFunc.java

Version: 1.01

Purpose:

History:
2.5.99 Added support for new builtin mechanism. SDe
	(Some Methods are declared public now)
3.5.99 Deleted arity and symbol method again. SDe

*/

package edu.unika.aifb.inference;

public class BuiltinFunc {
	Atoms D;
	int index[];
	Atom T;
	Atom ins;

	public boolean evaluable(Atom t) {return true;}
	
	boolean isevaluable(Atom T, Atom t) {
		Variable v;
		Atom f;
		int i;
		for(v = T.variables; v!= null; v=v.next) 
			v.subsby = t.terms[v.symbol];
		f = new Atom(T.terms.length);
		for(i = 0; i < T.terms.length; i++) {
			f.terms[i] = T.terms[i].Substitute();
		}
		f.Variables();
		T.ClearVariables();
		return evaluable(f);
	}

	
	public void eval(Atom t) {}
		
	public void insert(Atom t1) {
		Atom t;
		boolean inserted, unified;
		Variable v;
		
		unified = T.Match(t1);
		t = new Atom(D.stellen);
		for (v = T.variables; v != null; v = v.next) 
			t.terms[index[v.symbol]] = v.subsby;
		ins = (Atom)D.Insert(t);
		if (ins == t) {
			t.next2 = D.tuples2;
			D.tuples2 = t;
		}
		else {
			t = null;
		}
		t1.ClearVariables();
		T.ClearVariables();
	}	
	
}

