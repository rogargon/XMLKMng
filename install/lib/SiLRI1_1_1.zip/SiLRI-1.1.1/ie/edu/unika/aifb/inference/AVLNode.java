/*

Name: AVLNode.java

Version: 1.0

Purpose:

History:

*/

package edu.unika.aifb.inference;

import java.io.*;
import java.util.*;
import java.net.*;

public class AVLNode {
	// left, right tree and duplicates in the middle
	public AVLNode links = null, rechts = null, mitte = null;
	public int balance = 0;	
	public void print() {}
	public void write(RandomAccessFile f) throws IOException {}
	public static int anz = 0;
	public AVLNode () {
		anz++;
	}
}
