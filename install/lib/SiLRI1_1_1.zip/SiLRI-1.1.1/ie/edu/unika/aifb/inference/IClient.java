/*

Name: SiLRI.java

Version: 1.0

Purpose:

History:

*/

package edu.unika.aifb.inference;

import java.util.Date;
import java.util.Random;
import java.lang.Long;
import java.io.*;
import java.util.*;
import java.net.*;

public class IClient extends Thread {
	static int no = 0;
	static int num = 0;
	int n = 0;
        Socket socket = null;
        DataInputStream is = null;
        PrintStream os = null;
   	int port = 1236;
	Rule rule;
	SParser spars;
	Atoms filter;
	RuleSet rs;
	Atoms B;
	String host;

	public IClient(Rule r, RuleSet rs) {
		no++;
		n = num++;
		port = r.port;
		host = r.host;
		spars = new SParser();
		System.out.print("running IClient no "); System.out.println(n);
		rule = r;
		this.rs = rs;
		filter = rule.StartExternalEvaluation();
		B = new Atoms(rule.heads[0].up.stellen);
    		this.setPriority( Thread.NORM_PRIORITY );
		//System.out.println("DBAccess");
		/*System.out.println("Filterterme:");
		filter.print(System.out);
		System.out.println("-------------------------------------");
		*/
		this.start();
		//this.run();
	}


	public void run() {
		// System.out.print("running DBClient no "); System.out.println(n);

		// Initialize the sockets and streams
		while (true) {
		        try {
			    InetAddress ina = InetAddress.getByName(host);
		            socket = new Socket(ina, port);
			    break;

		        }
		        catch (IOException e) {
		            //System.err.println("Exception: couldn't connect to database"
		            //   + e.getMessage());
		        }
		}
	        try {
	            is = new DataInputStream(socket.getInputStream());
	            os = new PrintStream(socket.getOutputStream(),true);
	        }
	        catch (IOException e) {
	            System.err.println("Exception: couldn't create stream to database"
	                + e.getMessage());
	        }

		// Process user input and server responses
	        try {
	            	String inLine;
		    	Fact f;
			GroundAtom a,b;
			os.println(n);
			filter.internalize(os,rule.heads[0].symbol);
		     	os.println("stop");
	             	os.flush();
			//System.out.println("Ergebnisse: ");
	             	while ((inLine = is.readLine()) != null) {
			   // System.out.print("inline: "); System.out.println(inLine);
	                   if (inLine.length() > 0) {
		        	if (inLine.equals("stop"))
	                            break;
				spars.ParseString(inLine);
				try {
					f = spars.fact();
					b = new Atom(f.terms);								
					a = B.Insert(b);
					//f.print(System.out); System.out.println();
					//System.out.println(r.hrelation.stellen);
				}
				catch (JanParseError1 e){
					f = null;
				}
	                    }
	        	}
	   		// Cleanup
	    		os.close();
	    		is.close();
	    		socket.close();
	        }
	        catch (IOException e) {
	            System.err.println("I/O error: "+ e.toString());
	        }
		rule.FinishExternalEvaluation(B);
		if (rule.heads[0].addup.anztuples > 0)
			rs.insertqueue(rule);
		no--;
/*
		System.out.println("Ergebnisse: ");
		rule.heads[0].addup.print(System.out);

		System.out.print("terminating DBClient no "); System.out.println(n);
		System.out.println("=================================================");
*/

	}
}

