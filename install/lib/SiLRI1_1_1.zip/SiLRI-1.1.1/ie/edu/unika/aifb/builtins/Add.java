/*

Name: Add.java

Version: 1.0

Purpose:

History:

*/

package edu.unika.aifb.builtins;

import edu.unika.aifb.inference.BuiltinFunc;
import edu.unika.aifb.inference.Variable;
import edu.unika.aifb.inference.Atom;
import edu.unika.aifb.inference.NumTerm;
import java.lang.Math;




public class Add extends BuiltinFunc {


	public boolean evaluable(Atom t) {
		int i;
		int anzbound = 0;
		boolean ok = true;
		for (i = 0; i < 3; i++)
			if (t.terms[i].ground) {
				anzbound++;
				if (!(t.terms[i] instanceof NumTerm))
					ok = false;
			}
			else if (!(t.terms[i] instanceof Variable))
				ok = false;
		if (anzbound < 2)
			ok = false;			
		return ok;
	}

	public void eval(Atom t) {
		int i;
		boolean ok = true;
		if (evaluable(t)) {
			ok = false;
			if (t.terms[0].ground && t.terms[1].ground && t.terms[2].ground) {				
				if (((NumTerm)t.terms[0]).zahl + ((NumTerm)t.terms[1]).zahl == ((NumTerm)t.terms[2]).zahl)
					ok = true;
			}
			else if (t.terms[0].ground && t.terms[1].ground) {
				((Variable)t.terms[2]).subsby = new NumTerm(((NumTerm)t.terms[0]).zahl + ((NumTerm)t.terms[1]).zahl,0,true);
				ok = true;
			}
			else if (t.terms[0].ground && t.terms[2].ground) {
				((Variable)t.terms[1]).subsby = new NumTerm(((NumTerm)t.terms[2]).zahl-((NumTerm)t.terms[0]).zahl,0,true);
				ok = true;
			}
			else if (t.terms[1].ground && t.terms[2].ground) {
				((Variable)t.terms[0]).subsby = new NumTerm(((NumTerm)t.terms[2]).zahl-((NumTerm)t.terms[1]).zahl,0,true);
				ok = true;
			}
			if (ok) {
				insert(t);	
			}
		}		
	}
	
}


