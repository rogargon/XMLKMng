/*

Name: StringTerm.java

Version: 1.0

Purpose:

History:

*/

package edu.unika.aifb.inference;

import java.lang.String; 
import java.io.*;
import java.util.*;
import java.net.*;

public class StringTerm extends Term {
	// type = 3
	public String s;	// repr�sentiert die Zeichenkette

	public StringTerm(String st, Term terms[]) {
		// Funktion mit String st als Funktionssymbol
		// terms enthaelt die Parameter
		super(terms.length,true);
		int i;
		boolean ground = true;
		if (terms.length > 0) groundlevel = terms[0].groundlevel+1;
		for(i = 0; i < terms.length; i++) {
			if (!terms[i].ground) ground = false;
			if (terms[i].groundlevel+1 < groundlevel) groundlevel = terms[i].groundlevel+1;
			pars[i] = terms[i];
		}
		this.ground = ground;
		s = st; 
	}
	public StringTerm(String st) {
		// Stringkonstante
		super(0,true);
		s = st;
	}	
	public StringTerm(String st, int stelligkeit, boolean grnd) {
		super(stelligkeit,grnd);
		s = st;
	}
	public boolean isStringTerm() {return true;}
	
	public int type() {return 3;}

	public void print1(PrintStream p) {p.print("\""+s+"\"");}
	public void print1(PrintStream pr, String p[],String f[], String s[]) {
		System.out.println(s);
		pr.print(s);
	}
	
	public void internalize1(PrintStream p) {
		//System.out.print("\""+s+"\"");
		//f.writeBytes("\""+s+"\"");
		p.print("\""+s+"\"");
	}	

	public String toString1(String p[],String f[], String st[]) {
		// Ausgabe des einzelnen StringTerms (ohne Unterterme) als Zeichenkette
		return "\""+s+"\"";
	}
	public String toString1() {
		// Ausgabe des einzelnen StringTerms (ohne Unterterme) als Zeichenkette
		return "\""+s+"\"";
	}
	public int CompareEqual(Term t) {
		int res;
		// Vergleicht zwei Zeichenketten miteinander
		res = s.compareTo(((StringTerm)t).s);
		return res<=0?(res<0?-1:0):1;
	}
	public Term Substitute() {
		// Durchf�hrung einer Substitution, d.h. die Variable wird durch ihren
		// Substituenden im Term ersetzt
		// Dabei werden alle oberen Terme (oberhalb von Variablen) neu generiert
		Term t;
		int i;
		if (ground) return this;
		else {
			t = new StringTerm(s,anzpars, true);
			ground = true;
			for(i = 0; i < anzpars; i++) {
				t.pars[i] = pars[i].Substitute();
				if (!t.pars[i].ground) t.ground = false;
			}
			return t;
		}
	}
	
	public Term Clone() {
		// Klonen des Terms mit allen Untertermen
		StringTerm t;
		int i;
		t = new StringTerm(s,anzpars,ground);
		for (i = 0; i < anzpars; i++)
			t.pars[i] = pars[i].Clone();
		return t;
	}
	public Term clone1() {
		return new StringTerm(s,anzpars,ground);
	}

}


