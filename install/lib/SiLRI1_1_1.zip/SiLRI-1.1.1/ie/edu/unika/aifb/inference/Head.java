/*

Name: Head.java

Version: 1.0

Purpose:

History:

*/

package edu.unika.aifb.inference;



public class Head extends RuleAtom {
	// Kopfatom

	public Head(int sym, Term[] terme) {
		// sym = Pr�dikatsymbol,terme = Feld von anz Termen
		super(sym,terme);
		up = new Atoms(terms.length);
		addup = new Atoms(terms.length);
		down = new Atoms(anzvars);
		adddown = new Atoms(anzvars);
	}
	
	public boolean Up(Atoms brel, int bindex[]) {
		// Substituiert die Variablen im Kopfatom durch die Zeilen der Relation brel und fuegt die
		// entstandenen Grundatome in die Relation up ein
		int oldnum, newnum;	
		oldnum = up.anztuples;
		up.Substitute(this,brel,bindex);
		newnum = up.anztuples;
		return oldnum != newnum;
	}

}


