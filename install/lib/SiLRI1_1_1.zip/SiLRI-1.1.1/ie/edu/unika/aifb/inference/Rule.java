/*

Name: Rule.java

Version: 1.0

Purpose:

History:

*/

package edu.unika.aifb.inference;

import java.lang.Long;
import java.io.*;
import java.util.*;
import java.net.*;

public class Rule {
	// repr�sentiert eine Regel
	Rule next1 = null;  			// Verkettungen innerhalb von RuleSet
	Rule last1 = null;			// Doppeltverzeigerung innerhalb von RuleSet
	Rule next2 = null;			// Verkettung der Regeln auf dem gleichen Stratum
	Rule last2 = null;			// Doppeltverzeigerung der Straten
	Rule next3 = null;			// Verkettung der Regeln auf dem gleichen Stratum zum Evaluieren
	Rule next4 = null;			// Verkettung von Fakten und Queries
	Rule last4 = null;			// Doppeltverzeigerung
	int anzheads = 0, anzbodies = 0; 	// Anzahl Kopf- und Rumpfatome
	int anzvars = 0;  			// Anzahl Variablen, Variablen sind von 0 ab nummeriert
	Atoms brelation = null; 		// Rumpfrelation
	Atoms hrelation = null;			// pos. Ergebnissubstitution bei dynamischer Evaluierung
	Atoms addhrel = null;			// inkrementelle Berechnung
	Atoms drelation = null;			// Relation zum Verteilen auf Rumpfatome
	int bindex[];				// Variablen�berschriften f�r brelation
	Body bodies[];				// Rumpfatome
	Head heads[];				// Kopfatome
	int stratum;				// Stratum der Regel
	boolean facts = false;			// Regel repr�sentiert lediglich Fakten (kein Rumpf, Kopf grund)
	boolean toeval = false;			// befindet sich in der Evaluierungswarteschlange
	boolean evaluating = false;		// wird gerade evaluiert
	boolean stoppedevaluating = false;      // Evaluierung ist fertig
	int no = 0;				// Nummerierung der Regeln
	int anzpos = 0;				// Anzahl positiver Rumpfterme (muessen vorne stehen)
	long anzahl = 0;
	int mark = 0;
	int cycle = 0;
	static Atoms brelleer = new Atoms(0);
	static int bindex0[] = {-1};
	TermSet btermsets[] = null;
	boolean changebts[];
	boolean external = false;               // Regel soll (auch) auf anderem Inferenzserver ausgewertet werden
	String host = "";			// host auf dem sich die Regel in einem anderen Inferenzserver befindet
	int port = 1000;			// port des Inferenzservers

	static {
		boolean inserted;
		GroundAtom leer;
		brelleer = new Atoms(0);
		leer = new GroundAtom(0);
		leer = brelleer.Insert(leer);
	}

	synchronized Atoms StartExternalEvaluation() {
		Atoms filter;
		this.evaluating = true;
		this.stoppedevaluating = false;
		filter = new Atoms(this.heads[0].adddown.stellen);
		filter.Union(this.heads[0].adddown);
		this.heads[0].adddown.Clear();
		return filter;
	}
	synchronized void FinishExternalEvaluation(Atoms B) {
		//B.print(System.out);
		//System.out.println("--------------------------------------------");
		this.stoppedevaluating = true;
		this.evaluating = false;
		this.heads[0].up.Union(B);
		this.heads[0].addup.UnionSelected(this.heads[0].up);
		this.heads[0].up.print(System.out);
	}

	public void ClearRule() {
		// L�schen aller Evaluierungszwischenergebnisse
		int i;
		for (i = 0; i < anzheads; i++)
			heads[i].ClearRuleAtom();
		for (i = 0; i < anzbodies; i++)
			bodies[i].ClearRuleAtom();
		hrelation.Clear();
		addhrel.Clear();
		if (brelation != null) brelation.Clear();
	}
	
	public void ClearRule1() {
		// L�schen aller Evaluierungszwischenergebnisse
		int i;
		for (i = 0; i < anzheads; i++)
			heads[i].ClearRuleAtom();
		for (i = 0; i < anzbodies; i++)
			bodies[i].ClearRuleAtom1();
		hrelation.Clear();
		addhrel.Clear();
		if (brelation != null) brelation.Clear();
	}
	
	public void print(PrintStream p) {
		int i;
		System.out.print(no); System.out.print(": ");
		for (i = 0; i < anzheads; i++) {
			heads[i].print(p);
			if (i < anzheads-1) p.print(" & ");
		}
		p.print(" <- ");
		for (i = 0; i < anzbodies; i++) {
			bodies[i].print(p);
			if (i < anzbodies-1) p.print(" & ");
		}
		p.print(".");
	}
	
	public void internalize(PrintStream p) {
		Integer Anzheads = new Integer(anzheads);
		Integer Anzbodies = new Integer(anzbodies);
		int i;
		Character ch;

		//ch = new Character((char)((int)(anzheads)));
		//System.out.print(ch.toString());	
		//ch = new Character((char)((int)(anzbodies)));
		//System.out.print(ch.toString());
		// System.out.print("l"); System.out.print(anzheads); System.out.print("l"); System.out.print(anzbodies);	
		//f.writeBytes("l"+Anzheads.toString());
		//f.writeBytes("l"+Anzbodies.toString());

		p.print("l"+Anzheads.toString() + "l"+Anzbodies.toString());

		for (i = 0; i < anzheads; i++) {
			heads[i].internalize(p);
		}
		for (i = 0; i < anzbodies; i++) {
			bodies[i].internalize(p);
		}
	}

	public Rule(Head h[], Body b[]) {
		int i,j,p,q,s,k,m;
		Body bd;
		Head hd;
		Variable v;
		if (h != null) anzheads = h.length;
		else anzheads = 0;
		if (b != null) anzbodies = b.length; 
		else anzbodies = 0;
		
		anzvars = 0;
		bodies = b; heads = h;
		// Bestimmen des maximalen Variablensymbols
		for (i = 0; i < anzbodies; i++) {
			if (b[i].maxvarsym >= anzvars)
				anzvars = b[i].maxvarsym+1;
			if (!b[i].neg)
				anzpos++;
		}
		for (i = 0; i < anzheads; i++)
			if (h[i].maxvarsym >= anzvars)
				anzvars = h[i].maxvarsym+1;
		facts = false;  // Angabe ob Regel nur fuer Fakten eingefuegt
		stratum = 0;    // Stratum der Regel
		
		// Initialisierung der Rumpfatome
		for (i = 0; i < anzbodies; i++) {
			bd = bodies[i];
			bd.dindex = new int[bd.anzvars];
			bd.bindex = new int[anzvars+1];
			//bd.hindex = new int[anzvars+1];
			//bd.sindex1 = new int[bd.anzvars+1];
			//bd.sindex2 = new int[bd.anzvars+1];
			//bd.sdindex = new int[bd.anzvars];
			if (i > 0) bodies[i-1].index2 = new int[bd.anzvars+1];
			bd.rule = this;
			for (j = 0; j < anzvars+1; j++) {
				bd.bindex[j] = -1;
				//bd.hindex[j] = -1;
			}			
			for (v=bd.variables, j=0; v !=null; v=v.next,j++) {
				bd.dindex[j] = -1;
				//bd.sdindex[j] = -1;
			}
			bd.termsets = new TermSet[anzvars];
			bd.btermsets = new TermSet[anzvars];
			bd.changets = new boolean[anzvars];
			bd.changebts = new boolean[anzvars];
		}
		q = 0;
		if (anzbodies > 0) {
			// brelation, bindex und dindex f�r 1. Rumpfatom
			for(q = 0; bodies[0].vars2[q] != -1; q++) {
				bodies[0].bindex[bodies[0].vars2[q]] = q;
				bodies[0].dindex[q] = q;
			}
			bodies[0].brelation = bodies[0].up;
		}
			
		// rule-Verweis f�r Kopfatome	
		for (i = 0; i < anzheads; i++) {
			heads[i].rule = this;
		}		


		// bindex, index1, index2, brelation f�r andere Rumpfatome
		for(i = 1; i < anzbodies; i++) {
			for (j = 0; j < anzvars; j++) {
				bodies[i].bindex[j] = bodies[i-1].bindex[j];
			}
			p = 0; m = 0; k = 0;
			for(j = 0; bodies[i].vars2[j] != -1; j++) {
				if (bodies[i-1].bindex[bodies[i].vars2[j]] != -1) {
					bodies[i].index1[p] = j;
					bodies[i-1].index2[p] = bodies[i-1].bindex[bodies[i].vars2[j]];
					p++;
				}
				else {
					if (!bodies[i].neg) {
						bodies[i].dindex[j] = q;
						bodies[i].bindex[bodies[i].vars2[j]] = q;
						q++;
					}
				}
			}
			bodies[i-1].index2[p] = -1;
			bodies[i].index1[p] = -1;
			bodies[i].brelation = new Atoms(q);
		}
		if (anzbodies > 0) {	
			// brelation und bindex der Regel entspricht der brelation des letzten Rumpfatoms
			brelation = bodies[i-1].brelation;
			bindex = bodies[i-1].bindex;
		}
		
		
		// Initialisierungen fuer das dynamische Filtern
		for (i = 0; i < anzbodies; i++) {
			bodies[i].hrelation = new Atoms(anzvars);  // Atome, die nach unten propagiert werden
			bodies[i].addhrel = new Atoms(anzvars);  // Atome, die nach unten propagiert werden
		}
		hrelation = new Atoms(anzvars);  // Ergebnisse der Evaluierung der Rumpfatome
		addhrel = new Atoms(anzvars);    // Zwischenergebnisse der Evaluierung der Rumpfatome
		drelation = new Atoms(anzvars);  // auf die Rumpfatome zu verteilende Atome
		if (anzbodies > 0) {
		    btermsets = bodies[anzbodies-1].btermsets;
		    changebts = bodies[anzbodies-1].changebts;
		}
		else {
		    btermsets = new TermSet[anzvars];
		    changebts = new boolean[anzvars];
		} 
	}

	public boolean Switch() {
		// schaltet die negativen Rumpfliterale bei alternierendem Fixpunkt um
		int i;
		boolean switched = false;
		for (i = 0; i < anzbodies; i++)
			switched = bodies[i].Switch() || switched;
		return switched;
	}
	
	public void printneg(PrintStream p) {
		int i;
		boolean switched = false;
		for (i = 0; i < anzbodies; i++)
			if (bodies[i].neg) {
				bodies[i].print(p);
				p.println("up");
				bodies[i].up.print(p);
				p.println("up1");
				bodies[i].up1.print(p);
				p.println("up2");
				bodies[i].up2.print(p);
			}
	}


	public boolean NaiveEval() {
		// Auswertung der Regel durch naive Evaluierung
		int i, oldnum;
		boolean change = false;
		if (anzbodies > 0) {
		// Verkn�pfung der Rumpfrelationen
			if (bodies[0].builtin)
				change = bodies[0].NaiveRight(brelleer,bindex0) || change;
			for(i = 1; i < anzbodies; i++) {
				change = bodies[i].NaiveRight(bodies[i-1].brelation,bodies[i-1].index2) || change;
			}
			// Einsetzen in Kopfatome
			for(i = 0; i < anzheads; i++) {
				change = heads[i].Up(bodies[anzbodies-1].brelation,bodies[anzbodies-1].bindex) || change;
				// change = heads[i].Up(brelation,bindex) || change;
			}
		}
		return change;
	}



	public boolean TermEval() {
		// Berechnung der an den einzelnen Stellen m�glichen Terme
		int i,j,k,oldanz;
		boolean change = false;
		Variable v;
//System.out.print("Regel "); System.out.println(this.no);
		if (anzbodies > 0) {
		    if (!bodies[0].neg) {
			    for (j = 0; j < bodies[0].terms.length; j++) {
				if (bodies[0].terms[j] instanceof Variable){
				    k = ((Variable)bodies[0].terms[j]).symbol;
				    if (bodies[0].changets[k]) {
					bodies[0].changets[k] = false;
					if (bodies[0].btermsets[k] == null) 
					    bodies[0].btermsets[k] = new TermSet();
					oldanz = bodies[0].btermsets[k].anzterms;
					bodies[0].btermsets[k].Union(bodies[0].termsets[k]);
					bodies[0].changebts[k] = (bodies[0].btermsets[k].anzterms != oldanz);
				    }
				}
			    }
		    }
		    // Verkn�pfung der Rumpfrelationen
		    for(i = 1; i < anzbodies; i++) {
			if (!bodies[i].neg) {
				for (j = 0; j < bodies[i].terms.length; j++) {
				    if (bodies[i].terms[j] instanceof Variable) {
				        k = ((Variable)bodies[i].terms[j]).symbol;
					    if (bodies[i].btermsets[k] == null) 
			    		    	bodies[i].btermsets[k] = new TermSet(); 
			    		if (bodies[i].termsets[k] == null) 
			    		    	bodies[i].termsets[k] = new TermSet(); 
				        if (bodies[i].changets[k] || bodies[i-1].changebts[k]) {
					    bodies[i].changets[k] = false;
				   	    bodies[i-1].changebts[k] = false;
					    if (bodies[i-1].btermsets[k] != null){
					        oldanz = bodies[i].btermsets[k].anzterms;
					        bodies[i].btermsets[k].Intersect(bodies[i-1].btermsets[k],bodies[i].termsets[k]);
					        bodies[i].changebts[k] = (oldanz != bodies[i].btermsets[k].anzterms) || change;
					    }
					    else {
						    oldanz = bodies[i].btermsets[k].anzterms;
					        bodies[i].btermsets[k].Union(bodies[i].termsets[k]);
						    bodies[i].changebts[k] = (bodies[i].btermsets[k].anzterms != oldanz);
					    }
					}
				    }
				}
			}
			for(j = 0; j < bodies[i].btermsets.length; j++) {
			    if (bodies[i].btermsets[j] == null) {
				bodies[i].btermsets[j] = bodies[i-1].btermsets[j];
			    }
			    if (bodies[i].btermsets[j] == bodies[i-1].btermsets[j]) {			
				bodies[i].changebts[j] = bodies[i-1].changebts[j];
			    }
			    bodies[i-1].changebts[j] = false;	
			}		
		    }
		}
		change = false;
		for(j = 0; j < changebts.length; j++)
			change = change || changebts[j];
		return change;
	}


	private void down(Atom t, int b) {
		Variable v;
		Atom f;
		Atom ins;
		int i;
		boolean inserted;
		// Verteilen des Atoms auf das Rumpfatom b

		if (t == bodies[b].hrelation.Insert(t)) {
			ins = (Atom)bodies[b].addhrel.Insert(t);
			t.Mark(b);  // Markieren, dass dieses Rumpfatom bearbeitet
			// Substitutieren der Variablen des Rumpfatoms
			for(v = bodies[b].variables; v!= null; v=v.next) 
				v.subsby = t.terms[v.symbol];
			f = new Atom(bodies[b].terms.length);
			for(i = 0; i < bodies[b].terms.length; i++) {
				f.terms[i] = bodies[b].terms[i].Substitute();
			}
			f.Variables();
			// Einfuegen in die Relation down und adddown des Rumpfatoms
			if (f == bodies[b].down.Insert(f)) {
				f = (Atom)bodies[b].adddown.Insert(f);
				if (bodies[b].neg && !bodies[b].builtin)
					bodies[b].delayed = true;
			}
			bodies[b].ClearVariables();
		}
	}

	private boolean distribute(Atoms R) {
		// Verteilung der Atome in R auf die Rumpfatome
		int i,j;
		int b = -1;			 // betrachtetes Rumpfatom
		double anz, anz1;	
		int ground;
		long lastvars = -1;  // Anzahl uebereinstimmend belegter Terme bei der letzten Auswahl
		long lastmarks = -1;
		boolean inserted;
		boolean repeat = false;
		Atom t;
		// Verteilen auf Rumpfatome
		if (R.anztuples > 0) {
			R.enum1.R1 = R;
			for (t = (Atom)R.enum1.Enum(); t != null; t = (Atom)R.enum1.EnumNext()) {
				// Auswahl des positiven Rumpfatoms
				if ((t.vars != lastvars) || (t.mark != lastmarks)) {
					b = -1; anz = -1;
					for(i = 0; i < anzpos; i++) {
						if (!(t.isMarked(i))) {
							if (bodies[i].anzvars > 0) {
								ground = 0;
								for(j = 0; bodies[i].vars2[j] != -1; j++) {
									if (t.terms[bodies[i].vars2[j]].ground)
										ground++;
								}
								// Verh�ltnis von instantiierten Variablen zu nicht-instantiierten
								anz1 = (double)ground/(double)bodies[i].anzvars; 
							}
							else
								anz1 = 0;
							if (anz1 > anz) {
								if (bodies[i].builtin) {
									 if (((BuiltinBody)bodies[i]).Evaluable(t)) {
										anz = anz1; b = i;
									}
								}
								else {
									anz = anz1; b = i;
								}
							}
						}
					}
					if (b == -1) { // negative Rumpfatome
						for (i = anzpos; (i < anzbodies) && t.isMarked(i); i++);
						if (i < anzbodies)
							b = i;
					}				
				}
				lastvars = t.vars; lastmarks = t.mark;
				if (b == -1) {
					// alle  Rumpfatome fuer das Atom abgearbeitet
					// Einf�gen des Atoms in Ergebnisse
					// inserted = hrelation.Insert(t);
					if (t == hrelation.Insert(t)) {
						t = (Atom)addhrel.Insert(t);
					}
				}
				else {
					// Downpropagierung ueber das Rumpfatom b
					down(t,b);
					if (bodies[b].builtin) repeat = true;
				}
			}
		}
		return repeat;
	}





	public void  DynamicFiltering() {
		// Dynamisches Filtern mit Sidewayspropagierung 
		boolean stop = false, change = false, repeat = false;
		int i,j;
		//System.out.print("Eval Rule: "); System.out.println(this.no);
		// Einbringen der Konstanten der Kopfatome
		for (i = 0; i < anzheads; i++) {
			if (heads[i].adddown.anztuples > 0) {
				drelation.Extend(heads[i].adddown,heads[i].vars2);
				heads[i].adddown.Clear();
			}
		}

		// Verteilen der Atome auf die Ruempfe
		if (drelation.anztuples > 0) {
			distribute(drelation);
			drelation.Clear();	
		}

		do {
			repeat = false;
			// Weiterverteilen der nach oben gekommenen Rumpfatome, Auswertung von Builtin-Atomen 
			for (j = 0; j < anzbodies; j++) {
				if ((bodies[j].adddown.anztuples>0) && (bodies[j].builtin)) {
					// Auswertung von Builtin-Atomen
					((BuiltinBody)bodies[j]).Eval();
				}
				if (!bodies[j].neg) { // positives Rumpfatom
					if (bodies[j].addup.anztuples > 0) {
						drelation.MatchJoin(bodies[j].hrelation,bodies[j].vars2, bodies[j].addup,bodies[j].addup.matchindex,bodies[j].vars2);
						if (drelation.anztuples > 0) {
							repeat = distribute(drelation) || repeat;
							drelation.Clear();
						}
						bodies[j].addup.Clear();
					}
					if (bodies[j].addhrel.anztuples > 0) {
						drelation.MatchJoin(bodies[j].addhrel,bodies[j].vars2, bodies[j].up,bodies[j].up.matchindex,bodies[j].vars2);
						if (drelation.anztuples > 0) {
							repeat = distribute(drelation) || repeat;
							drelation.Clear();
						}
						bodies[j].addhrel.Clear();
					}

				}	
				else { // negatives Rumpfatom
				    if (bodies[j].up.anztuples > 0) {
					//if (bodies[j].addup.anztuples > 0) {
						//bodies[j].negrelation.MatchJoin(bodies[j].hrelation,bodies[j].vars2, bodies[j].addup,bodies[j].addup.matchindex,bodies[j].vars2);
						//bodies[j].negrelation.MatchJoin(bodies[j].hrelation,bodies[j].vars2, bodies[j].up,bodies[j].up.matchindex,bodies[j].vars2);
						//bodies[j].hrelation.Negation1(bodies[j].vars2,bodies[j].negrelation,bodies[j].vars2);
						bodies[j].hrelation.Negation1(bodies[j].vars2,bodies[j].up,bodies[j].up.matchindex);
						// bodies[j].hrelation.Negation1(bodies[j].vars2,bodies[j].addup,bodies[j].addup.matchindex);
						bodies[j].addup.Clear();
						bodies[j].addhrel.Clear();
					}
					if ((!bodies[j].delayed) && (bodies[j].hrelation.anztuples > 0)) {
						repeat = distribute(bodies[j].hrelation) || repeat;
						bodies[j].hrelation.Clear();
					}
				}
			}
		} while (repeat);

		// Einsetzen der Ergebnisrelation in Kopfatome
		if (addhrel.anztuples > 0) {
			for(i = 0; i < anzheads; i++) {
				heads[i].up.Substitute(heads[i],addhrel,addhrel.matchindex);
				heads[i].addup.UnionSelected(heads[i].up);
				change = (heads[i].addup.anztuples > 0) || change;
			}
			addhrel.Clear();
		}
	}


	private boolean distributeWF(Atoms R) {
		// Verteilung der Atome in R auf die Rumpfatome
		int i,j;
		int b = -1;			 // betrachtetes Rumpfatom
		double anz, anz1;	
		int ground;
		long lastvars = -1;  // Anzahl uebereinstimmend belegter Terme bei der letzten Auswahl
		long lastmarks = -1;
		boolean inserted, repeat = false;
		Atom t;
		// Verteilen auf Rumpfatome
		if (R.anztuples > 0) {
			R.enum1.R1 = R;
			for (t = (Atom)R.enum1.Enum(); t != null; t = (Atom)R.enum1.EnumNext()) {
				// Auswahl des positiven Rumpfatoms
				if ((t.vars != lastvars) || (t.mark != lastmarks)) {
					b = -1; anz = -1;
					for(i = 0; i < anzpos; i++) {
						if (!(t.isMarked(i))) {
							if (bodies[i].anzvars > 0) {
								ground = 0;
								for(j = 0; bodies[i].vars2[j] != -1; j++) {
									if (t.terms[bodies[i].vars2[j]].ground)
										ground++;
								}
								// Verh�ltnis von instantiierten Variablen zu nicht-instantiierten
								anz1 = (double)ground/(double)bodies[i].anzvars; 
							}
							else
								anz1 = 0;
							if (anz1 > anz) {
								if (bodies[i].builtin) {
									 if (((BuiltinBody)bodies[i]).Evaluable(t)) {
										anz = anz1; b = i;
									}
								}
								else {
									anz = anz1; b = i;
								}
							}
						}
					}
				}
				lastvars = t.vars; lastmarks = t.mark;
				if (b == -1) {
					// alle  positiven Rumpfatome fuer das Atom abgearbeitet
					// Einf�gen des Atoms in Ergebnisse und bei den neg. Rumpftermen
					// inserted = hrelation.Insert(t);
					if (t == hrelation.Insert(t)) {
						t = (Atom)addhrel.Insert(t);
					}
					for (j = anzpos; j < anzbodies; j++)
						down(t,j);
				}
				else {
					// Downpropagierung ueber das Rumpfatom b
					down(t,b);
					if (bodies[b].builtin) repeat = true;
				}
			}
		}
		return repeat;
	}

	public void  DynamicFilteringWF() {
		// Dynamisches Filtern mit Sidewayspropagierung 
		boolean stop = false, change = false, repeat = false;; 
		int i,j;

		// System.out.print("Regel: "); System.out.println(no);
		//System.out.println("hrelation davor:");
		//hrelation.print();
		//if ((no == 4) || (no == 5)) hrelation.checkpaths();
		
		// Einbringen der Konstanten der Kopfatome
		for (i = 0; i < anzheads; i++) {
			if (heads[i].adddown.anztuples > 0) {
				drelation.Extend(heads[i].adddown,heads[i].vars2);
				heads[i].adddown.Clear();
			}
		}
		// Verteilen der Atome auf die Ruempfe
		if (drelation.anztuples > 0) {
			distributeWF(drelation);
			drelation.Clear();	
		}
		do {
			repeat = false;
			// Weiterverteilen der nach oben gekommenen Rumpfatome, Auswertung von Builtin-Atomen 
			for (j = 0; j < anzbodies; j++) {
				if ((bodies[j].adddown.anztuples>0) && (bodies[j].builtin)) {
					// Auswertung von Builtin-Atomen
					((BuiltinBody)bodies[j]).Eval();
				}
				if (!bodies[j].neg) { // positives Rumpfatom
					if (bodies[j].addup.anztuples > 0) {
						drelation.MatchJoin(bodies[j].hrelation,bodies[j].vars2, bodies[j].addup,bodies[j].addup.matchindex,bodies[j].vars2);
						if (drelation.anztuples > 0) {
							repeat = distributeWF(drelation) || repeat;
							drelation.Clear();
						}
						bodies[j].addup.Clear();
					}
					if (bodies[j].addhrel.anztuples > 0) {
						drelation.MatchJoin(bodies[j].addhrel,bodies[j].vars2, bodies[j].up,bodies[j].up.matchindex,bodies[j].vars2);
						if (drelation.anztuples > 0) {
							repeat = distributeWF(drelation) || repeat;
							drelation.Clear();
						}
						bodies[j].addhrel.Clear();
					}

				}	
				else { // negatives Rumpfatom
					if (bodies[j].addup.anztuples > 0) {
						bodies[j].hrelation.Negation2(bodies[j].vars2,bodies[j].addup,bodies[j].addup.matchindex);
						bodies[j].addup.Clear();
					}
					if (bodies[j].addhrel.anztuples > 0) {
						bodies[j].addhrel.Negation2(bodies[j].vars2,bodies[j].up,bodies[j].up.matchindex);
						bodies[j].addhrel.Clear();
					}
				}
			}
		} while (repeat);
		// Einsetzen der Ergebnisrelation in Kopfatome
		if (addhrel.anztuples > 0) {
			for(i = 0; i < anzheads; i++) {
				heads[i].up.Substitute(heads[i],addhrel,addhrel.matchindex);
				heads[i].addup.UnionSelected(heads[i].up);
				change = (heads[i].addup.anztuples > 0) || change;
				// heads[i].addup.print(); System.out.println();
			}
			addhrel.Clear();
		}
	}

}
