/*

Name: DBInterface.java

Version: 1.0

Purpose:

History:

*/

package edu.unika.aifb.inference;

import java.io.*;


public interface DBInterface {


	public void write(PrintStream p) throws IOException;
		// Schreibt die Faktenmenge im internen Format auf p heraus

	public void read(RandomAccessFile file) throws IOException;
		// liest eine Menge von Fakten im internen Format aus der Datei file

			
	public void AddFact(int sym, GroundAtom fact);
		// F�gt ein einzelnes Faktum  hinzu


	public void DeleteFact(int sym, GroundAtom fact);
		// L�scht ein  Faktum

	public Atoms GetFacts(int praedikatsymbol, Atoms filterterme);
		// Das ist die wesentliche Funktion zum Zugriff auf Fakten. 
		// Es werden auf Fakten mit dem Pr�dikatsymbol praedikatsymbol zugegriffen. 
		// Der Zugriff wird mit Hilfe einer Menge von Filtertermen filterterme eingeschr�nkt. 
		// Ein Filterterm ist ein Tupel von Termen, die Variablen enthalten k�nnen. 
		// Z.B. ist f(X,a),"hallo",X ein solcher Filterterm. 
		// Das Ergebnis des Aufrufs ist eine Menge von Fakten, 
		// die zu diesen Filtertermen "passen" (die mit einem der Filterterme matchen). 

		// Z.B. enthalte die entsprechende Tabelle der DB die Zeilen:
		// 5, "hallo",8
		// f(7,a), "hallo",7
		// f(ab,a), "hallo",ab
		// f(7,a), "hallo",h
		// f(ab,a), "huhu",ab

		// Die filterterme bestehen nur aus dem einen Filterterm: f(X,a),"hallo",X. 
		// Dann ist das Ergebnis des Aufrufs die folgende Menge von Fakten:
		// f(7,a), "hallo", 7
		// f(ab,a), "hallo", ab

	public TermSet GetTerms(int praedikatsymbol, int i);
		// Dies wird f�r Optimierungszwecke gebraucht. Liefert die Menge von Termen, 
		// die am i-ten Argument aller Fakten des Pr�dikatsymbols praedikatsymbol auftreten.
}
