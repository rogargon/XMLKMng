/*

Name: RuleSet.java

Version: 1.0

Purpose:

History:

*/

package edu.unika.aifb.inference;

import java.util.Date;
import java.util.Random;
import java.lang.Long;
import java.io.*;
import java.util.*;
import java.net.*;


class Filter {
	// Kante des Systemgraphen, verbindet ein Bodyatom mit einem Headatom
	Filter nexthead = null;		// n�chstes Kopfatom, das mit dem  Rumpfatom  body verbunden ist
	Filter lasthead = null;		// doppelte Verzeigerung
	Filter nextbody = null;  	// n�chstes Rumpfatom, das mit dem  Kopfatom head verbunden ist
	Filter lastbody = null;		// doppelte Verzeigerung
	Head head = null;		// Referenz auf Kopfatom
	Body body = null;		// Referenz auf Rumpfatom
	Atoms filter = null;		// Filteratome der Kante
	boolean on = true;          	// Filter an oder aus
	Atoms addfilter = null;		// inkrementelle Bestimmung von Filtern
	boolean delayed = false;	// Negation
	TermSet termsets[];		// Terme, die an den einzelnen Stellen auftreten k�nnen	

	public Filter(Head h, Body b) {
		// Neuanlegen einer Verbindung zwischen Kopfatom h und Rumpfatom b
		head = h; body = b;
		nextbody = h.filter; 
		if (h.filter != null) h.filter.lastbody = this;
		h.filter = this;
		nexthead = b.filter;
		if (b.filter != null) b.filter.lasthead = this;
		b.filter = this;
		termsets = new TermSet[b.terms.length];
	}

	public void Unlink() {
		// Verbindung zwischen Kopf- und Rumpfatom loesen
		if (head.filter == this) head.filter = nextbody;
		if (body.filter == this) body.filter = nexthead;
		if (lastbody != null) lastbody.nextbody = nextbody;
		if (nextbody != null) nextbody.lastbody = lastbody;	
		if (lasthead != null) lasthead.nexthead = nexthead;
		if (nexthead != null) nexthead.lasthead = lasthead;
	}
	
	boolean Down(boolean optimized) {
		// Propagierung von Termen durch den Filter nach unten
		int oldanz, oldanz1;
		Atoms A,B;
		Atom t;
		boolean changedown = false;
		int i;
		oldanz = filter.anztuples;
		B = body.adddown;
		if (on) {
			if (body.adddown.anztuples > 0) {
				if (optimized) {
    			    		B = new Atoms(body.adddown.stellen);
    			    		B.Union(body.adddown);
					// L�schen von Filtertermen
					B.Select(termsets);
					B.DeleteSelected();
				}

				// Filtergeneralisierung
				A = new Atoms(filter.stellen); 
				A.Generalize(filter,B);
				filter.DeleteSelected();
				B.DeleteSelected();
				B.Union(A);

/*
				// Filtersubsumption
				if (B.anztuples > 1)
					B.Subsumption(B);
				filter.Subsumption(B);
				B.Subsumption(filter);
*/	
			}
		}
		if (!head.rule.facts) {
			// Unifikation mit Kopfatom der Regel
			head.down.Unify(head,B);
			changedown = (head.down.tuples2 != null);
			head.adddown.UnionSelected(head.down);
			if (on) {
				// Ergaenzen des Filters
				filter.UnionSelected(B);
				addfilter.UnionSelected(filter); 
				changedown = (addfilter.anztuples > 0) || changedown;
			}
		}
		else {
			head.down.Union(B);
			head.adddown.UnionSelected(head.down);
			if (on) {
				// Einfuegen in Filter fuer Fakten (keine Unifikation noetig)
				filter.Union(B);
				addfilter.UnionSelected(filter);
				changedown = addfilter.anztuples > 0;
			}
		}
		if (changedown) {
			if (body.neg && !delayed) {
				delayed = true;
				body.delays++;
				body.delayed = true;
			}
		}
		return changedown;
	}
	
	boolean Up() {
		boolean changeup = false;
		if (on) {
			if (filter.anztuples > 0) {
				if (addfilter.anztuples > 0) {
					body.up.Filtering(body,addfilter,head.up);
	 				changeup = (body.up.tuples2 != null);
					body.addup.UnionSelected(body.up);
	 				addfilter.Clear();
	 			}
		 		if (head.addup.anztuples > 0) {
					body.up.Filtering(body,filter,head.addup);
	 				changeup = (body.up.tuples2 != null) || changeup;
					body.addup.UnionSelected(body.up);
		 		}					 		
	 		}
	 	}
	 	else {
	 		if (head.addup.anztuples > 0) {
				body.up.Match(body,head.addup);
 				changeup = (body.up.tuples2 != null);
				body.addup.UnionSelected(body.up);
	 		}
			body.up.Match(body,head.up);
 			changeup = (body.up.tuples2 != null);
			body.addup.UnionSelected(body.up);
		}
		return changeup;
	}

	boolean Up(int durchlauf) {
		boolean changeup = false;
		if (on) {
			if (filter.anztuples > 0) {
				if (addfilter.anztuples > 0) {
					if (!body.neg || (head.rule.facts && (durchlauf == 0))) {
						body.up.Filtering(body,addfilter,head.up);
	 					changeup = (body.up.tuples2 != null);
						body.addup.UnionSelected(body.up);
	 					addfilter.Clear();
	 				}
	 				else {
	 					body.up1.Filtering(body,addfilter,head.up);
	 					changeup = (body.up1.tuples2 != null);
	 					addfilter.Clear();
					}
	 			}
		 		if (head.addup.anztuples > 0) {
		 			if (!body.neg || (head.rule.facts && (durchlauf == 0))) {
						body.up.Filtering(body,filter,head.addup);
	 					changeup = (body.up.tuples2 != null) || changeup;
						body.addup.UnionSelected(body.up);
					}
					else {
						body.up1.Filtering(body,filter,head.addup);
						changeup = (body.up1.tuples2 != null) || changeup;
					}
		 		}					 		
	 		}
	 	}
	 	else {
	 		if (!head.rule.facts) {
		 		if (head.addup.anztuples > 0) {
		 			if (!body.neg || (head.rule.facts && (durchlauf == 0))) {
						body.up.Match(body,head.addup);
	 					changeup = (body.up.tuples2 != null);
						body.addup.UnionSelected(body.up);
					}
					else {
						body.up1.Match(body,head.addup);
	 					changeup = (body.up.tuples2 != null);
					}
		 		}	
		 	}
		 	else {
		 		if (!body.neg || (head.rule.facts && (durchlauf == 0))) {
					body.up.Match(body,head.up);
	 				changeup = (body.up.tuples2 != null);
					body.addup.UnionSelected(body.up);
				}
				else {
					body.up1.Match(body,head.up);
	 				changeup = (body.up1.tuples2 != null);
				}
		 	}				 		
		}
		return changeup;
	}

	
	boolean reduceDelay() {
		if (delayed) {
			delayed = false;
			body.delays--;
			if (body.delays == 0) {
				body.delayed = false;
				return true;
			}
		}
		return false;
	}
}


	
public class RuleSet {
	Rule rules = null;		// Zeiger auf Liste von Regeln
	int anzrules = 0;		// Anzahl von Regeln
	int maxpreds = 0;		// maximales Pr�dikatsymbol
	Rule facts[] = null; 		// Feld von Regeln f�r Fakten
	Head heads[] = null;		// Feld von Kopfatomen
	Body bodies[] = null;		// Feld von Rumpfatomen
	int increment = 200;    	// dynamische Erweiterung der Felder facts, heads, bodies um incr
	Rule strata[] = null;   	// Anordnung der Regeln nach strata
	Rule evalstrata[]=null; 	// Strata, die noch evaluiert werden m�ssen
	Rule queries = null;		// Liste von Queries
	int maxstratum = 0;		// maximales Stratum
	int startstratum = 0;   	// Stratum an dem die Top-Down Evaluierung beginnt
	int evalmethod = 1;		// Gibt die Evaluierungsmethode an: 0: Naiv, 1: Dynamisch, 2: wellfounded dynamisch
	Rule evalqueue = null;		// Warteschlange zur Evaluierung bei wellfounded
	Rule lastqueue = null;  	// letzter in Warteschlange
	boolean optimized = false;	// Terme von unten nach oben durchpropagiert
	boolean writeonly = false;  	// Flag, dass nur eine Datei geschrieben wird
	PrintStream ffacts, frules;   	// Dateien, in die geschrieben wird
	static SParser spars = null;	// Parser zum Einlesen des internen Formats
	DB db;				// Datenbank in der die Fakten liegen

	public void read(RandomAccessFile file) throws IOException {
	    String s = "";

	    if (spars == null) spars = new SParser();
	    while((s = file.readLine())!= null) {
		try {
			spars.decode(this, s+"\n");
		}
		catch (JanParseError1 p) {
			System.out.println(p.getMessage());
		}
  
	    } 
	}
	
	public void writeonly(PrintStream f) {
		writeonly = true;
		ffacts = f;
		frules = f;
	}

	public void writeonly(PrintStream ff, PrintStream fr) {
		writeonly = true;
		ffacts = ff;
		frules = fr;
	}

	synchronized void insertqueue(Rule r) {
		if (!r.toeval) {
			if (evalqueue == null) {
				evalqueue = r; lastqueue = r;
			}
			else {
				lastqueue.next3 = r;
				lastqueue = r;
			}
			r.toeval = true;
			r.next3 = null;
		}
	}

	synchronized Rule getqueue() {
		Rule r;
		r = evalqueue;
		if (r != null) {
			evalqueue = r.next3; r.toeval = false;
		}
		return r;
	}
		
	public RuleSet() {
		// Konstruktor f�r Regelmenge, 
		// maxp gibt das gr��te Pr�dikatsymbol an, um die Felder anlegen zu k�nnen
		maxpreds = increment-1;
		facts = new Rule[increment];
		heads = new Head[increment];
		bodies = new Body[increment];
		queries = null;
		db = new DB();
	}
	
	private void extendRuleSet(int index) {
		// erweitert die Felder factsext, factsint, bodies und heads, so dass sie auch den Index 'index'
		// enthalten
		int len, i;
		Rule newfacts[];
		Body newbodies[];
		Head newheads[];
		len = maxpreds+1;
		if (maxpreds < index) {
			while (len < index + 1) len +=increment;
			newfacts = new Rule[len];
			newbodies = new Body[len];
			newheads = new Head[len];
			for (i = 0; i <= maxpreds; i++) {
				newfacts[i] = facts[i];
				newbodies[i] = bodies[i];
				newheads[i] = heads[i];
				
			}
			facts = newfacts;
			bodies = newbodies;
			heads = newheads;
		}
		maxpreds = len-1;
	}
			
		
	
	public void EvaluationMethod(int method) {
		// Umschalten der Evaluierungsmethoden
		this.evalmethod = method;
	}

	public void ClearRuleSet() {
		// L�sche alle Zwischenergebnisse der Evaluierung
		// Query q;
		Rule r;
		Filter c;
		int i;
		for(r = rules; r != null; r = r.next1) {
			if (!r.facts)
				r.ClearRule();
			for(i = 0; i < r.anzbodies; i++)
				for(c = r.bodies[i].filter; c != null; c = c.nexthead) {
					c.filter.Clear();
					c.addfilter.Clear();
				}
			for(i = 0; i < r.anzheads; i++)
				for(c = r.heads[i].filter; c != null; c = c.nextbody) {
					c.filter.Clear();
					c.addfilter.Clear();
				}
		}
			
	}
	
	public void ClearRuleSet1() {
		// L�sche alle Zwischenergebnisse der Evaluierung
		// Query q;
		Rule r;
		Filter c;
		int i;
		for(r = rules; r != null; r = r.next1) {
			if (!r.facts)
				r.ClearRule1();
			for(i = 0; i < r.anzbodies; i++)
				for(c = r.bodies[i].filter; c != null; c = c.nexthead) {
					c.filter.Clear();
					c.addfilter.Clear();
				}
			for(i = 0; i < r.anzheads; i++)
				for(c = r.heads[i].filter; c != null; c = c.nextbody) {
					c.filter.Clear();
					c.addfilter.Clear();
				}
		}
			
	}

	public void write(PrintStream p) throws IOException {
		Rule r;
		int i;
		db.write(p);
		for(r = rules; r != null; r = r.next1) {
			if (!r.facts) {
				r.internalize(p);
				p.println();
			}
		}
	}



	protected void checksym(int sym) {
		// neues Pr�dikatsymbol
		// falls noetig RuleSet erweitern
		if (sym > maxpreds)
			extendRuleSet(sym);
	}
	
	
	protected void addFactRule(int sym, int len) {
		Body b;
		Filter c;
		Head f;
		Head heads[];
		Rule r;
		Term terms[];
		int i;
		// falls noetig RuleSet erweitern
		checksym(sym);
		if (facts[sym] == null) {
			// noch keine Faktenregel dieses Pr�dikatsymbols vorhanden
			// Erzeugen einer neuen Regel dieses Symbols
			terms = new Term[len];
			for(i = 0; i < len; i++)
			    terms[i] = new Variable(i);
			f = new Head(sym,terms);
			// Erzeugung der Regel ohne Rumpf
			heads = new Head[1]; 
			heads[0] = f;
			r = new Rule(heads,null);
			addRule(r);
			r.facts = true;
			f.up = new Atoms(len);
			f.addup = new Atoms(len);
			facts[sym] = r;
		}	
	}	
	
			

	void DeleteFact(int sym, GroundAtom fact) {
		// L�scht ein  Faktum vom RuleSet 
		db.DeleteFact(sym,fact);
	}


	public void AddFact(int sym, GroundAtom fact) {
		// F�gt ein einzelnes Faktum zu den externen Fakten hinzu
		boolean inserted;
		Rule r;
		int i;
		if (writeonly) {
			fact.internalize(ffacts,sym);
			ffacts.println("");
		}
		else {
			// Einf�gen des Faktums in die Datenbank
			db.AddFact(sym,fact);
		}
	}
	

	
	void connectToHeads(Rule r) {
		// die  Rumpfatome der Regel r mit allen passenden Kopfatomen 
		// aller Regeln verbinden
		int i;
		Head h;
		Filter c;
		boolean unifiable;
		for (i = 0; i < r.anzbodies; i++) {
			for (h = heads[r.bodies[i].symbol]; h != null; h = (Head)h.next) {
				if (!h.rule.facts) {
					unifiable = h.Unify(r.bodies[i]);
					h.ClearVariables(); r.bodies[i].ClearVariables();
				}
				else
					unifiable = true;
				if (unifiable) {
					c = new Filter(h,r.bodies[i]);
					c.filter = new Atoms(r.bodies[i].terms.length);
					c.addfilter = new Atoms(r.bodies[i].terms.length);
				}
			}
		} 
	}
		
	void disconnectFromHeads(Rule r) {
		// Verbindungen zwischen  Rumpfatomen von r und 
		// den Kopfatomen aller Regeln l�sen
		int i;
		Head h;
		Filter c,c1 = null;
		for (i = 0; i < r.anzbodies; i++) {
			for (c = r.bodies[i].filter; c != null; c = c1) {
				c1 = c.nexthead;
				c.Unlink();
			}
		}
	}
	
	void connectToBodies(Rule r) {
		// Kopfatome der Regel r mit passenden Rumpfatomen 
		// aller Regeln verbinden
		int i;
		Body b;
		boolean unifiable;
		Filter c;
		i = 0;
		for (i = 0; i < r.anzheads; i++) {
			for (b = bodies[r.heads[i].symbol]; b != null; b = (Body)b.next) {
				unifiable = r.heads[i].Unify(b);
				r.heads[i].ClearVariables(); b.ClearVariables();
				if (unifiable) {
					c = new Filter(r.heads[i],b);
					// connect(c,r.heads[i],b);
					c.filter = new Atoms(b.terms.length);
					c.addfilter = new Atoms(b.terms.length);
				}
			}
		}
	}
	
	void disconnectFromBodies(Rule r) {
		// Verbindungen zwischen  Kopfatomen von r und den Rumpfatomen aller Regeln l�sen
		int i;
		Head h;
		Filter c,c1 = null;
		for (i = 0; i < r.anzheads; i++) {
			for (c = r.heads[i].filter; c != null; c = c1) {
				c1 = c.nextbody;
				c.Unlink();
			}
		}
	}


	public void AddRule(Rule r) {
		Variable v;
		int i,j,p;
		boolean inserted, unifiable;
		Filter c;
		Atom a;
				
		if ((r.anzbodies == 0) && (r.anzvars == 0)) {
			for (i = 0; i < r.anzheads; i++) {
				AddFact(r.heads[i].symbol,new GroundAtom(r.heads[i].terms));
				// r.heads[i].print(); System.out.println(".");
			}
		} 
		else {
			if (writeonly) {
				r.internalize(frules);
				frules.println();
			}
			else {
				if (r.anzheads == 0) {
					// Query
					r.next4 = queries;
					queries = r;
				} 			
				addRule(r);
				// r.print();
			}
		}
	} 
	
		 
	public void addRule(Rule r) {
		Variable v;
		int i,j,p;
		boolean inserted, unifiable;
		Filter c;
		Atom a;
		
		r.next2 = null; // Verzeigerung f�r Straten
		
		// Pr�dikatsymbole der Regel in RuleSet eintragen
		for (i = 0; i < r.anzbodies; i++)
			checksym(r.bodies[i].symbol);
		for (i = 0; i < r.anzheads; i++)
			checksym(r.heads[i].symbol);

		// Eintragen der Regel in die Liste aller Regeln
		r.next1 = rules;
		if (rules != null) rules.last1 = r;
		rules = r;
		anzrules++;
		r.no = anzrules;

		// f�r alle Rumpfatome Faktenregeln einf�gen
		for(i = 0; i < r.anzbodies; i++)
			addFactRule(r.bodies[i].symbol,r.bodies[i].terms.length);
		
		// Regel in Systemgraph einf�gen
		// alle K�pfe mit den Rumpfatomen der Regel verbinden	
		connectToBodies(r);
		// alle R�mpfe mit den Kopfatomen der Regel verbinden
		connectToHeads(r);
		// bei rekursiver Regel die entsprechenden Rumpfatome mit den Kopfatomen verbinden	
		for (i = 0; i < r.anzbodies; i++) {
			for (j = 0; j < r.anzheads; j++) {
				if (r.bodies[i].symbol == r.heads[j].symbol) {
					unifiable = r.heads[j].Unify(r.bodies[i]);
					r.heads[j].ClearVariables(); r.bodies[i].ClearVariables();
					if (unifiable) {
						c = new Filter(r.heads[j],r.bodies[i]);
						//connect(c,r.heads[j],r.bodies[i]);
						c.filter = new Atoms(r.bodies[i].terms.length);
						c.addfilter = new Atoms(r.bodies[i].terms.length);
					}
				}
			}
		} 
		// Eintragen der Rumpfatome in die Liste aller Rumpfatome
		for (i = 0; i < r.anzbodies; i++) {
			r.bodies[i].next = bodies[r.bodies[i].symbol];
			if (bodies[r.bodies[i].symbol] != null)
				bodies[r.bodies[i].symbol].last = r.bodies[i];
			bodies[r.bodies[i].symbol] = r.bodies[i];
		}
		// Eintragen der Kopfatome in die Liste aller Kopfatome
		for (i = 0; i < r.anzheads; i++) {
			r.heads[i].next = heads[r.heads[i].symbol];
			if (heads[r.heads[i].symbol] != null)
				heads[r.heads[i].symbol].last = r.heads[i];
			heads[r.heads[i].symbol] = r.heads[i];
		}
	}
	
	public void DeleteRule(Rule r) {
		Variable v;
		int i,j,p;
		boolean inserted, unifiable;
		Filter c;
		Atom a;
		Body b;
		Head h;
		Rule r1;

		if ((r.anzbodies == 0) && (r.anzvars == 0)) {
			for (i = 0; i < r.anzheads; i++) {
				DeleteFact(r.heads[i].symbol,r.heads[i]);
			}
		} 		
		else {
			if (r.anzheads == 0) {
				// Query l�schen
				if (queries == r) {
					queries = r.next4;
					if (r.next4 != null)
						r.next4.last4 = null;
				}
				else {
					r.last4.next4 = r.next4;
					if (r.next4 != null)
						r.next4.last4 = r.last4;
				}
			} 
			// L�schen aus der Liste aller Regeln
			if (rules == r) {
				rules = r.next1;
				if (rules != null)
					rules.last1 = null;
			}
			else {
				r.last1.next1 = r.next1;
				if (r.next1 != null)
					r.next1.last1 = r.last1;
			}
			anzrules--;

			// Regel aus  Systemgraph l�schen
			// Verbindungen der K�pfe mit den Rumpfatomen l�sen
			disconnectFromBodies(r);
			// Verbindungen der R�mpfe mit den Kopfatomen der Regeln l�sen
			disconnectFromHeads(r);

			// L�schen der Rumpfatome aus der Liste aller Rumpfatome
			for (i = 0; i < r.anzbodies; i++) {
				b = r.bodies[i];
				if (bodies[r.bodies[i].symbol] == b) {
					bodies[r.bodies[i].symbol] = (Body)b.next;
					if (b.next != null)
						b.next.last = null;
				}
				else {
					b.last.next = b.next;
					if (b.next != null)
						b.next.last = b.last;
				}
			}

		}

		// L�schen der Kopfatome aus der Liste aller Kopfatome
		for (i = 0; i < r.anzheads; i++) {
			h = r.heads[i];
			if (heads[r.heads[i].symbol] == h) {
				heads[r.heads[i].symbol] = (Head)h.next;
				if (h.next != null)
					h.next.last = null;
			}
			else {
				h.last.next = h.next;
				if (h.next != null)
					h.next.last = h.last;
			}
		}
		// Regel aus Stratum l�schen
		if (r.next2 != null) {
			if (strata[r.stratum] == r) {
				strata[r.stratum] = r.next2;
				if (r.next2 != null)
					r.next2.last2 = null;
			}
			else {
				r.last2.next2 = r.next2;
				if (r.next2 != null)
					r.next2.last2 = r.last2;
			}
			r.next2 = null;
			r.stratum = 0;
		}

	}




	public Rule NextQuery(Rule query) {
		// gibt die n�chste Query zur�ck, die erste query wird 
		// durch query=null abgefragt
		if (query == null) return queries;
		else return query.next4;
	}


	public void EvalQueries() {
		// Evaluiert alle mit AddQuery eingefuegten Queries gemeinsam
		Rule q;
		Atom a;
		int i;
		boolean inserted,change;
		switch (evalmethod) {
		 	case 0:
				NaiveEval();
				break;
			case 1: 
				for(q = queries; q != null; q = q.next4) {
					// dynamische Evaluierung
					// Starttupel einfuegen
					a = new Atom(q.anzvars);
					for (i = 0; i < q.anzvars; i++)
						a.terms[i] = new Variable(i);
					a.Variables();
					a = (Atom)q.drelation.Insert(a);
					// F�ge Query in das entsprechende Stratum ein
					q.next3 = evalstrata[q.stratum];
					evalstrata[q.stratum] = q;
					if (startstratum < q.stratum) 
						startstratum = q.stratum;				
				}
				// SwitchFilters();
				DynamicFiltering();
		 		break;
			case 2:
				WellFoundedAF();
				break;
			case 3:
				for(q = queries; q != null; q = q.next4) {
					a = new Atom(q.anzvars);
					for (i = 0; i < q.anzvars; i++)
						a.terms[i] = new Variable(i);
					a.Variables();
					a = (Atom)q.drelation.Insert(a);
					insertqueue(q);
				}
				Filtering();
				break;
		}
	}
	
	public Substitution Substitution(Rule q) {
		// gibt die durch die Evaluierung erzeugte Variablenssubstitution fuer die query aus
		Substitution subs;
		if (evalmethod == 0) {
			subs = new Substitution(q.bodies[q.anzbodies-1].bindex,q.bodies[q.anzbodies-1].brelation.stellen);
			subs.Union(q.bodies[q.anzbodies-1].brelation);
		}
		else {
			subs = new Substitution(q.hrelation.matchindex,q.hrelation.stellen);
			subs.Union(q.hrelation);
		} 
		return subs;
	}
		
	public Atoms Result(Rule q, int body) {
		// Ausgabe des Evaluierungsergebnisses als Menge von Grundatomen von body
		Atoms r = new Atoms(q.bodies[body].terms.length);
		if (evalmethod == 0) 
			r.Substitute(q.bodies[body],q.bodies[q.anzbodies-1].brelation,q.bodies[q.anzbodies-1].bindex);	
		else 
			r.Substitute(q.bodies[body],q.hrelation,q.hrelation.matchindex);
		return r;
	}				
			
	
	boolean stratum(Rule r) {
		// bestimmt das Stratum einer Regel in Abh�ngigkeit der Straten der Rumpfatome
		Filter c;
		int i;
		int strat;
		boolean change = false;
		for (i = 0; i < r.anzbodies; i++) {
			for(c = r.bodies[i].filter; c != null; c = c.nexthead) {
				strat = c.head.rule.stratum;
				if (r.bodies[i].neg)
					strat = strat + 1;
				if (r.stratum < strat) {
					r.stratum = strat;
					change = true;
				}
			}
		}
		return change;
	}
		
	public boolean Stratify() {
		// Bestimmen der Strata der einzelnen Regeln und 
		// Umsortierung der Regeln nach den Strata
		// Algorithmus nach Ullmann
		Rule r;
		Filter c;
		int i;
		boolean change = true;
		Rule regeln[];
		maxstratum = 0;
		int strat;
		while ((maxstratum <= anzrules) && change) {
			change = false;
			for(r = rules; r != null; r = r.next1) {
				change = stratum(r) || change;
				if (maxstratum < r.stratum)
					maxstratum = r.stratum;
			}
		}
		// Einf�gen der Regeln in das Feld strata gem�� oben 
		// berechneten Strata
		if (maxstratum <= anzrules) {
			strata = new Rule[maxstratum+2];
			evalstrata = new Rule[maxstratum+2];
			for(r = rules; r != null; r = r.next1) {
				r.next2 = strata[r.stratum];
				if (strata[r.stratum] != null)
					strata[r.stratum].last2 = r;
				strata[r.stratum] = r;
			}
			strata[maxstratum+1] = null;
			return true;
		}
		else return false;
	}	


	private void clearTermSets() {
		Rule r;
		int i,j;
		for (r = rules; r != null; r = r.next1) {
			for(i = 0; i < r.anzbodies; i++) {
				for(j = 0; j < r.bodies[i].termsets.length; j++) {
					r.bodies[i].termsets[j] = null;
					r.bodies[i].changets[j] = false;
					r.bodies[i].btermsets[j] = null;
					r.bodies[i].changebts[j] = false;
				}
			}
		}
	}

	public void ClearTermSets() {
		Rule r;
		int i,j;
		Filter c;
		for (r = rules; r != null; r = r.next1) {
			for(i = 0; i < r.anzbodies; i++) {
				for(j = 0; j < r.bodies[i].termsets.length; j++) {
					r.bodies[i].termsets[j] = null;
					r.bodies[i].changets[j] = false;
					r.bodies[i].btermsets[j] = null;
					r.bodies[i].changebts[i] = false;
				}
			}
			for( i = 0; i < r.anzheads; i++) {
				for(c = r.heads[i].filter; c != null; c = c.nextbody) {
					for(j = 0; j < c.termsets.length; j++) {
						c.termsets[j] = null; 
					}
				}
			}
		}
		optimized = false;
	}


	private void initTermSets() {
		Rule r;
		Filter c;
		int i,j,l;
		boolean open;
		for (r = rules; r != null; r = r.next1) {
			for (i = 0; i < r.anzheads; i++) {
				for (j = 0; j < r.heads[i].terms.length; j++) {
					if (r.heads[i].terms[j].ground) {
						for (c = r.heads[i].filter; c != null; c = c.nextbody) {
							c.termsets[j] = new TermSet();
							c.termsets[j].Insert(r.heads[i].terms[j]);
							if (c.body.terms[j] instanceof Variable) {
								l = ((Variable)c.body.terms[j]).symbol;
								if (c.body.termsets[l] == null) 
									c.body.termsets[l] = new TermSet();
								c.body.termsets[l].Insert(r.heads[i].terms[j]);
								c.body.changets[l] = true;
								insertqueue(c.body.rule);
							}
						}
					}
				}
			}
		}
	}


	 void optimize(boolean all) {
		Head h;
		int i,j,k,l;
		boolean ok;
		Filter c;
		Rule r;
		boolean change, changeup;
		int oldanz;
		if (optimized)
			ClearTermSets();
		initTermSets();
		if (all) {
			for (r = rules; r != null; r = r.next1) 
				if (r.facts) {
					for(i = 0; i < r.changebts.length; i++) {
						//r.btermsets[i] = null;
						// r.btermsets[i] = new TermSet();
						// r.heads[0].up.Terms(r.btermsets[i],i);
						r.btermsets[i] = db.GetTerms(r.heads[0].symbol,i);
						r.changebts[i] = (r.btermsets[i].anzterms > 0);
					}
					insertqueue(r);
				}
		}
		r = getqueue();	
		while (r != null) {
			change = r.TermEval();
			// Propagierung der Terme nach oben
			if (change) {
				for(i = 0; i < r.anzheads; i++) {
					for(c = r.heads[i].filter; c != null; c = c.nextbody) {
						for(j = 0; j < c.body.terms.length; j++) {
							if ((r.heads[i].terms[j] instanceof Variable) && (c.body.terms[j] instanceof Variable)) {
								k = ((Variable)r.heads[i].terms[j]).symbol;
								if (r.changebts[k]) {
								    changeup = false;
								    l = ((Variable)c.body.terms[j]).symbol;
								    if (c.body.termsets[l] == null)
									c.body.termsets[l] = new TermSet();
								    oldanz = c.body.termsets[l].anzterms;
								    c.body.termsets[l].Union(r.btermsets[k]);
					    			    changeup = (oldanz != c.body.termsets[l].anzterms);
								    if (changeup) {
									c.body.changets[l] = true;
								    	if (c.termsets[j] == null)
										c.termsets[j] = new TermSet();
					    			   	c.termsets[j].Union(r.btermsets[k]);
									insertqueue(c.body.rule);
								    }								}
								}
							}
	                                    	}	
				}
				for(i = 0; i < r.changebts.length; i++)
					r.changebts[i] = false;
			}
			r = getqueue();
		}


		for (r = rules; r != null; r = r.next1) 
			for(i = 0; i < r.btermsets.length; i++)
				if (r.btermsets[i] == null) {
					r.changebts[i] = true;
					insertqueue(r);
				}
		r = getqueue();	
		while (r != null) {
			for(i = 0; i < r.anzheads; i++) {
				for (j = 0; j < r.heads[i].terms.length; j++) {
					if (r.heads[i].terms[j] instanceof Variable) {
						k = ((Variable) r.heads[i].terms[j]).symbol;
						if (r.changebts[k]) {
							for (c = r.heads[i].filter; c != null; c = c.nextbody) {
								if (c.body.terms[j] instanceof Variable) {
									l = ((Variable) c.body.terms[j]).symbol;
									c.termsets[j] = null;
									if (c.body.rule.btermsets[l] != null) {
										c.body.rule.btermsets[l] = null;
										c.body.rule.changebts[l] = true;
										insertqueue(c.body.rule);
									}
								}
							}
							r.changebts[k] = false;
						}
					}
				}
			}
			r = getqueue();
		}

		clearTermSets();
		optimized = true;
	}

	public void Optimize1() {
		optimize(false);
	}

	public void Optimize2() {
		optimize(true);
	}

	public void DBAccessNaive(DB db, Rule r) {
		Atoms A,F;
		GroundAtom B;
		F = new Atoms(r.heads[0].terms.length);
		B = F.Insert(r.heads[0]);
		A = db.GetFacts(r.heads[0].symbol,F);
		if (A != null) {
			r.heads[0].up.Union(A);
		}
	}

	public void DBAccess(DB db, Rule r) {
		Atoms A;

		A = db.GetFacts(r.heads[0].symbol,r.heads[0].adddown);
		if (A != null) {
			//r.heads[0].up = A;
			r.heads[0].up.Union(A);
			r.heads[0].addup.UnionSelected(r.heads[0].up);
		} 
		r.heads[0].adddown.Clear();
	}

	public void XAccess(Rule r) {
		IClient xi;

		xi = new IClient(r,this);
	}


	public void NaiveEval() {
		// Naive Evaluierung der Regeln gemaess der Stratifizierung in strata
		Head h;
		int i;
		Filter c;
		// Query q;
		Rule r;
		boolean change;
		int stratum = 0;
		int oldanz;
		for(stratum= 0; stratum <= maxstratum; stratum++) {
			do {
				// Naive Evaluierung und Propagierung von Grundatomen nach oben
				change = false;
				for (r = strata[stratum]; r != null; r = r.next2) {
					if (!r.external) {
						if (!r.facts) 
							change = r.NaiveEval() || change;
						else
							DBAccessNaive(db,r);
						// Propagierung von Grundatomen nach oben
						for(i = 0; i < r.anzheads; i++) { 
							for(c = r.heads[i].filter; c != null; c = c.nextbody) {
								oldanz = c.body.up.anztuples;
								c.body.up.Match(c.body,c.head.up);
								change = change || (oldanz < c.body.up.anztuples);
							}
						}
					}
				}
			} while (change);
		}
	}


	private void insertstratum(Rule r) {
	    if (!r.toeval) {
	        r.next3 = evalstrata[r.stratum];
	        evalstrata[r.stratum] = r;
	        r.toeval = true;
	    }
	}


	void SwitchFilters() {
		Rule r;
		Filter c;
		int i;
		for(r=rules; r != null; r = r.next1) {
			if (!r.facts) {
				for(i = 0; i < r.anzheads; i++) {
					if ((c = r.heads[i].filter) != null) {
						if ((c.nextbody) == null) {
							// nur eine Regel angehaengt
							c.on = false;
							// System.out.println("Filter aus");
						}
						else
							for(; c != null; c = c.nextbody) 
								c.on = true;
							// System.out.println("Filter an");

					}
				}
			}
		}
	}	

	


	public void DynamicFiltering() {
		// Volles Dynamisches Filtern mit Sideways Passing 
		Filter f;
		Rule r;
		int i, j, oldanz;
		TermSet ts;
		boolean change = false, changedown = false, changeup = false;
		int stratum = 0, minstratum = maxstratum + 1;
		int dir = -1;
		
		stratum = startstratum;
		do {
			change = false;
			// Propagieren von Fakten nach oben, Konstanten nach unten, Sideways Passing
			r = evalstrata[stratum];
			if ((r != null) && !r.external) {
				evalstrata[stratum] = r.next3; r.next3 = null; r.toeval = false;
				// Propagierung der Konstanten und Evaluierung
				if (!r.facts) {
					r.DynamicFiltering();
					// Ergaenzen der Filter
					for(i = 0; i < r.anzbodies; i++) {
						if (r.bodies[i].adddown.anztuples > 0) {
							for(f = r.bodies[i].filter; f != null; f = f.nexthead) {
								changedown = f.Down(optimized);
								if (changedown) {
								    insertstratum(f.head.rule);
								    if (f.head.rule.stratum < minstratum)
								    	minstratum = f.head.rule.stratum;
								}
								change = change || changedown;
							}
							r.bodies[i].adddown.Clear();
						}
					}
				}
				else {
					if (r.heads[0].adddown.anztuples > 0) {
						DBAccess(db,r);
					}
				}
				// Propagierung der Evaluierungsergebnisse mit Filtern nach oben
				for(i = 0; i < r.anzheads; i++) {
					if (r.heads[i].up.anztuples > 0) {
						for(f = r.heads[i].filter; f != null; f = f.nextbody) {
							changeup = f.Up(); 
					 		if (((f.body.neg) && f.reduceDelay()) || changeup) {
							    insertstratum(f.body.rule);
							}
				 			change = change || changeup;						 		
						}
						r.heads[i].addup.Clear();				
					}
					else {
						for(f = r.heads[i].filter; f != null; f = f.nextbody) {
					 		if ((f.body.neg) && f.reduceDelay()) {
								insertstratum(f.body.rule);
							}
						}
					}
				} 
			}
			if (evalstrata[stratum] == null) {
				if ((dir == -1) && (stratum == minstratum)) {
					dir = 1;
					minstratum = maxstratum +1;
				}
				else if (stratum > minstratum)
					dir = -1;
				stratum += dir;
			}	
		} while ((stratum <= maxstratum) && (stratum >= 0));
	}



	public void FilteringAF(int durchlauf) {
		// Volles Dynamisches Filtern mit Sideways Passing 
		Filter f;
		Rule r;
		int i, j, oldanz;
		boolean change = false, changedown = false, changeup = false;
		
		do {
			change = false;
			// Propagieren von Fakten nach oben, Konstanten nach unten, Sideways Passing
			r = getqueue();
			// System.out.println(r.no);
			if ((r != null) && !r.external) {
				// Propagierung der Konstanten und Evaluierung
				if (!r.facts) {
					r.DynamicFiltering();
					// Ergaenzen der Filter
					for(i = 0; i < r.anzbodies; i++) {
						if (r.bodies[i].adddown.anztuples > 0) {
							for(f = r.bodies[i].filter; f != null; f = f.nexthead) {
								changedown = f.Down(optimized);
								if (changedown) {
								    insertqueue(f.head.rule);
								 	//System.out.print("insertdown: "); System.out.println(f.head.rule.no);	
								}
								change = change || changedown;
							}
							r.bodies[i].adddown.Clear();
						}
					}
				}
				else {
					if (r.heads[0].adddown.anztuples > 0) {
						DBAccess(db,r);
					}
				}
				
				// Propagierung der Evaluierungsergebnisse mit Filtern nach oben
				for(i = 0; i < r.anzheads; i++) {
					if (r.heads[i].up.anztuples > 0) {
						for(f = r.heads[i].filter; f != null; f = f.nextbody) {
							changeup = f.Up(durchlauf); 
					 		if (((f.body.neg) && f.reduceDelay()) || changeup) {
							    insertqueue(f.body.rule);
							}
				 			change = change || changeup;						 		
						}
						r.heads[i].addup.Clear();				
					}
					else {
						for(f = r.heads[i].filter; f != null; f = f.nextbody) {
					 		if ((f.body.neg) && f.reduceDelay()) {
								insertqueue(f.body.rule);
							}
						}
					}
				} 
			}
		} while (evalqueue != null);
	}
	

	void WellFoundedAF() {
		boolean change = true, inserted;
		Rule q,r;
		int durchlauf = 0;
		Atom a;
		int i;
				
		while ((change || (durchlauf % 2 == 1)) && (durchlauf < 20)) {
			ClearRuleSet1();
			evalqueue = null; lastqueue = null;
			for (q = queries; q != null; q = q.next4) {
				a = new Atom(q.anzvars);
				for (i = 0; i < q.anzvars; i++)
					a.terms[i] = new Variable(i);
				a.Variables();
				a = (Atom)q.drelation.Insert(a);
				insertqueue(q);
			}
			FilteringAF(durchlauf);
			change = false;
			for(r = rules; r != null; r = r.next1) {
				change = r.Switch() || change;
			}
			durchlauf++;
		}
	}	
	

	public void Filtering() {
		// Volles Dynamisches Filtern mit Sideways Passing
		// ATMS zur Berechnung des wellfounded models 
		Filter f;
		Rule r;
		int i, j, oldanz;
		boolean change = false, changedown = false, changeup = false;
		
		do {
			change = false;
			// Propagieren von Fakten nach oben, Konstanten nach unten, Sideways Passing
			r = getqueue();
			// System.out.println(r.no);
			if (r != null) {
				// Propagierung der Konstanten und Evaluierung
				if (r.external) {
					if (r.heads[0].adddown.anztuples > 0) {				
						XAccess(r);
					}
				}
				else if (r.facts) {
					if (r.heads[0].adddown.anztuples > 0) {
						DBAccess(db,r);
					}
				}
				else {
					r.DynamicFilteringWF();
					// Ergaenzen der Filter
					for(i = 0; i < r.anzbodies; i++) {
						if (r.bodies[i].adddown.anztuples > 0) {
							for(f = r.bodies[i].filter; f != null; f = f.nexthead) {
								changedown = f.Down(optimized);
								if (changedown) {
								    insertqueue(f.head.rule);
								 	//System.out.print("insertdown: "); System.out.println(f.head.rule.no);	
								}
								change = change || changedown;
							}
							r.bodies[i].adddown.Clear();
						}
					}
				}
				
				// Propagierung der Evaluierungsergebnisse mit Filtern nach oben
				for(i = 0; i < r.anzheads; i++) {
					if (r.heads[i].up.anztuples > 0) {
						// System.out.println();
						for(f = r.heads[i].filter; f != null; f = f.nextbody) {
							changeup = f.Up(); 
					 		if (changeup) {
							    insertqueue(f.body.rule);
							    //System.out.print("insertup1: "); System.out.println(f.body.rule.no);
							}
				 			change = change || changeup;						 		
						}
						r.heads[i].addup.Clear();				
					}
				} 
			}
			if (IClient.no > 0) {
			    try   {
			        Thread.yield();
			    }
			    catch(Exception x) {
			        System.out.println(x);
			        System.exit( -1 );
			    }
		        }
		} while ((evalqueue != null) || (IClient.no > 0));
	}	
}
