/*

Name: Body.java

Version: 1.0

Purpose:

History:

*/

package edu.unika.aifb.inference;

import java.io.*;
import java.util.*;
import java.net.*;

public class Body extends RuleAtom {
	// Rumpfatom
	boolean neg;	  		// negiert oder nicht	
	Atoms up1 = null;		// fuer alternierenden Fixpunkt bei negativen Atomen
	Atoms up2 = null;		// fuer alternierenden Fixpunkt bei negativen Atomen
	int bindex[];	  		// the indices indicate the symbols of the variables, the content the columns of the resulting relation
	int dindex[];	  		// number j at index i indicates that column i has to be copied to column j in the resulting relation
	Atoms hrelation = null; 	// Down- und Sidewayspropagierung
	Atoms addhrel = null; 		// Berechnung bei Negation
	boolean builtin = false; 	// gibt an, ob es sich um ein Builtin-Atom handelt
	int delays = 0; 		// Verz�gerung der Auswertung bei Negation
	boolean delayed = false;
	long anzahl = 0;

	Atoms brelation = null; 	// inkrementelle Berechnung des joins �ber alle Rumfpatome
	TermSet termsets[];
	boolean changets[];
	TermSet btermsets[];
	boolean changebts[];
	
	public void ClearRuleAtom() {
		// L�schen der Zwischenergebnisse der Evaluierung
		super.ClearRuleAtom();
		if (up1 != null) up1.Clear();
		if (up2 != null) up2.Clear();
		if (brelation != null) brelation.Clear();
		if (hrelation != null) hrelation.Clear();
		if (addhrel != null) addhrel.Clear();
	}
	
	public void ClearRuleAtom1() {
		// L�schen der Zwischenergebnisse der Evaluierung
		if (!neg)
			up.Clear();
		else {
			up1.Clear();
		}
		down.Clear();
		adddown.Clear();
		addup.Clear();
		//delup.Clear();
		if (brelation != null) brelation.Clear();
		if (hrelation != null) hrelation.Clear();
		if (addhrel != null) addhrel.Clear();
	}
	

	public Body(int sym, boolean negated, Term[] terms) {
		// sym = Pr�dikatsymbol, anz = Stelligkeit, negated = negiert, terms = Feld von anz Termen
		super(sym,terms);
		neg = negated;
		up = new Atoms(anzvars);
		addup = new Atoms(anzvars);
		down = new Atoms(terms.length);
		adddown = new Atoms(terms.length);
		if (negated) {
			up1 = new Atoms(anzvars);
			up2 = new Atoms(anzvars);
		}
	}

	public void print(PrintStream p) {
		if (neg) p.print('-');
		super.print(p);
	}

 	public void internalize(PrintStream p) {
		if (neg) {
			// System.out.print('-');
			//f.writeByte('-');
			p.print("-");
		}
		super.internalize(p);
	}
 
	public boolean Switch() {
		// schaltet die Fakten der negativen Literale um beim alternierenden Fixpunkt
		Atoms h;
		
		if (neg && !up1.Compare(up2)) {
			h = up2; up2 = up; up = up1; up1 = h;
			return true;
		}
		else
			return false;
	}
	
	public boolean Down(Atoms relation, int index[]) {
		int oldnum, newnum;
		// Downpropagierung ueber Rumpfatom		
		oldnum = down.anztuples;
		down.Substitute(this,relation,index);
		newnum = down.anztuples;
		return oldnum != newnum;	
	}

	public boolean NaiveRight(Atoms brel, int index[]) {
		int oldnum, newnum;
		oldnum = brelation.anztuples;
		if (!neg)
			// Join mit positivem Rumpfliteral
			brelation.Join(brel,index,up,index1,brel.matchindex,dindex);
		else 
			// Differenz mit negativem Rumpfliteral
			brelation.Negation(brel,index,up,index1);
		newnum = brelation.anztuples;
		return oldnum != newnum;
	}
	public boolean SimpleRight(Atoms brel, int index[]) {
		int oldnum, newnum;
		oldnum = brelation.anztuples;
		if (!neg)
			// Join mit positivem Rumpfliteral
			brelation.Join(brel,index,up,index1,brel.matchindex,dindex);
		else 
			brelation = brel;
		newnum = brelation.anztuples;
		return oldnum != newnum;
	}
}
