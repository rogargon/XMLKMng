/*

Name: SimpleParseException

Version: 1.0

Purpose:

History:

*/

package edu.unika.aifb.inference;

public class SimpleParseException extends Exception {
	public SimpleParseException(String s) {
		super(s);
	}
}

