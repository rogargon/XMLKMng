/*

Name: Builtin.java

Version: 1.01

Purpose:

History:
7.5. Added additional constructor and commented out class generation from String SDe
*/

package edu.unika.aifb.builtins;
import java.io.*;
import java.lang.*;
import edu.unika.aifb.inference.BuiltinFunc;
import edu.unika.aifb.utils.QSort;


public class Builtin{
	String classid=null;
	public BuiltinFunc builtinobject=null;
	public String symbol;
	public int arity;
	private Class c=null; 

	Builtin(String symbol,int arity,String classid){
		this.classid=classid;
		this.symbol = symbol;
		this.arity = arity;
	}

	Builtin(String symbol,int arity,BuiltinFunc builtinobject){
		this.builtinobject=builtinobject;
		this.symbol = symbol;
		this.arity = arity;
	}



	Builtin(String symbol, int arity){
		this.symbol = symbol;
		this.arity = arity;
	}

	public String getSymbol(){
		return symbol;
	}

	public int getArity(){
		return arity;
	}


	public BuiltinFunc newInstance(){
		if(builtinobject!=null) return builtinobject;
		/* uncomment  when a new object should be generated
		if(c==null)
			try{
				c = Class.forName(classid);
			} catch(Exception e){System.out.println("Wrong classID "+classid);}
		try{
			return (BuiltinFunc) c.newInstance();
		} catch(Exception e) { System.out.println("Can't instantiate " + c.toString()); return null;}
		*/
		return null;
	}

	public String toString(){
	if(c!=null)
		return c.toString() + "/" + new Integer(arity);
	else return symbol + "/" + new Integer(arity);
	}

}
