/*

Name: isConst.java

Version: 1.0

Purpose:

History:

*/

package edu.unika.aifb.builtins;

import edu.unika.aifb.inference.BuiltinFunc;
import edu.unika.aifb.inference.Variable;
import edu.unika.aifb.inference.Atom;
import edu.unika.aifb.inference.NumTerm;
import java.lang.Math;


public class isConst extends BuiltinFunc {


	public void eval(Atom t) {
		
		if (t.terms[0].ground && (t.terms[0].isConstTerm())) {
			insert(t);	
		}
	}			
}

