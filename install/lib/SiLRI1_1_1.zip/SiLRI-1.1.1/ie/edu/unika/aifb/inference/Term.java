/*

Name: Term.java

Version: 1.0

Purpose:

History:

*/

package edu.unika.aifb.inference;

import java.io.*;
import java.util.*;
import java.net.*;
/*
Dieses Modul enthaelt alles, was mit einzelnen Termen zusammenhaengt
*/


public abstract class Term {
	public static int anz = 0;
	// public int type = 0;				Typ eines Terms: Variable, Konstante,...
	public boolean ground = true;			// gibt an ob keine Variablen enthalten sind
	public int groundlevel = -1;			// gibt an bis zu welchem Level der Term grund ist
	public int anzpars = 0;				// Stelligkeit des Terms
	public Term pars[] = null;			// Unterterme
	public abstract int CompareEqual(Term t);	// Vergleicht zwei Terme (ohne Unterterme) auf Gleichheit
							// -1 falls this < t, 0 falls this = t, 1 falls this > t
	public abstract void print1(PrintStream p);	// Ausgabe auf PrintStream
	public abstract void print1(PrintStream pr, String p[],String f[], String s[]);	// Ausgabe auf PrintStream
	public abstract String toString1(); 
							// Ausgabe eines Terms als String
	public abstract String toString1(String p[],String f[], String s[]); 
							// Ausgabe des Terms als String, p,f,s sind Symboltabellen f�r Pr�dikate,Funktionssymbole,Strings
	public abstract void internalize1(PrintStream p);
	public abstract Term Substitute();		// Durchfuehren der Substitution von Variablen innerhalb von Termen
	public abstract Term Clone();			// Duplizieren eines Terms mit Untertermen
	public abstract Term clone1();			// Duplizieren ohne Unterterme

	public abstract int type();
	
	
	public Term(int stelligkeit, boolean grnd) {
		anz++;
		// creating terms 
		anzpars = stelligkeit;
		ground = grnd;
		if (stelligkeit > 0) 
			pars = new Term[stelligkeit];
	}
	
	public boolean isNumTerm() {return false;}
	public boolean isStringTerm() {return false;}
	public boolean isConstTerm() {return false;}
	public boolean isVariable() {return false;}
			
	public int CompareTypes(Term t) {
		// vergleicht zwei einzelne Terme (ohne Unterterme) aufgrund deren Typen und Stelligkeit
		// liefert die Werte -1 falls this < t, 0 falls this = t, 1 falls this > t
		int res;
		res = (type() <= t.type())?(type()<t.type()?-1:0):1;
		return (res!=0)?res:((anzpars<=t.anzpars)?((anzpars<t.anzpars)?-1:0):1);
	}
	
	public int Compare(Term t) {
		// vergleicht zwei Terme mit Untertermen
		// liefert die Werte -1 falls this < t, 0 falls this = t, 1 falls this > t		
		int cmp,i;
		if ((type() != t.type()) || (anzpars != t.anzpars)) {
			return CompareTypes(t);
		}
		else {
			cmp = CompareEqual(t);
			if (cmp == 0) {
				for (i = 0; i < anzpars; i++) {
					cmp = pars[i].Compare(t.pars[i]);
					if (cmp != 0) return cmp;
				}
			}
			return cmp;
		}
	}
					
	public boolean Unify(Term t) {
		// Unifiziert zwei Terme. Die Substitutionen f�r die Variablen werden an das
		// Feld subsby der Variablen angeh�ngt
		int i;
		boolean res=true;
		if (t instanceof Variable) return t.Unify(this);
		else if ((CompareTypes(t) != 0) || (CompareEqual(t) != 0)) return false;
		else {
			for (i = 0; i < anzpars; i++) {
				res = pars[i].Unify(t.pars[i]);
				if (!res) return res;
			}
			return res;
		}
	}
	
	public boolean Match(Term t) {
		// Matcht den Term this mit dem Grundterm t. Die Substitutionen f�r die Variablen werden an das
		// Feld subsby der Variablen in this angeh�ngt
		int i;
		boolean res=true;
		//if (t.ground) {
			if ((CompareTypes(t) != 0) || (CompareEqual(t) != 0)) 
				return false;
			else {
				for (i = 0; i < anzpars; i++) {
					res = pars[i].Match(t.pars[i]);
					if (!res) return res;
				}
				return res;
			}
	}

	public Term Generalize(Term t) {
		// erzeugt einen Term der sowohl mit this als auch mit t unifizierbar ist
		// Dabei muss this und t unifizierbar sein
		Term t1 = null;
		int i;
		boolean ground = true;
		if (t instanceof Variable)
			t1 = t.clone1();
		else 
			t1 = this.clone1();
		for(i = 0; i < anzpars; i++) {
			t1.pars[i] = this.pars[i].Generalize(t.pars[i]);
			if (!t1.pars[i].ground) ground = false;
		}
		t1.ground = t1.ground && ground;
		return t1;
	}
			
		
	
	protected boolean occurs(Variable v) {
		// Occurence Check f�r Variablen: true, falls Variable v in this auftritt. Dabei sind
		// die Variablensymbole ma�gebend
		int i;
		boolean res=false;
		if (!ground) {
			for (i = 0; i < anzpars; i++) {
				res = pars[i].occurs(v);
				if (res) return res;
			}
		}
		return res;
	}

	boolean isGround(long v) {
		// v hat an der Stelle Bit i gesetzt, wenn Variable i nicht substituiert sein soll
		// isGround gibt an, ob der Term unter zus�tzlicher Substitution der
		// Variablen in v ground ist
		int i;
		if (ground)
			return true;
		else if (this instanceof Variable) {
			if (((1L<<(((Variable)this).symbol)) & v) == 0)
				return true;
			else
				return false;
			}
		else {
			for(i = 0; i < anzpars; i++) {
				if (!pars[i].isGround(v))
					return false;
			}
		}
		return true;
	}
					

			
	public void print(PrintStream p) {
		// Ausgabe eines Terms zu Debugging-Zwecken
		int i;

		//System.out.println("Term.printb");		
		print1(p);
		if (anzpars > 0) {
			p.print('(');		
			for(i= 0; i < anzpars; i++) {
				pars[i].print(p);
				if (i < anzpars-1) 	
					p.print(',');	
			}
			p.print(')');
		}		
	}

	public void print(PrintStream p, String pr[],String f[], String s[]) {
		// Ausgabe eines Terms zu Debugging-Zwecken
		int i;
		
		//System.out.println("Term.printb");
		print1(p,pr,f,s);
		if (anzpars > 0) {
			p.print('(');		
			for(i= 0; i < anzpars; i++) {
				pars[i].print(p,pr,f,s);
				if (i < anzpars-1) 	
					p.print(',');	
			}
			p.print(')');
		}		
	}
	
	public void internalize(PrintStream p) {
		int i;
		// Character ch;
		//System.out.println("Term.internalize");
		internalize1(p);
		if (anzpars > 0) {
			// ch = new Character((char)((int)(anzpars)));
			//System.out.print(ch.toString());
			//System.out.print("l");System.out.print(anzpars);
			//f.writeBytes("l"+String.valueOf(anzpars));
			p.print("l"+String.valueOf(anzpars));	
			for(i= 0; i < anzpars; i++) {
				pars[i].internalize(p);
			}
		}
	}

	public String toString(String p[],String f[], String st[]) {
		// Ausgabe eines Terms mit Untertermen als String, p,f,s sind Symboltabellen f�r
		// Pr�dikatsymbole, Funktionssymbole, Strings
		int i;
		String s;
		// System.out.println("Term.toString");
		s = toString1(p,f,st);
		if (anzpars > 0) {
			s = s.concat("(");		
			for(i= 0; i < anzpars; i++) {
				s = s.concat(pars[i].toString(p,f,st));
				if (i < anzpars-1) s = s.concat(",");	
			}
			s = s.concat(")");
		}
		return s;		
	}

	public String toString() {
		// Ausgabe eines Terms mit Untertermen als String
		int i;
		String s;
		s = toString1();
		if (anzpars > 0) {
			s = s.concat("(");		
			for(i= 0; i < anzpars; i++) {
				s = s.concat(pars[i].toString());
				if (i < anzpars-1) s = s.concat(",");	
			}
			s = s.concat(")");
		}
		return s;		
	}
		
}
	
					
	

	





