/*

Name: DB.java

Version: 1.0

Purpose:

History:

*/

package edu.unika.aifb.inference;

import java.io.*;


public class DB implements DBInterface {
	Atoms facts[] = null;	// Feld von Faktenmengen der Regelmenge
	int increment = 200;    // dynamische Erweiterung der Felder facts um incr
	int maxpreds = 0;	// gr�sstes bisher aufgetretenes Pr�dikatsymbol

	public DB() {	
		// Konstruktor 
		maxpreds = increment-1;
		facts = new Atoms[increment];
	}
	
	private void extend(int index) {
		// erweitert das Feld facts so dass sie auch den Index 'index' enthalten
		int len, i;
		Atoms newfacts[];
		len = maxpreds+1;
		if (maxpreds < index) {
			while (len < index + 1) len +=increment;
			newfacts = new Atoms[len];
			for (i = 0; i <= maxpreds; i++) {
				newfacts[i] = facts[i];
			}
			facts = newfacts;
		}
		maxpreds = len-1;
	}
			

	public void write(PrintStream p) throws IOException {
		/*
		Schreibt die Faktenmenge im internen Format auf p heraus
		*/
		int i;
		for(i = 0; i < facts.length; i++) {
			if (facts[i] != null) facts[i].internalize(p,i);
		}
	}

	public void read(RandomAccessFile file) throws IOException {
	    String s = "";
	    SParser spars;

	    spars = new SParser();
	    while((s = file.readLine())!= null) {
		try {
			spars.decode(null, this, s+"\n");
		}
		catch (JanParseError1 p) {
			System.out.println(p.getMessage());
		}
  
	    } 
	}


	private void checksym(int sym) {
		// neues Pr�dikatsymbol
		// falls noetig RuleSet erweitern
		if (sym > maxpreds)
			extend(sym);
	}
	
	
			
	public void AddFact(int sym, GroundAtom fact) {
		// F�gt ein einzelnes Faktum  hinzu

		boolean inserted;
		int i;
		// if (sym == 6) {fact.print(System.out); System.out.println();}
		// falls noetig RuleSet erweitern
		checksym(sym);
		if (facts[sym] == null) {
			// noch kein Faktum dieses Pr�dikatsymbols vorhanden
			// Erzeugen einer neuen Faktenmenge dieses Symbols
			facts[sym] = new Atoms(fact.terms.length);
		}
		// Einf�gen des Faktums in die Faktenmenge
		fact = facts[sym].Insert(fact);
	}



	public void DeleteFact(int sym, GroundAtom fact) {
		// L�scht ein  Faktum
		if (facts[sym] != null) 
			facts[sym].Delete(fact);
	}


	


	public Atoms GetFacts(int praedikatsymbol, Atoms filterterme) {
		/* 
		Das ist die wesentliche Funktion zum Zugriff auf Fakten. Es werden auf Fakten mit dem Pr�dikatsymbol praedikatsymbol zugegriffen. Der Zugriff wird mit Hilfe einer Menge von Filtertermen filterterme eingeschr�nkt. Ein Filterterm ist ein Tupel von Termen, die Variablen enthalten k�nnen. Z.B. ist f(X,a),"hallo",X
		ein solcher Filterterm. Das Ergebnis des Aufrufs ist eine Menge von Fakten, die zu diesen Filtertermen "passen" (die mit einem der Filterterme matchen). 

		Z.B. enthalte die entsprechende Tabelle der DB die Zeilen:
		5, "hallo",8
		f(7,a), "hallo",7
		f(ab,a), "hallo",ab
		f(7,a), "hallo",h
		f(ab,a), "huhu",ab

		Die filterterme bestehen nur aus dem einen Filterterm: f(X,a),"hallo",X. Dann ist das Ergebnis des Aufrufs die folgende Menge von Fakten:
		f(7,a), "hallo",7
		f(ab,a), "hallo",ab
		*/
	
		/*System.out.println("Filterterme:");
		filterterme.print(System.out);
		System.out.println("-------------------------------------");*/
		
		Atoms res = null;
		if (facts[praedikatsymbol] != null) {
			/*System.out.println("verf�gbar:");
			facts[praedikatsymbol].print(System.out);
			System.out.println("-------------------------------------");*/	
			res = new Atoms(facts[praedikatsymbol].stellen);
			res.Filtering1(filterterme,facts[praedikatsymbol]);
		}
		/*System.out.print("Pr�dikatsymbol: "); System.out.println(praedikatsymbol);
		System.out.println("Ergebnis:");
		if (res != null) res.print(System.out);
		System.out.println("===============================================");*/
		return res;
	}

	public TermSet GetTerms(int praedikatsymbol, int i) {
		/*
		Dies wird f�r Optimierungszwecke gebraucht. Liefert die Menge von Termen, 
		die am i-ten Argument aller Fakten des Pr�dikatsymbols praedikatsymbol auftreten.
		*/

		TermSet terms;
		if (facts[praedikatsymbol] != null) {
			terms = new TermSet();
			facts[praedikatsymbol].Terms(terms,i);
			return terms;
		}
		else
			return new TermSet();
	}
	
}
