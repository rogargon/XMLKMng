/*

Name: CompileFLogic.java

Version: 1.0

Purpose:

History:

*/

package edu.unika.aifb.inference;

import java.util.*;
import java.util.Date;
import java.net.*;
import java.io.*;


public class CompileFLogic extends Object {
   public static void main(String args[]) throws Exception  { 
     PrintStream f;
     RandomAccessFile sym;
     Evaluator eval = new Evaluator();
     f = new PrintStream(new FileOutputStream(args[0]));
     // eval.RS.writeonly(f);
     eval.init(f);
     sym = new RandomAccessFile(args[1],"rw");
     // sym = new RandomAccessFile(args[1],"r");
     // eval.read(sym);

     for(int i=2; i < args.length; i++)
       {
//System.out.println(args[i]);
         eval.compileFile(args[i]);
       }
     // eval.RS.write(f);
     f.close();
     eval.write(sym);
     sym.close();
 
 
 }

}


