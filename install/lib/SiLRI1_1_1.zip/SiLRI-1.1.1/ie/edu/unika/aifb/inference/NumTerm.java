/*

Name: NumTerm.java

Version: 1.0

Purpose:
Represents Number Constants

History:

*/

package edu.unika.aifb.inference;

import java.io.*;
import java.util.*;
import java.net.*;

public class NumTerm extends Term {
	// type = 2
	public double zahl;  // NumTerm wird durch zahl repr�sentiert
	
	public NumTerm(double z, Term terms[]) {
		// Funktion mit Zahl z als Funktionssymbol
		// terms enthaelt die Parameter
		super(terms.length,true);
		int i;
		boolean ground = true;
		if (terms.length > 0) groundlevel = terms[0].groundlevel+1;
		for(i = 0; i < terms.length; i++) {
			if (!terms[i].ground) ground = false;
			if (terms[i].groundlevel+1 < groundlevel) groundlevel = terms[i].groundlevel+1;
			pars[i] = terms[i];
		}
		this.ground = ground;
		zahl = z;
	}
	public NumTerm(double z) {
		// Zahlkonstante
		super(0,true);
		zahl = z; 
	}
	public NumTerm(double z, int stelligkeit, boolean grnd) {
		// Funktion mit Zahl als Funktionssymbol, Stelligkeit stelligkeit
		// grnd gibt an, ob die Parameter Variablen enthalten oder nicht
		super(stelligkeit,grnd);
		zahl = z; 
	}
	
	public int type() {return 2;}

	public boolean isNumTerm() {return true;}
	
	public Term Clone() {
		// Klonen des Terms und seiner Unterterme
		NumTerm t;
		int i;
		t = new NumTerm(zahl,anzpars,ground);
		for (i = 0; i < anzpars; i++)
			t.pars[i] = pars[i].Clone();
		return t;
	}

	public Term clone1() {
		return new NumTerm(zahl,anzpars,ground);
	}
	public String toString1(String p[],String f[], String s[]) {
		// Ausgabe als String, ids ist die Symboltabelle f�r Konstanten und Funktionssymbole
		Double d = new Double(zahl);		
		return d.toString();
	}

	public void print1(PrintStream p) {p.print(zahl);}
	public String toString1() {return String.valueOf(zahl);}
	public void print1(PrintStream pr, String p[],String f[], String s[]) {pr.print(zahl);}

	public void internalize1(PrintStream p) {
		//Double Zahl = new Double(zahl);
		//System.out.print("n");System.out.print(zahl);
		//f.writeBytes("n"+String.valueOf(zahl)); 
		p.print("n"+String.valueOf(zahl));
	}

	public int CompareEqual(Term t) {
		// Vergleich eines NumTerms mit einem anderen NumTerm
		return zahl <= ((NumTerm)t).zahl?(zahl<((NumTerm)t).zahl?-1:0):1;	
	}
	public Term Substitute() {
		// Durchf�hrung einer Substitution, d.h. die Variable wird durch ihren
		// Substituenden im Term ersetzt
		// Dabei werden alle oberen Terme (�berhalb von Variablen) neu generiert
		Term t;
		int i;
		if (ground) return this;
		else {
			t = new NumTerm(zahl, anzpars, true);
			ground = true;
			for(i = 0; i < anzpars; i++) {
				t.pars[i] = pars[i].Substitute();
				if (!t.pars[i].ground) t.ground = false;
			}
			return t;
		}
	}
}
	
