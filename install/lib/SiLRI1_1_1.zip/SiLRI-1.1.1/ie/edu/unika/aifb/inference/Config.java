/*

Name: Config.java

Version: 1.0

Purpose:
System-Wide Configuration Data

History:
2.5.99 Added provisional support for Strings Consts SDe

*/

package edu.unika.aifb.inference;
/* this class contains configuration data used by the inference engine */


public class Config{
	public static final int STRINGSTART = 100000;
	/* Strings are encoded as constants beginning with this number */


	/* Definitions of several predicate symbols */
	 public static final String[] METHODSYMBOL = {"att_",  
                                       "setatt_",
                                       "atttype_",
                                       "setatttype_",
                                       "inatt_",
                                       "insetatt_"};
  	public static final String INASYMBOL= "isa_";
  	static final String ISASYMBOL = "sub_";
  	static final String PARTOFSYMBOL = "partof_";
  	static final String METHODARGSYMBOL = "args_";
  	static final String METHODNAMESYMBOL= "methodname_";
  	static final String OBJECTSYMBOL = "object_";
 	static final String PATHSYMBOL = "path_";
  	public static final String NIL = "nil_";
  	public static final String LIST = "l_";
  	static final String DIRECT = "direct_";
  	static final String SETDIRECT = "setdirect_";

	static public SimpleEvaluator ev = null; // provisional solution SDe



}

