package org.desire.rudolf.rdf;

import java.lang.*;
import java.util.*;
import org.w3c.rdf.Resource;
import org.w3c.rdf.Property;
import org.w3c.rdf.DataSource;
import org.w3c.rdf.RDFnode;
import org.w3c.rdf.RDFConsumer;
import org.w3c.rdf.Literal;

/** 

<P>RDFModelCore   $Id: RDFModelCore.java,v 1.3 1999/05/01 16:11:34 pldab Exp $</P>

<P>This is a stop-gap API to represent the facilities implemented in RDFGraph, which should
really be called RDFInMemoryGraph. <B>All of this may change.</B>
</P>


<P>
RDFQueryCore represents a syntax-independent RDF graph of nodes and arcs. A few basic query methods
are available, to allow client applications to ask for all the nodes that have a given
property/value pairing, or all the nodes (and literals) that are the value of a given property
of a node.
</P>

<PRE>
Recent Changes:
$Log: RDFModelCore.java,v $
Revision 1.3  1999/05/01 16:11:34  pldab
Added hasAssertion to core API

Revision 1.2  1999/05/01 12:39:07  pldab
Added CVS comments


</PRE> */

public interface RDFModelCore extends RDFConsumer {
 
/**
An RDFConsumer method that is called by the datasource to notify us when data is about to
arrive.
*/
public void start(DataSource ds);


/**
An RDFConsumer method that is called by the datasource to notify us when data will no longer be
arriving from that source (until further notice).
*/ 
public void end(DataSource ds);



/**				<P> Assert </P>


<P>
An RDFConsumer method that is called by the datasource to inform us of some new fact.
Currently we offer no mechanism (ie. return type is 'void') to let the datasource know whether
the assertion was accepted, ie. written into our RDF model as triple (ie. statement). 
</P>
<P>
Note that statements which have a resource as their object can only be represented once within
an RDF graph, regardless of how many times they are asserted. Reified representations of such
statements can of course appear multiple times.
</P>
<P><B>Todo: the handling of literal-valued assertions is currently incomplete</B></P>

*/

public void assert(DataSource ds, Property p,  Resource r, RDFnode v);


/** Boolean check to see if a statement is in the database */

public boolean hasAssertion( Property p,  Resource r, RDFnode v);


/** 
* Query method: find values 'of this property for this resource'
*
***/
public Vector valuesWhere(Property property, Resource resource);


/**
* Query method: find nodes where 'this property has that value'
* For a specified property and value(URI), return URIs for each node that
* has arcs out fitting that template.
*
*/
public Vector nodesWhere(Property property, RDFnode value_uri);


/**
nodesWhere query method; returns a list of nodes that have a given property.
*/
public Vector nodesWhere(Property property);


}


