LICENSE
-------
Please see the file copyright-software.html


INSTALLATION
------------

Please see the file index.html


USAGE
-----

tryme.bat contains a small example.

The class edu.unika.aifb.rdfie.SiLRI (= Simple Logic-based RDF Interpreter) has the following parameters
  -rdf filename 
   Compile a RDF specification from a given file

  -rdfurl URL
   Compile a RDF specification from a given URL

  -simple filename
   Compile facts, rules and queries from a given file written in a prolog like
   syntax. The parser is much faster than the default parser, but understands 
   only a limited syntax. However, for reading in large fact files this option
   should be used.
   
  filename 
  If just one or more filenames are provided, these file are compiled using
  the general F-Logic parser. These parser understand a very general frame-based
  logic expressions, but is rather slow.

All arguments can be mixed
(e.g. SiLRI -simple file1 -simple file2 -rdf rdffile1 -rdfurl url1 complexfile1 complexfile2)
For an API see the file edu.unika.aifb.inference.Evaluator.java
and (derived from that class) edu.unika.aifb.rdfie.RDFEvaluator.java

The JIT of some versions of the JDK contains serveral bugs.
If you get unexpected exceptions, please try to turn of the JIT first.


SIMPLE SYNTAX
-------------

The simple syntax is oriented towards prolog, but there exists some differences:

 - Variables start with a capital letter.
 - Atoms are written like in prolog ( like: p(term1,term2))
 - negated Atoms are specified with a "-" like - p(term1,term2) 
 - rule can have multiple heads.

Examples are e.g.

r(a,b).
r(c,d).
z(a,b).

p(X) & q(Y) <- r(X,Y)  & -z(X,Y).

<- p(X).
<- q(Y).


COMPLEX SYNTAX
--------------

The complex syntax is a variant of F-Logic 
(see Kifer, Lausen, Wu: F-logic, Communications of the ACM 1995).

Some basic expressions are:

  - C1 :: C2   
    C1 is a subclass of C2

  - O : C 
    O is an instance of C

  - O[A->>V]
    Object o as an attribute A with value V

  - C1[A=>>C2]
    Class C1 has an attribute, the value range is class C1.

  - also combined expressions are allowed, e.g.
    C1 :: C2[A1=>>C3;A2=>>C4]
    (C1 is a subclass of C2 and has two more attributes than C2:
     A1 and A2 with value ranges C3 and C4. 

  - usual predicates like p(X)

  - Variables have to be introduced by an quantifier.

  - Rules consist of a rule head and a rule body.
    The head can be a conjunction of several primitives
    The body of a rule (and a query) can be any first order formula.
    An examples is:
 
    FORALL V,Y
      myobject[a->>V] and p(Y) <-  
           (EXISTS Z object2[a->>Z) and q(V,Y)) or
           (t(V,Y) and forall U not o(u,v,y).

  - A double rule defines a dependency between two conjunctions of basic expressions.
    An example for a double rule is eg.
   
FORALL Person1, Publication1
	Publication1:Publication[author ->> Person1] <->
		Person1:Person[publication ->> Publication1].

Other examples are:

Object[].
Person :: Object.
  Employee :: Person.
    AcademicStaff :: Employee.
      Researcher :: AcademicStaff.
        PhDStudent :: Researcher.

Employee[		
	affiliation =>> Organization;
	worksAtProject =>> Project;
	headOf =>> Project;
	headOfGroup =>> ResearchGroup].
  



BUGS & COMMENTS
---------------

Please send comments and bug reports to 

Stefan.Decker@aifb.uni-karlsruhe.de
