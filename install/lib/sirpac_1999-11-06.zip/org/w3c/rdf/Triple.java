/**
 * Simple Triple class
 *
 * $Log: Triple.java,v $
 * Revision 1.13  1999/05/04 15:27:20  lehors
 * commit after CVS crash
 *
 * Revision 1.4  1999/04/01 09:32:57  jsaarela
 * SiRPAC distribution release V1.11 on 1-Apr-99
 *
 * Revision 1.3  1998/10/07 21:55:23  jsaarela
 * Vocabulary changed.
 *
 * Revision 1.2  1998/06/17 09:17:38  jsaarela
 * Updated the translator to manage new RDF constructs such as
 * distributive referents and changed attribute names.
 *
 * Revision 1.1  1998/05/12 13:15:25  jsaarela
 * Routines for RDF manipulation added.
 *
 *
 * @author Janne Saarela
 */
package org.w3c.rdf;

public interface Triple
{
  public Resource predicate ();

  public Resource subject ();

  public RDFnode object ();
}
