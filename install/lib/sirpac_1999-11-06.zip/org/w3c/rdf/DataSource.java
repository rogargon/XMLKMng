/**
 * Copyright � World Wide Web Consortium, (Massachusetts Institute of
 * Technology, Institut National de Recherche en Informatique et en
 * Automatique, Keio University).
 *
 * All Rights Reserved.
 *
 * Please see the full Copyright clause at
 * <http://www.w3.org/Consortium/Legal/copyright-software.html>
 *
 * DataStore interface
 *
 * $Log: DataSource.java,v $
 * Revision 1.1  1999/05/04 15:23:18  lehors
 * commit after CVS crash
 *
 * Revision 1.2  1999/04/26 14:51:26  jsaarela
 * URI resolution improved.
 *
 * Revision 1.1  1999/04/01 09:32:30  jsaarela
 * SiRPAC distribution release V1.11 on 1-Apr-99
 *
 *
 * @author	Janne Saarela <jsaarela@w3.org>
 */
package org.w3c.rdf;

import org.xml.sax.InputSource;

public interface DataSource
{
    /**
     * register a RDFConsumer object
     *
     * @param	c	RDFConsumer object
     */
    public void		register (RDFConsumer c);

    /**
     * unregister a RDFConsumer object
     *
     * @param	c	RDFConsumer object
     */
    public void		unregister (RDFConsumer c);

    /**
     * start processing RDF (from the URI set by setURI)
     *
     */
    public void		fetchRDF () throws Exception;

    /**
     * Bean method for setting the RDFSource
     *
     * @param	is	The RDFSource instance
     */
    public void		setRDFSource (InputSource source);

    /**
     * Bean method for getting the RDFSource
     */
    public InputSource	getRDFSource ();
}
