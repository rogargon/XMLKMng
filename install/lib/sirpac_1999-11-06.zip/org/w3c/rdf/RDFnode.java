/**
 * Copyright � World Wide Web Consortium, (Massachusetts Institute of
 * Technology, Institut National de Recherche en Informatique et en
 * Automatique, Keio University).
 *
 * All Rights Reserved.
 *
 * Please see the full Copyright clause at
 * <http://www.w3.org/Consortium/Legal/copyright-software.html>
 *
 * $Log: RDFnode.java,v $
 * Revision 1.1  1999/05/04 15:25:45  lehors
 * commit after CVS crash
 *
 * Revision 1.1  1999/04/01 09:32:41  jsaarela
 * SiRPAC distribution release V1.11 on 1-Apr-99
 *
 *
 * @author	Janne Saarela <jsaarela@w3.org>
 */
package org.w3c.rdf;

public interface RDFnode {

  // Sergey Melnik: I know every Java object has it. Just want to have some common semantics.

  /**
   * Returns a serialized value of the node which is a URI in case of a Resource
   * and an arbitrary non-null string in case of a Literal
   */
  public String toString();
}
