/**
 * Copyright � World Wide Web Consortium, (Massachusetts Institute of
 * Technology, Institut National de Recherche en Informatique et en
 * Automatique, Keio University).
 *
 * All Rights Reserved.
 *
 * Please see the full Copyright clause at
 * <http://www.w3.org/Consortium/Legal/copyright-software.html>
 *
 * RDFConsumer interface can be used to create
 *
 * $Log: RDFConsumer.java,v $
 * Revision 1.1  1999/05/05 08:49:05  jsaarela
 * Distribution V1.11 5-May-99.
 *
 * Revision 1.1  1999/04/26 14:51:27  jsaarela
 * URI resolution improved.
 *
 * Revision 1.1  1999/04/01 09:32:54  jsaarela
 * SiRPAC distribution release V1.11 on 1-Apr-99
 *
 *
 * @author	Janne Saarela <jsaarela@w3.org>
 */
package org.w3c.rdf;

public interface RDFConsumer
{
    /**
     * start is called when parsing of data is started
     *
     * @param	ds	DataSource starting its job
     */
    public void start (DataSource ds);

    /**
     * end is called when parsing of data is ended
     *
     * @param	ds	DataSource finishing its job
     */
    public void end   (DataSource ds);

    /**
     * assert is called every time a new statement within
     * RDF data model is added
     *
     * @param	ds	DataSource who assert'ed this statement
     *                  (can be null if the assert'ing party
     *                   does no implement DataSource interface)
     */
    public void assert (DataSource ds,
			Resource predicate,
			Resource subject,
			RDFnode  object);

}
