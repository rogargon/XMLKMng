/**
 * Copyright � World Wide Web Consortium, (Massachusetts Institute of
 * Technology, Institut National de Recherche en Informatique et en
 * Automatique, Keio University).
 *
 * All Rights Reserved.
 *
 * Please see the full Copyright clause at
 * <http://www.w3.org/Consortium/Legal/copyright-software.html>
 *
 * $Log: Resource.java,v $
 * Revision 1.1  1999/05/04 15:26:02  lehors
 * commit after CVS crash
 *
 * Revision 1.2  1999/04/26 14:51:27  jsaarela
 * URI resolution improved.
 *
 * Revision 1.1  1999/04/01 09:32:45  jsaarela
 * SiRPAC distribution release V1.11 on 1-Apr-99
 *
 *
 * @author	Janne Saarela <jsaarela@w3.org>
 */
package org.w3c.rdf;

public class ResourceImpl implements Resource
{
    protected String	m_sURI;
  //  static long nonameCounter = 0;

  public ResourceImpl() {
    //    m_sURI = "noname" + (++nonameCounter);
  }

    public ResourceImpl (String sURI) {
	m_sURI = sURI;
    }

  //    public void		setURI (String sURI) {
  //	m_sURI = sURI;
  //    }

  //    public String	getURI () {
  //	return m_sURI;
  //    }

    public String	toString () {
	return m_sURI;
    }

  public int hashCode() {
    return m_sURI.hashCode();
  }

    public boolean	equals (Object that) {

      if (this == that) 
        {
	  return true;
        }
      if (that == null || !(that instanceof Resource))
        {
	  return false;
        }

      return m_sURI.equals( ((Resource)that).toString() );
    }
}
