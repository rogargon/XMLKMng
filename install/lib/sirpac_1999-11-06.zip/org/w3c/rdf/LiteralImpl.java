/**
 * Copyright � World Wide Web Consortium, (Massachusetts Institute of
 * Technology, Institut National de Recherche en Informatique et en
 * Automatique, Keio University).
 *
 * All Rights Reserved.
 *
 * Please see the full Copyright clause at
 * <http://www.w3.org/Consortium/Legal/copyright-software.html>
 *
 * $Log: Literal.java,v $
 * Revision 1.1  1999/05/04 15:23:59  lehors
 * commit after CVS crash
 *
 * Revision 1.2  1999/05/04 14:52:43  jsaarela
 * Literal value now tells if it is well-formed XML.
 * Improved entity management in Data nodes.
 *
 * Revision 1.1  1999/04/01 09:32:34  jsaarela
 * SiRPAC distribution release V1.11 on 1-Apr-99
 *
 *
 * @author	Janne Saarela <jsaarela@w3.org>
 */
package org.w3c.rdf;

public class LiteralImpl implements Literal
{
    private String	m_sLiteral;
    private boolean	m_bXML = false;
  private String	m_sXMLlang; // new String ("undefined");

    public LiteralImpl() {
      //	m_sLiteral = "undefined";
    }

    public LiteralImpl(String sLiteral) {
	m_sLiteral = sLiteral;
    }

    public LiteralImpl(String sLiteral, boolean bXML) {
	m_sLiteral = sLiteral;
	m_bXML = bXML;
    }

    public void		setLiteral (String sLiteral) {
	m_sLiteral = sLiteral;
    }

    public String	getLiteral () {
	return m_sLiteral;
    }

    public String	toString () {
	return m_sLiteral;
    }

    /**
     * Is the literal well-formed XML markup?
     */
    public boolean	isXML () {
	return m_bXML;
    }

    /**
     * The language of a literal can be managed separately
     * from the RDF data model with the xml:lang attribute
     */
    public void		setXMLlang (String sLang) {
	m_sXMLlang = sLang;
    }

    public String	getXMLlang () {
	return m_sXMLlang;
    }

  public int hashCode() {
    return m_sLiteral.hashCode();
  }

    public boolean	equals (Object that) {

      if (this == that) 
        {
	  return true;
        }
      if (that == null || !(that instanceof Literal)) 
        {
	  return false;
        }

      return m_sLiteral.equals( ((Literal)that).toString() );
    }
}
