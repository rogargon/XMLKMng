/**
 * Simple Triple class
 *
 * $Log: Triple.java,v $
 * Revision 1.13  1999/05/04 15:27:20  lehors
 * commit after CVS crash
 *
 * Revision 1.4  1999/04/01 09:32:57  jsaarela
 * SiRPAC distribution release V1.11 on 1-Apr-99
 *
 * Revision 1.3  1998/10/07 21:55:23  jsaarela
 * Vocabulary changed.
 *
 * Revision 1.2  1998/06/17 09:17:38  jsaarela
 * Updated the translator to manage new RDF constructs such as
 * distributive referents and changed attribute names.
 *
 * Revision 1.1  1998/05/12 13:15:25  jsaarela
 * Routines for RDF manipulation added.
 *
 *
 * @author Janne Saarela
 */
package org.w3c.rdf;

public class TripleImpl implements Triple
{
  private Resource	m_predicate = null;
  private Resource	m_subject = null;
  private RDFnode	m_object = null;
  private int hashCode = 0;

  /**
   * The parameters to constructor are instances of classes
   * and not just strings
   */
  public TripleImpl (Resource predicate, Resource subject, RDFnode object) {
    m_predicate = predicate;
    m_subject = subject;
    m_object = object;
  }

  public Resource predicate () {
    return m_predicate;
  }

  public Resource subject () {
    return m_subject;
  }

  public RDFnode object () {
    return m_object;
  }

  public int hashCode() {

    if(hashCode == 0)
      hashCode = m_subject.hashCode() ^ m_predicate.hashCode() ^ m_object.hashCode();
    return hashCode;
  }

  public String toString() {

    String objStr = m_object instanceof Literal ? "literal(\"" + m_object + "\")" : "\"" + m_object + "\"";
    return "triple(\"" + m_subject + "\", \"" + m_predicate + "\", " + objStr + ")";
  }

  public boolean equals (Object that) {
    
    if (this == that) 
      {
	return true;
      }
    if (that == null || !(that instanceof Triple)) 
      {
	return false;
      }
    
    Triple t = (Triple)that;

    if(hashCode() != t.hashCode())
      return false;

    /*
    if(DEBUG) {
      System.err.println("Matching: " + subject().equals(t.subject()) + " " +
			 predicate().equals(t.predicate()) + " " +
			 object().equals(t.object()));
      System.err.println("Subjects: " + subject() + " vs " + t.subject() + ", Class: " + subject().getClass());
    }
    */

    return
      subject().equals(t.subject()) &&
      predicate().equals(t.predicate()) &&
      object().equals(t.object());
  }
  //  public static boolean DEBUG = false;
}
