/**
 * Copyright � World Wide Web Consortium, (Massachusetts Institute of
 * Technology, Institut National de Recherche en Informatique et en
 * Automatique, Keio University).
 *
 * All Rights Reserved.
 *
 * Please see the full Copyright clause at
 * <http://www.w3.org/Consortium/Legal/copyright-software.html>
 *
 * $Log: Literal.java,v $
 * Revision 1.1  1999/05/04 15:23:59  lehors
 * commit after CVS crash
 *
 * Revision 1.2  1999/05/04 14:52:43  jsaarela
 * Literal value now tells if it is well-formed XML.
 * Improved entity management in Data nodes.
 *
 * Revision 1.1  1999/04/01 09:32:34  jsaarela
 * SiRPAC distribution release V1.11 on 1-Apr-99
 *
 *
 * @author	Janne Saarela <jsaarela@w3.org>
 */
package org.w3c.rdf;

public interface Literal extends RDFnode {
}
